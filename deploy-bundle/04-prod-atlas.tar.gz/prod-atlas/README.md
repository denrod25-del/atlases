# Production APIs — Atlas #19 (B. Symbolic)

Caching · Idempotency · Pagination · Observability

Standalone Vite + React + Tailwind project. Closes the 3-atlas API series
(17 — Foundations, 18 — Security, 19 — Production).

Build script uses `node ./node_modules/vite/bin/vite.js build` (Vercel-fix
baked in). `.gitignore` baked in from the first commit. No `sk_live_` /
`sk_test_` / `AKIA*` / `ghp_*` patterns anywhere in source — push protection
safe by construction.

## Run locally
```
npm install
npm run dev          # http://localhost:5173
```

## Deploy
Push to GitHub. Connect at vercel.com/new. Auto-detects Vite. ~60s to live URL.

## Section status — all complete
- 01 Caching        — Cache Policy Picker (4 scenarios, 3 candidate configs each)
- 02 Idempotency    — Retry Simulator (3 scenarios, step-through sequence diagrams)
- 03 Pagination     — Performance Comparator (log-scale slider over 8 depths)
- 04 Observability  — Trace Bottleneck Identifier (3 scenarios, clickable Gantt chart)

## Conventions
- Palette: teal-300 primary, amber-400 accent
- Glyph: ⏣
- Type: Bricolage Grotesque · JetBrains Mono · Manrope
- Severity colors: critical=rose-400, warn=orange-400, mid=amber-400, good=teal

## Series
- Atlas 17 — API Foundations  ( api-atlas.vercel.app )
- Atlas 18 — API Security     ( github.com/denrod25-del/security-atlas )
- Atlas 19 — Production APIs  ( this one )
