/* Section 01 — Caching.
 *
 * Prose + Cache Policy Picker.
 *
 * The picker: 4 scenarios at different points in the cache-policy space
 * (static asset, user-specific API, public HTML, sensitive financial data).
 * For each scenario, 3 candidate Cache-Control configs. Student picks
 * the best one. Reveal explains why the right config is right AND why the
 * wrong configs are wrong for THIS scenario (each wrong config is a real
 * policy that fits a DIFFERENT scenario — teaches the trade-offs).
 *
 * All prose strings use backticks (template literals) to avoid the
 * apostrophe-in-single-quote parse traps from Atlas 18 section 03.
 */

import { useState } from 'react';
import { Sparkles, Check, X, RotateCcw, ArrowRight, Zap, Clock } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Cache Policy Picker quiz
// ───────────────────────────────────────────────────────────────────────

const SCENARIOS = [
  {
    id: 'static-bundle',
    label: 'Static JS bundle',
    context: `A Vite build output with a content hash in the filename: app-x7s9d2e.js. The filename CHANGES whenever the content changes — that is the entire point of the hash. So this exact URL serves the same bytes forever.`,
    options: [
      {
        id: 'A',
        config: `Cache-Control: public, max-age=31536000, immutable`,
        verdict: 'correct',
        why: `One year cache, marked immutable so browsers will not even send conditional revalidation requests. The filename hash guarantees content uniqueness — if the bundle changes, the URL changes — so there is no scenario where the cached version becomes stale. This is the standard pattern for hashed static assets.`,
      },
      {
        id: 'B',
        config: `Cache-Control: no-cache, must-revalidate`,
        verdict: 'wrong',
        why: `no-cache forces a conditional request on every page load. That is the right setting for content that CAN change at a given URL — but a hashed bundle cannot change at a given URL by design. Using no-cache here just wastes a round trip on every request.`,
      },
      {
        id: 'C',
        config: `Cache-Control: public, max-age=60`,
        verdict: 'wrong',
        why: `One minute cache. Misses the point of the hashed filename. Users would re-download a multi-megabyte bundle every minute on a long browsing session — needlessly. Hashed assets get long cache times.`,
      },
    ],
  },
  {
    id: 'user-dashboard',
    label: 'User dashboard API',
    context: `An endpoint /api/me/dashboard returning the current user's stats, recent activity, and personalized recommendations. The data is specific to the logged-in user, changes whenever they take any action in the app, and must never be served to a different user.`,
    options: [
      {
        id: 'A',
        config: `Cache-Control: public, max-age=300`,
        verdict: 'wrong',
        why: `"public" means shared caches (CDNs, corporate proxies) can store the response. That is catastrophic for per-user data — User B requesting the same URL gets User A's dashboard from the cache. Always "private" for user-specific responses.`,
      },
      {
        id: 'B',
        config: `Cache-Control: private, no-cache, must-revalidate`,
        verdict: 'correct',
        why: `"private" forbids shared caches but lets the browser cache. "no-cache" forces revalidation with the server before using the cached copy (despite the name, no-cache does NOT mean "do not cache" — it means "always check first"). Combined with ETag or Last-Modified, this lets browsers skip the body when content has not changed while still always asking.`,
      },
      {
        id: 'C',
        config: `Cache-Control: no-store`,
        verdict: 'wrong',
        why: `no-store is the most restrictive option — nothing is cached anywhere, not even the browser. Correct for sensitive data, overkill for a dashboard. Loses the optimization where ETags can save a round trip when nothing changed. Reserve no-store for actual secrets and financial data.`,
      },
    ],
  },
  {
    id: 'public-homepage',
    label: 'Public homepage HTML',
    context: `The marketing homepage at /. Same content for every visitor. Changes occasionally (new product launch copy, updated testimonials). A few seconds of staleness is acceptable; a 5-minute delay before a homepage update goes live is fine.`,
    options: [
      {
        id: 'A',
        config: `Cache-Control: public, max-age=31536000, immutable`,
        verdict: 'wrong',
        why: `One year cache + immutable means content updates would NEVER reach users until they cleared their browser. For HTML at a stable URL (unlike hashed assets), this is dangerous — you cannot push fixes.`,
      },
      {
        id: 'B',
        config: `Cache-Control: public, max-age=60, stale-while-revalidate=300`,
        verdict: 'correct',
        why: `Cache for 60 seconds, then for the next 5 minutes serve the stale copy IMMEDIATELY while fetching a fresh one in the background. Users see near-instant page loads; updates propagate within minutes. The stale-while-revalidate directive is the secret weapon for "mostly static but occasionally changing" content.`,
      },
      {
        id: 'C',
        config: `Cache-Control: no-cache, no-store`,
        verdict: 'wrong',
        why: `Forces every visitor to hit your origin for every page load. Wastes the value of having a CDN. Reserve this for content that is actually time-sensitive or sensitive — not the marketing homepage.`,
      },
    ],
  },
  {
    id: 'payment-receipt',
    label: 'Payment receipt API',
    context: `An endpoint /api/payments/{id} returning a receipt for a specific charge — payment method (last 4 digits), amount, status. Sensitive financial data. Belongs only to the customer who made the payment.`,
    options: [
      {
        id: 'A',
        config: `Cache-Control: private, max-age=3600`,
        verdict: 'wrong',
        why: `Private prevents shared caching, which is good. But max-age=3600 still allows browsers to cache the receipt for an hour. Sensitive financial data should not sit in browser caches at all — laptop gets lost, the receipt is in cache.`,
      },
      {
        id: 'B',
        config: `Cache-Control: public, max-age=60`,
        verdict: 'wrong',
        why: `Catastrophic. "public" means any shared cache (CDN, ISP, corporate proxy) can store the receipt. Then any other user requesting the same URL might get someone else's payment data. Never use public for personalized content, double never for financial.`,
      },
      {
        id: 'C',
        config: `Cache-Control: no-store`,
        verdict: 'correct',
        why: `The only correct answer for sensitive financial data. no-store tells every layer in the chain — browser, CDN, corporate proxy — not to store this response anywhere. Combined with HTTPS, this ensures the receipt exists only in transit and in the user's current page.`,
      },
    ],
  },
];

function CachePicker() {
  const [idx, setIdx] = useState(0);
  const [picks, setPicks] = useState({});  // { scenarioId: optionId }
  const scenario = SCENARIOS[idx];
  const pick = picks[scenario.id];
  const answered = !!pick;
  const correctCount = SCENARIOS.filter(s => {
    const p = picks[s.id];
    return p && s.options.find(o => o.id === p)?.verdict === 'correct';
  }).length;
  const allDone = Object.keys(picks).length === SCENARIOS.length;

  const choose = (optionId) => {
    if (answered) return;
    setPicks(prev => ({ ...prev, [scenario.id]: optionId }));
  };
  const next = () => { if (idx < SCENARIOS.length - 1) setIdx(idx + 1); };
  const reset = () => { setIdx(0); setPicks({}); };

  return (
    <div className="my-6 border border-teal-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-teal-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-teal-300" />
          <span className="text-teal-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · cache policy picker
          </span>
        </div>
        <div className="flex items-center gap-3 text-[11px] text-zinc-400"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          <span>{correctCount} / {SCENARIOS.length} correct</span>
          <button onClick={reset}
            className="text-zinc-500 hover:text-teal-300 flex items-center gap-1">
            <RotateCcw size={10} /> reset
          </button>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {SCENARIOS.map((s, i) => {
            const p = picks[s.id];
            const result = p ? s.options.find(o => o.id === p)?.verdict : null;
            const isCurrent = i === idx;
            let cls = 'border-zinc-700 text-zinc-400 hover:border-teal-300/50';
            if (result === 'correct')      cls = 'border-teal-300/60 text-teal-200 bg-teal-300/10';
            else if (result === 'wrong')   cls = 'border-rose-400/60 text-rose-300 bg-rose-400/10';
            else if (isCurrent)            cls = 'border-amber-400 bg-amber-400/15 text-amber-200';
            return (
              <button key={s.id} onClick={() => setIdx(i)}
                className={`px-2.5 py-1 border text-[11.5px] transition-colors ${cls}`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {i + 1}. {s.label}
              </button>
            );
          })}
        </div>

        {/* Scenario context */}
        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-1"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            scenario · {scenario.label}
          </div>
          <div className="text-zinc-300 text-[13.5px] leading-relaxed">{scenario.context}</div>
        </div>

        {/* Options */}
        <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          which cache-control header would you set?
        </div>
        <div className="space-y-2 mb-3">
          {scenario.options.map(opt => {
            const isPicked = pick === opt.id;
            const isCorrect = opt.verdict === 'correct';
            let cls = 'border-zinc-700 hover:border-teal-300/50';
            if (answered) {
              if (isCorrect)             cls = 'border-teal-300/70 bg-teal-300/10';
              else if (isPicked)         cls = 'border-rose-400/70 bg-rose-400/10';
              else                       cls = 'border-zinc-800 bg-zinc-900/30 opacity-60';
            }
            return (
              <button key={opt.id} onClick={() => choose(opt.id)} disabled={answered}
                className={`w-full text-left border ${cls} p-3 transition-colors ${!answered ? 'cursor-pointer' : ''}`}>
                <div className="flex items-start gap-3">
                  <div className={`text-[10px] tracking-[0.2em] font-bold px-2 py-0.5 border shrink-0 ${
                    answered && isCorrect ? 'border-teal-300 text-teal-300' :
                    answered && isPicked ? 'border-rose-400 text-rose-400' :
                    'border-zinc-700 text-zinc-400'
                  }`}
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    {opt.id}
                  </div>
                  <pre className="flex-1 text-[12px] text-zinc-200 leading-relaxed overflow-x-auto"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    <code>{opt.config}</code>
                  </pre>
                  {answered && isCorrect && <Check size={14} className="text-teal-300 shrink-0 mt-0.5" strokeWidth={3} />}
                  {answered && isPicked && !isCorrect && <X size={14} className="text-rose-400 shrink-0 mt-0.5" strokeWidth={3} />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Reveal */}
        {answered && (
          <div className="space-y-2 mb-3">
            {scenario.options.map(opt => {
              if (opt.verdict !== 'correct' && opt.id !== pick) return null;
              const isCorrect = opt.verdict === 'correct';
              return (
                <div key={opt.id} className={`border p-3 ${
                  isCorrect ? 'border-teal-300/40 bg-teal-300/5' : 'border-rose-400/40 bg-rose-400/5'
                }`}>
                  <div className={`flex items-center gap-2 mb-1.5 text-[10px] tracking-[0.25em] uppercase font-semibold ${
                    isCorrect ? 'text-teal-300' : 'text-rose-400'
                  }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    {isCorrect ? <Check size={11} strokeWidth={3} /> : <X size={11} strokeWidth={3} />}
                    option {opt.id} · {isCorrect ? 'correct' : 'why this is wrong here'}
                  </div>
                  <div className="text-zinc-200 text-[13.5px] leading-relaxed">{opt.why}</div>
                </div>
              );
            })}

            {idx < SCENARIOS.length - 1 && (
              <button onClick={next}
                className="flex items-center gap-2 px-4 py-2 border border-teal-300 bg-teal-300/10 text-teal-200 hover:bg-teal-300/20 transition-colors text-[12px] tracking-[0.2em] uppercase font-semibold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                next scenario <ArrowRight size={12} />
              </button>
            )}
          </div>
        )}

        {allDone && (
          <div className={`border p-3 ${
            correctCount === SCENARIOS.length
              ? 'border-teal-300 bg-teal-300/10'
              : 'border-amber-400/40 bg-amber-400/5'
          }`}>
            <div className={`text-[11px] tracking-[0.25em] uppercase font-semibold mb-1 ${
              correctCount === SCENARIOS.length ? 'text-teal-300' : 'text-amber-400'
            }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {correctCount === SCENARIOS.length ? '✓ four for four' : `done · ${correctCount}/${SCENARIOS.length}`}
            </div>
            <div className="text-zinc-300 text-[12.5px] leading-relaxed">
              Notice the pattern: each wrong answer is a real cache policy that fits a DIFFERENT
              scenario. There is no universal "best" Cache-Control — the right answer depends entirely
              on what changes, who can see it, and how stale it can get. Build the intuition for each
              dimension and the right header writes itself.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section01_Caching() {
  return (
    <>
      <SectionLabel>section 01</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Caching — making the right responses fast
      </h2>
      <P>
        Every request to your API has a cost — CPU, memory, database connections, downstream service
        calls. Caching is the practice of paying that cost once and reusing the result for subsequent
        callers. Done well, the cache layer absorbs 80-95% of your traffic before it ever touches
        your origin server. Done badly, you serve stale data to wrong users, miss critical updates,
        or wipe out your origin during a cache miss stampede.
      </P>
      <P>
        This section is about the HTTP-level caching every web API uses. Application-level caching
        (Redis, in-memory) is its own art, briefly covered at the end.
      </P>

      <H2 num="◇ 01">Where caches live — the layers</H2>
      <P>
        A single HTTP response can be cached at multiple layers, and they all act independently:
      </P>
      <Code id="cache-layers" lang="text">{`CLIENT                EDGE                ORIGIN
──────                ────                ──────
Browser cache    →    CDN cache       →   Application cache    →   Database
(per user)            (Cloudflare,        (Redis, in-memory)        (the source of truth)
                       Fastly,
                       CloudFront)

EACH LAYER DECIDES INDEPENDENTLY whether to cache a response. Your job is to
tell them with Cache-Control directives. Get the directives wrong and a CDN
serves User A's response to User B, or a browser holds onto stale data after
you have shipped a fix.`}</Code>

      <H2 num="◇ 02">The Cache-Control directives that matter</H2>
      <P>
        The <Kbd>Cache-Control</Kbd> response header is the protocol for telling every layer what it
        can and cannot do. The directives you will use 99% of the time:
      </P>
      <Code id="cc-directives" lang="text">{`DIRECTIVE                  WHAT IT MEANS                                              USED FOR
─────────                  ─────────────                                              ────────
public                     Any cache (browser, CDN, proxy) may store this              Shared content
private                    ONLY the user's browser cache may store this                Per-user data
max-age=N                  Cache for N seconds                                         The base TTL
s-maxage=N                 Cache for N seconds (CDNs/shared caches only)               Longer CDN, shorter browser
no-cache                   Cache, but always revalidate with origin before use         Frequently-changing data
no-store                   Do NOT cache anywhere, period                               Sensitive data
must-revalidate            Once expired, MUST hit origin (no stale serving)            Critical correctness
immutable                  Content WILL NOT change; skip revalidation entirely         Hashed static assets
stale-while-revalidate=N   Serve stale for N seconds while fetching fresh in bg        "Mostly static" content
stale-if-error=N           Serve stale for N seconds if origin returns 5xx             Graceful degradation`}</Code>

      <H2 num="◇ 03">Validators — ETag and Last-Modified</H2>
      <P>
        When a cached response expires, the client (or CDN) can either re-download the full body or
        ask "has this changed since I last saw it?" Validators make that ask possible.
      </P>
      <Code id="etag-flow" lang="http">{`# First request
GET /api/articles/42
→
HTTP/1.1 200 OK
ETag: "v3-9f8e7d"
Cache-Control: private, max-age=60
Content-Length: 8421

{...8421 bytes of article body...}


# 60 seconds later, cache expired — client asks "still v3-9f8e7d?"
GET /api/articles/42
If-None-Match: "v3-9f8e7d"
→
HTTP/1.1 304 Not Modified
ETag: "v3-9f8e7d"


# 8421 bytes saved. Just a 304 header, no body. Browser keeps using its
# cached copy. ETag is just a string — usually a hash of the content or a
# version number. Server generates it; clients echo it back.`}</Code>
      <P>
        <Kbd>Last-Modified</Kbd> + <Kbd>If-Modified-Since</Kbd> works the same way with timestamps
        instead of opaque tokens. Pick one or the other; ETag is more flexible because it handles any
        kind of content change (not just time-based ones).
      </P>

      <H2 num="◇ 04">Cache stampede — and what to do about it</H2>
      <P>
        Imagine an expensive endpoint cached for 5 minutes. The cache expires. The next 10,000
        requests all arrive in the same second. They all miss the cache. They all hit your origin.
        Your origin falls over.
      </P>
      <P>
        This is the cache stampede (sometimes called "thundering herd" or "dogpiling"). Three
        mitigations, in order of complexity:
      </P>
      <ol className="text-zinc-300 text-[15px] leading-relaxed my-3 list-decimal pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-teal-300">stale-while-revalidate.</strong> CDN serves the stale
          response to all 10,000 clients while ONE request goes upstream to refresh. The simplest
          fix; works at the HTTP layer.
        </li>
        <li>
          <strong className="text-teal-300">Locking at the application cache.</strong> When the
          cache misses, acquire a lock. Only the first request actually computes the value; the others
          wait briefly, see the cache is now populated, and return the cached result. Works at the
          Redis layer (SET NX EX, then poll).
        </li>
        <li>
          <strong className="text-teal-300">Probabilistic early refresh.</strong> Before the cache
          expires, each request has a small (and increasing) probability of refreshing it. By the
          time it actually expires, it has usually been refreshed already by some prior request. No
          stampede possible. (See: XFetch algorithm.)
        </li>
      </ol>
      <Callout kind="jolt" title="STAMPEDE IS A PRODUCTION-ONLY BUG">
        Cache stampede does not show up in dev or staging. It manifests at scale, after a deploy that
        clears caches, or after a slow upstream causes a coordinated cache eviction. The bug is
        invisible until your origin dies. Build the mitigation BEFORE you see the failure.
      </Callout>

      <H2 num="◇ 05">Vary — the header that prevents the wrong-user disaster</H2>
      <P>
        If your API serves different responses based on a request header (Accept-Language,
        Authorization, Accept-Encoding for gzip), caches need to know — otherwise the cache key is
        just the URL, and the cache will serve the wrong language to half your users.
      </P>
      <Code id="vary-example" lang="http">{`HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: public, max-age=300
Vary: Accept-Language, Accept-Encoding

# Now the cache key is URL + Accept-Language + Accept-Encoding combined.
# Requests with different language preferences are cached separately.
# Without the Vary header, the first-cached version wins for all subsequent
# callers regardless of their preferences — visible as "why am I seeing the
# English page when I requested Spanish?"`}</Code>
      <Callout kind="warn" title="VARY HAS COSTS">
        Every value in Vary multiplies the cache key space. Vary on Authorization means every user
        gets their own cache entry — at which point your CDN is mostly cache-missing. For per-user
        responses, prefer <Kbd>private, no-cache</Kbd> (only the user's browser caches it) over
        <Kbd>public</Kbd> with <Kbd>Vary: Authorization</Kbd>.
      </Callout>

      <H2 num="◇ 06">Cache invalidation — the second-hardest problem in CS</H2>
      <P>
        Phil Karlton's quote — "There are only two hard things in computer science: cache invalidation
        and naming things" — exists for a reason. Some patterns that actually work:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-teal-300">Content-hashed URLs.</strong> If the content changes, the
          URL changes. No invalidation needed — the old URL just stops being requested. Standard for
          static assets; sometimes applicable to API responses too via versioned URLs.
        </li>
        <li>
          <strong className="text-teal-300">Short TTLs.</strong> Cache for 60 seconds; tolerate up to
          60 seconds of staleness. For most content this is fine. Eliminates the question.
        </li>
        <li>
          <strong className="text-teal-300">Surrogate keys + targeted purges.</strong> Tag each
          cached response with one or more keys (user_id, article_id, tenant_id). On a data change,
          purge all entries tagged with that key. Cloudflare, Fastly, and Varnish all support this.
        </li>
        <li>
          <strong className="text-teal-300">Versioning in the URL.</strong> Every breaking change
          gets a new path or query param. Easy; loses you cache hits across versions; works.
        </li>
      </ul>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 07">Pick the right cache policy for the scenario</H2>
      <P>
        Four scenarios across the cache-policy spectrum: from "cache for a year, never check" through
        "do not store anywhere, ever." Three candidate Cache-Control configs per scenario. Two are
        wrong for THIS scenario — but each wrong answer is a real, valid policy for SOME other
        scenario. Pick the right one; the reveal explains why the wrong ones are wrong here.
      </P>

      <CachePicker />

      <H2 num="◇ 08">Application-level caching — the layer below HTTP</H2>
      <P>
        HTTP caching handles "the same URL returns the same response." Application-level caching
        handles "the same computation returns the same answer." Common shape: cache the result of an
        expensive database query in Redis, keyed by the inputs.
      </P>
      <Code id="redis-cache" lang="python">{`def get_user_dashboard(user_id):
    cache_key = f"dashboard:{user_id}"
    cached = redis.get(cache_key)
    if cached:
        return json.loads(cached)

    # Cache miss — compute it
    dashboard = compute_expensive_dashboard(user_id)
    redis.setex(cache_key, 300, json.dumps(dashboard))  # 5 min TTL
    return dashboard


# Invalidation: when the user does something that affects their dashboard,
# invalidate the cache so the next read recomputes.
def update_user_stat(user_id, stat, value):
    db.update_stat(user_id, stat, value)
    redis.delete(f"dashboard:{user_id}")  # next read recomputes`}</Code>
      <P>
        Same questions apply: who can see this? when does it become stale? what is the invalidation
        plan? The biggest application-cache bug in real systems is forgetting to invalidate on write,
        so reads return stale data forever (or until TTL expires).
      </P>

      <H2 num="◇ 09">Hardening checklist for caching</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Cache-Control set on every response — never rely on cache defaults</li>
        <li>✓ "public" only for content that is safe to share across users</li>
        <li>✓ "private" for personalized responses; "no-store" for sensitive data</li>
        <li>✓ ETags on responses where conditional revalidation saves bandwidth</li>
        <li>✓ Stale-while-revalidate on "mostly static" content to mask cache misses</li>
        <li>✓ Vary on any header that changes the response shape</li>
        <li>✓ Stampede mitigation in place BEFORE the first production incident</li>
        <li>✓ Invalidation plan for every cached resource — TTL is the simplest version</li>
        <li>✓ Monitoring on cache hit rate per endpoint; alert on regression</li>
        <li>✓ Sensitive data (auth tokens, financial info) NEVER cached at any layer</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Caching makes the right responses fast. Section 02 covers what happens when the network
        fails partway through a request — idempotency, the practice of making operations safe to
        retry without breaking things twice.
      </Callout>
    </>
  );
}
