/* Section 03 — Pagination.
 *
 * Prose + Pagination Performance Comparator.
 *
 * The comparator: logarithmic slider for page depth (10 rows to 100M).
 * Two side-by-side bar charts showing simulated query time for OFFSET
 * pagination vs cursor pagination at that depth. Status badge shows
 * where each falls on the latency spectrum (instant / noticeable /
 * slow / timeout risk / completely broken).
 *
 * The dramatic visualization is the lesson: at depth=100 both look fine;
 * at depth=1M offset hits multi-second territory; at depth=100M offset
 * would take minutes. Cursor stays at ~10ms regardless.
 *
 * All prose strings use backticks (template literals) to avoid the
 * apostrophe-in-single-quote parse traps from Atlas 18 section 03.
 */

import { useState, useMemo } from 'react';
import { Sparkles, Gauge, Zap, AlertTriangle } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Pagination Performance Comparator
// ───────────────────────────────────────────────────────────────────────

// Discrete depths — snapped values across the log range
const DEPTHS = [10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000];

function formatDepth(n) {
  if (n >= 1e6) return `${(n / 1e6).toString().replace(/\.0$/, '')}M`;
  if (n >= 1e3) return `${(n / 1e3).toString().replace(/\.0$/, '')}K`;
  return String(n);
}

function formatTime(ms) {
  if (ms < 1) return `<1ms`;
  if (ms < 1000) return `${Math.round(ms)}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60000).toFixed(1)}m`;
}

// Status thresholds for query latency
function statusFor(ms) {
  if (ms < 100)    return { label: 'instant',       tone: 'good',    desc: `Imperceptible to the user.` };
  if (ms < 1000)   return { label: 'noticeable',    tone: 'mid',     desc: `Users start to notice the lag.` };
  if (ms < 10000)  return { label: 'slow',          tone: 'warn',    desc: `Users abandon the page.` };
  if (ms < 60000)  return { label: 'timeout risk',  tone: 'bad',     desc: `API gateways return 504 around 30s. Most clients give up.` };
  return                  { label: 'broken',         tone: 'bad',     desc: `This query will not complete inside any reasonable timeout.` };
}

const TONE_STYLES = {
  good: { bar: 'bg-teal-400',   text: 'text-teal-300',   border: 'border-teal-300/40' },
  mid:  { bar: 'bg-amber-400',  text: 'text-amber-300',  border: 'border-amber-400/40' },
  warn: { bar: 'bg-orange-400', text: 'text-orange-300', border: 'border-orange-400/40' },
  bad:  { bar: 'bg-rose-400',   text: 'text-rose-300',   border: 'border-rose-400/50' },
};

function PerformanceComparator() {
  const [idx, setIdx] = useState(2);  // depth = 1000 by default
  const depth = DEPTHS[idx];

  // Simulated timings — these are rough approximations of real PostgreSQL behavior:
  //   OFFSET: linear scan past offset rows. ~10ms base + ~10ns per row scanned.
  //   CURSOR with index: ~10ms regardless of depth (B-tree seek is O(log n) but small).
  const offsetMs = 10 + depth * 0.01;
  const cursorMs = 10 + Math.log10(Math.max(depth, 10)) * 0.5;  // tiny log-scale variation
  const offsetStatus = statusFor(offsetMs);
  const cursorStatus = statusFor(cursorMs);

  // Bar widths — scale relative to the larger of the two, so the visual
  // contrast is dramatic as offset balloons.
  const maxMs = Math.max(offsetMs, cursorMs, 50);
  const offsetWidth = (offsetMs / maxMs) * 100;
  const cursorWidth = (cursorMs / maxMs) * 100;

  const offsetTone = TONE_STYLES[offsetStatus.tone];
  const cursorTone = TONE_STYLES[cursorStatus.tone];

  // SQL preview values
  const pageSize = 10;
  const offsetValue = depth - pageSize;  // skip ahead
  const cursorValue = depth;             // pretend the last-seen id was this number

  return (
    <div className="my-6 border border-teal-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-teal-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-teal-300" />
          <span className="text-teal-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · pagination performance comparator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Depth slider */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-2">
            <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              how deep into the data?
            </div>
            <div className="flex items-center gap-2">
              <Gauge size={13} className="text-teal-300" />
              <span className="text-teal-300 text-[14px] font-semibold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {formatDepth(depth)} rows in
              </span>
            </div>
          </div>
          <input
            type="range"
            min={0}
            max={DEPTHS.length - 1}
            value={idx}
            onChange={(e) => setIdx(parseInt(e.target.value, 10))}
            className="w-full accent-teal-300"
          />
          <div className="flex justify-between text-zinc-600 text-[10px] mt-1"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            {DEPTHS.map(d => <span key={d}>{formatDepth(d)}</span>)}
          </div>
        </div>

        {/* Two-bar comparison */}
        <div className="grid md:grid-cols-2 gap-3 mb-4">
          {/* OFFSET pagination */}
          <div className={`border ${offsetTone.border} bg-zinc-950/40 p-3`}>
            <div className="flex items-center justify-between mb-2">
              <div className="text-zinc-300 text-[12px] font-semibold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                OFFSET pagination
              </div>
              <div className={`text-[10px] tracking-[0.2em] uppercase font-semibold ${offsetTone.text}`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {offsetStatus.label}
              </div>
            </div>
            <div className="mb-2">
              <pre className="bg-zinc-950/80 border border-zinc-800 p-2 text-[10.5px] text-zinc-300 overflow-x-auto leading-relaxed"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
{`SELECT * FROM orders
ORDER BY id
LIMIT ${pageSize}
OFFSET ${offsetValue.toLocaleString()};`}
              </pre>
            </div>
            <div className="bg-zinc-800 h-7 relative border border-zinc-700">
              <div className={`h-full ${offsetTone.bar} transition-all duration-300`}
                style={{ width: `${offsetWidth}%` }} />
              <div className="absolute inset-0 flex items-center justify-end pr-2">
                <span className="text-zinc-100 text-[12px] font-semibold drop-shadow"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {formatTime(offsetMs)}
                </span>
              </div>
            </div>
            <div className={`text-[11px] mt-1.5 italic ${offsetTone.text}`}>
              {offsetStatus.desc}
            </div>
          </div>

          {/* CURSOR pagination */}
          <div className={`border ${cursorTone.border} bg-zinc-950/40 p-3`}>
            <div className="flex items-center justify-between mb-2">
              <div className="text-zinc-300 text-[12px] font-semibold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                CURSOR pagination
              </div>
              <div className={`text-[10px] tracking-[0.2em] uppercase font-semibold ${cursorTone.text}`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {cursorStatus.label}
              </div>
            </div>
            <div className="mb-2">
              <pre className="bg-zinc-950/80 border border-zinc-800 p-2 text-[10.5px] text-zinc-300 overflow-x-auto leading-relaxed"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
{`SELECT * FROM orders
WHERE id > ${cursorValue.toLocaleString()}
ORDER BY id
LIMIT ${pageSize};`}
              </pre>
            </div>
            <div className="bg-zinc-800 h-7 relative border border-zinc-700">
              <div className={`h-full ${cursorTone.bar} transition-all duration-300`}
                style={{ width: `${cursorWidth}%` }} />
              <div className="absolute inset-0 flex items-center justify-end pr-2">
                <span className="text-zinc-100 text-[12px] font-semibold drop-shadow"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {formatTime(cursorMs)}
                </span>
              </div>
            </div>
            <div className={`text-[11px] mt-1.5 italic ${cursorTone.text}`}>
              {cursorStatus.desc}
            </div>
          </div>
        </div>

        {/* Ratio callout */}
        <div className="border border-zinc-800 bg-zinc-900/40 p-3">
          <div className="flex items-center gap-2 text-[12.5px] flex-wrap">
            <span className="text-zinc-500"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              at this depth:
            </span>
            <span className="text-zinc-200">offset is</span>
            <span className={`font-bold ${offsetMs / cursorMs > 100 ? 'text-rose-400' : offsetMs / cursorMs > 10 ? 'text-orange-300' : offsetMs / cursorMs > 2 ? 'text-amber-300' : 'text-teal-300'}`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {(offsetMs / cursorMs).toFixed(offsetMs / cursorMs < 10 ? 1 : 0)}×
            </span>
            <span className="text-zinc-200">slower than cursor.</span>
            {offsetMs / cursorMs >= 1000 && (
              <span className="text-rose-400 text-[11px] tracking-[0.2em] uppercase font-semibold ml-2"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                ⚠ catastrophic
              </span>
            )}
          </div>
          <div className="text-zinc-400 text-[12px] mt-1 leading-relaxed">
            Move the slider. Notice that at small depths the difference is irrelevant — but offset
            grows linearly with how deep into the data you go, while cursor stays constant. By
            page 100,000 of small results, offset queries are timing out.
          </div>
        </div>

        {/* Real-world note */}
        <div className="border border-amber-400/30 bg-amber-400/5 p-3 mt-3">
          <div className="text-amber-400 text-[10px] tracking-[0.25em] uppercase font-semibold mb-1"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            note on the numbers
          </div>
          <div className="text-zinc-300 text-[12px] leading-relaxed">
            Simulated. Real query times depend on indexes, hardware, row width, cache state, and
            concurrent load. The SHAPE is accurate though — offset is O(n) in the offset value,
            cursor is essentially O(1) with a proper index. The ratio you see at 1M+ rows is real;
            anyone who has paginated past page 10,000 in production has felt this curve.
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section03_Pagination() {
  return (
    <>
      <SectionLabel>section 03</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Pagination — handing back big datasets without dying
      </h2>
      <P>
        At small scale, pagination feels like a UX decision: how many results per page? At large
        scale, it becomes a survival decision: how do we let users walk through 10 million orders
        without freezing the database every time they click "next page"? The two natural answers
        to "how do I paginate" produce wildly different results at scale. The interactive below
        shows the difference dramatically.
      </P>

      <H2 num="◇ 01">Why pagination exists</H2>
      <P>
        An API endpoint returning all matching rows works fine on day one and breaks silently as
        the data grows. By the time it returns 100,000 rows on every request, you have one or
        more of:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1 max-w-prose">
        <li>Out-of-memory errors on the API server</li>
        <li>Browser tabs that lock up trying to render the response</li>
        <li>Database connections held open long enough to exhaust the pool</li>
        <li>Multi-megabyte responses that crush mobile clients</li>
        <li>Gateway timeouts (504) when the response cannot be assembled in time</li>
      </ul>
      <P>
        Pagination caps the per-request blast radius. Every endpoint that returns a list — every
        single one — needs pagination from day one. Adding it later means breaking every existing
        client.
      </P>

      <H2 num="◇ 02">The naive approach — LIMIT and OFFSET</H2>
      <P>
        The first thing every API developer reaches for:
      </P>
      <Code id="offset-pagination" lang="sql">{`-- Page 1 (rows 1-10)
SELECT * FROM orders ORDER BY id LIMIT 10 OFFSET 0;

-- Page 2 (rows 11-20)
SELECT * FROM orders ORDER BY id LIMIT 10 OFFSET 10;

-- Page 100 (rows 991-1000)
SELECT * FROM orders ORDER BY id LIMIT 10 OFFSET 990;`}</Code>
      <P>
        Works perfectly until the data gets large. Then two problems show up at the same time.
      </P>

      <H2 num="◇ 03">Why offset dies at scale — the linear scan</H2>
      <P>
        Here is what <Kbd>OFFSET 990</Kbd> actually does in PostgreSQL (and most databases):
      </P>
      <Code id="offset-explain" lang="text">{`EXPLAIN ANALYZE
SELECT * FROM orders ORDER BY id LIMIT 10 OFFSET 1000000;

                                  QUERY PLAN
─────────────────────────────────────────────────────────────────────
 Limit  (cost=80442.18..80442.99 rows=10 width=240)
        (actual time=8923.471..8923.482 rows=10 loops=1)
   ->  Index Scan using orders_pkey on orders
            (cost=0.43..8045031.42 rows=10000000 width=240)
            (actual time=0.025..8922.108 rows=1000010 loops=1)
                                                       ↑
                              SCANNED ONE MILLION TEN ROWS TO RETURN TEN

 Planning Time: 0.082 ms
 Execution Time: 8923.502 ms     ← almost 9 seconds for ONE PAGE`}</Code>
      <P>
        OFFSET 1,000,000 means "scan past one million rows, then start returning." The database
        does not have a magic way to skip ahead — it walks the index from the start, counting as
        it goes, then returns rows after the count exceeds the offset value. The cost is linear in
        the offset value: deeper pages take proportionally longer to fetch.
      </P>
      <Callout kind="jolt" title="THE SECOND PROBLEM — INCONSISTENT RESULTS">
        Imagine the user is reading page 50 (rows 491-500). Between page 50 and page 51, a new
        order is inserted at the top. Now what was row 500 is row 501; their next-page fetch
        returns rows starting from row 501 — and they SKIP the row that used to be on page 51.
        Or, if a row is deleted, they see a row TWICE. Offset pagination cannot give a stable
        view of a changing dataset.
      </Callout>

      <H2 num="◇ 04">Cursor pagination — the right answer at scale</H2>
      <P>
        Instead of "skip 990 rows then give me 10," ask "give me 10 rows AFTER this specific row."
        The "this specific row" is the cursor.
      </P>
      <Code id="cursor-pagination" lang="sql">{`-- Page 1 — no cursor, just first 10
SELECT * FROM orders ORDER BY id LIMIT 10;
-- (returns rows with ids 1..10, say)

-- Page 2 — cursor is the last id from page 1
SELECT * FROM orders WHERE id > 10 ORDER BY id LIMIT 10;
-- (returns ids 11..20)

-- Page 100 — cursor is the last id from page 99
SELECT * FROM orders WHERE id > 990 ORDER BY id LIMIT 10;
-- (returns ids 991..1000)`}</Code>
      <P>
        Why this is fast: the database uses the index on <Kbd>id</Kbd> to jump directly to the
        first row with <Kbd>id &gt; 990</Kbd>, then reads 10 rows. The time is independent of how
        deep into the data you are. <Kbd>WHERE id &gt; 1_000_000</Kbd> is just as fast as{' '}
        <Kbd>WHERE id &gt; 10</Kbd>.
      </P>

      <H2 num="◇ 05">Building stable cursors — the tie-breaker problem</H2>
      <P>
        The simple cursor pattern above works because we sort by <Kbd>id</Kbd> and IDs are unique
        — every row has a different one, so <Kbd>WHERE id &gt; X</Kbd> deterministically picks up
        where we left off. But what about sorting by <Kbd>created_at</Kbd>? Two rows can have
        the exact same timestamp. The cursor would miss or duplicate at the boundary.
      </P>
      <Code id="composite-cursor" lang="sql">{`-- Two rows with identical created_at — cursor on created_at alone breaks

-- Order rows by created_at, but break ties with id (which IS unique)
SELECT * FROM orders
ORDER BY created_at ASC, id ASC
LIMIT 10;

-- Cursor for page 2: (last_created_at, last_id) — both values needed
SELECT * FROM orders
WHERE (created_at, id) > ('2026-06-08 12:34:56'::timestamp, 4242)
ORDER BY created_at ASC, id ASC
LIMIT 10;

-- The tuple comparison "(a, b) > (x, y)" handles ties correctly:
--   created_at > x  →  include
--   created_at = x AND id > y  →  include
--   otherwise  →  skip`}</Code>
      <P>
        The pattern: every cursor must include enough fields to uniquely identify "where I am in
        the result set." Whatever you sort by, plus a tie-breaker (typically the primary key).
        Encode the cursor as an opaque base64 string before sending to clients — that way they
        cannot construct invalid cursors and you can change the internal format later.
      </P>

      <H2 num="◇ 06">The total-count problem</H2>
      <P>
        Many APIs return pagination metadata like "page 5 of 1,247." Computing that total count
        requires the database to count every matching row — which on a large table can take longer
        than the actual query for the page.
      </P>
      <Code id="count-cost" lang="text">{`-- This looks innocent. It is not.
SELECT COUNT(*) FROM orders WHERE status = 'pending';

-- On a table with 10M orders, even with an index on status, this takes
-- 5-30 seconds depending on how much of "pending" is in cache.
-- And it runs on EVERY page request if you display "page X of Y".`}</Code>
      <P>
        Pragmatic alternatives that real APIs use:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-teal-300">Do not show the total.</strong> Show "Next page" / "Previous page" buttons and a <Kbd>has_more</Kbd> flag. Twitter, GitHub, Stripe all do this. The user does not actually need to know there are 47,832 results.
        </li>
        <li>
          <strong className="text-teal-300">Show an approximate count.</strong> "About 50,000 results." Postgres has <Kbd>reltuples</Kbd> in pg_class — instant estimate; updated by ANALYZE.
        </li>
        <li>
          <strong className="text-teal-300">Show "X+" beyond a threshold.</strong> "Showing 1-10 of 1000+ results." Run a fast bounded count: <Kbd>SELECT COUNT(*) FROM (SELECT 1 FROM orders WHERE status = &apos;pending&apos; LIMIT 1001) AS t</Kbd> — cheap, gives you the indicator.
        </li>
      </ul>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 07">Watch offset and cursor diverge as you go deeper</H2>
      <P>
        The slider goes from page depth 10 (basically zero data) all the way to 100 million rows
        in. At every step, the simulated query time for OFFSET pagination is plotted against the
        time for cursor pagination. Watch when each one crosses the "users abandon the page"
        threshold — and when offset crosses the "this query cannot complete" line.
      </P>

      <PerformanceComparator />

      <H2 num="◇ 08">API design for cursor pagination</H2>
      <P>
        How real APIs expose cursor pagination to clients:
      </P>
      <Code id="api-cursor-response" lang="json">{`// GET /api/orders?limit=10
{
  "data": [
    { "id": 1001, "amount": 50, "created_at": "..." },
    { "id": 1002, "amount": 75, "created_at": "..." },
    ...
  ],
  "pagination": {
    "next_cursor": "eyJpZCI6MTAxMH0=",   // base64 of {"id":1010}
    "has_more": true
  }
}

// Client paginates by passing the cursor back:
// GET /api/orders?limit=10&cursor=eyJpZCI6MTAxMH0=`}</Code>
      <P>
        Pattern notes:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>The cursor is opaque to the client — they store and return it, never parse it. This lets you change cursor format without breaking clients.</li>
        <li><Kbd>has_more</Kbd> rather than <Kbd>total_pages</Kbd>. Cheap to compute (just check if we got <Kbd>limit + 1</Kbd> rows; return the first <Kbd>limit</Kbd>).</li>
        <li>Always include the sort order in the response so the client can build a reverse cursor for backward pagination if needed.</li>
        <li>For very large APIs, consider returning <Kbd>Link</Kbd> headers per RFC 5988: <Kbd>Link: &lt;...?cursor=X&gt;; rel="next"</Kbd>.</li>
      </ul>

      <H2 num="◇ 09">Pagination + filtering + sorting — the combinatorial problem</H2>
      <P>
        Real APIs do not just paginate; they let clients filter and sort the data first. That
        triples the complexity. The cursor must encode the FULL sort key — not just the last id,
        but the last value of every sort field.
      </P>
      <Code id="filter-sort-cursor" lang="sql">{`-- A user sorts by amount DESC, filters by status
-- GET /api/orders?status=pending&sort=amount&order=desc&limit=10

SELECT * FROM orders
WHERE status = 'pending'
  AND (amount, id) < ($last_amount, $last_id)   -- compound cursor, descending
ORDER BY amount DESC, id DESC
LIMIT 10;

-- Index needed: CREATE INDEX ON orders (status, amount DESC, id DESC);
-- Without that composite index, the query falls back to a sort + scan.`}</Code>
      <Callout kind="warn" title="THE INDEX MATCHES THE SORT, ALWAYS">
        Every supported sort order needs a matching index. If you let users sort by 5 different
        fields, you need 5 indexes (or 5 composite indexes including the common filter fields).
        Sort orders without index support do FULL TABLE SCANS — fine on dev data, deadly on
        production. Limit the supported sort orders to what your indexes cover. "Sort by anything"
        is an anti-pattern.
      </Callout>

      <H2 num="◇ 10">Common pagination mistakes</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-rose-400">No ORDER BY.</strong> Without explicit ordering, the
          database returns rows in whatever order is convenient — and that order can change between
          queries. Pagination silently produces inconsistent results. ALWAYS specify ORDER BY when
          paginating.
        </li>
        <li>
          <strong className="text-rose-400">ORDER BY a non-unique column without a tie-breaker.</strong>{' '}
          Sorting by created_at alone misses rows at timestamp boundaries. Always include the primary key as a tie-breaker.
        </li>
        <li>
          <strong className="text-rose-400">Letting clients pick the page size unbounded.</strong>{' '}
          <Kbd>?limit=100000</Kbd> bypasses the whole point of pagination. Always enforce a max — 100 is typical.
        </li>
        <li>
          <strong className="text-rose-400">Counting on every page request.</strong>{' '}
          <Kbd>COUNT(*)</Kbd> is expensive. Compute it once and cache it, or use the "Next" / "Previous" pattern with no total count.
        </li>
        <li>
          <strong className="text-rose-400">Putting raw cursors (like the last id) in the URL.</strong>{' '}
          Lets clients craft cursors that point at data they should not see. Use opaque tokens — base64-encoded JSON works fine, or signed tokens if you want tamper-proofing.
        </li>
      </ul>

      <H2 num="◇ 11">Hardening checklist for pagination</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Every list endpoint paginates from day one — never "return everything"</li>
        <li>✓ Cursor pagination for any dataset that might grow beyond ~10K rows</li>
        <li>✓ Stable ORDER BY on every paginated query (sort field + primary key tie-breaker)</li>
        <li>✓ Page size capped server-side (e.g. <Kbd>min(client_limit, 100)</Kbd>)</li>
        <li>✓ Opaque cursors (base64 or signed) — never expose raw IDs</li>
        <li>✓ has_more flag instead of total count where possible</li>
        <li>✓ Composite indexes matching every supported sort order</li>
        <li>✓ Supported sort orders enumerated explicitly — not "any field"</li>
        <li>✓ Documentation explains how to paginate forward, backward, and from-the-start</li>
        <li>✓ Default pagination behavior tested with millions of rows in staging, not just dev seed data</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Section 04 closes the atlas and the whole 3-atlas API series: observability — the discipline
        of knowing what your API is doing while it does it. Logs, metrics, traces, and the patterns
        that turn "production has a bug somewhere" into "the bug is in span B at request 4f9e."
      </Callout>
    </>
  );
}
