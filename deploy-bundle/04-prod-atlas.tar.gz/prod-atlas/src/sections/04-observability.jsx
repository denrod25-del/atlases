/* Section 04 — Observability. Closing section.
 *
 * Prose + Trace Bottleneck Identifier.
 *
 * The interactive: Gantt-style distributed trace across three scenarios.
 *   1. Slow database query — one span dominates (79% of total)
 *   2. Slow external API — payment provider call dominates
 *   3. N+1 query problem — many small spans, the PATTERN is the bottleneck
 *
 * Student clicks the span they think is the bottleneck. Right span → reveal
 * with analysis + fix. Wrong span → hint ("only X% of total"). For N+1,
 * clicking any cluster span triggers the pattern-recognition reveal.
 *
 * Closes with the atlas-wide and series-wide wrap pointing to what comes
 * next in the B. Symbolic atlas series.
 *
 * All prose strings use backticks to avoid the apostrophe-in-single-quote
 * parse traps from Atlas 18 section 03.
 */

import { useState } from 'react';
import { Sparkles, Check, X, RotateCcw, Activity, Database, Cloud, Mail, ShoppingCart, BarChart3 } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Trace Bottleneck Identifier
// ───────────────────────────────────────────────────────────────────────

// Service color mapping — each service gets a consistent color across spans
const SERVICE_COLORS = {
  'api-gateway':         'bg-teal-400',
  'cart-service':        'bg-amber-400',
  'orders-service':      'bg-amber-400',
  'inventory-service':   'bg-violet-400',
  'payment-service':     'bg-rose-400',
  'notification-service':'bg-cyan-400',
  'postgres':            'bg-zinc-400',
  'stripe-api':          'bg-rose-400',
};
const SERVICE_BORDERS = {
  'api-gateway':         'border-teal-400',
  'cart-service':        'border-amber-400',
  'orders-service':      'border-amber-400',
  'inventory-service':   'border-violet-400',
  'payment-service':     'border-rose-400',
  'notification-service':'border-cyan-400',
  'postgres':            'border-zinc-400',
  'stripe-api':          'border-rose-400',
};

// Build N+1 cluster spans programmatically — 20 customer lookups representing 50
const N1_CLUSTER_COUNT = 20;
const N1_PER_QUERY_MS = 13;
const N1_CLUSTER_START = 45;
const buildN1Cluster = () => Array.from({ length: N1_CLUSTER_COUNT }, (_, i) => ({
  id: `customer_${i}`,
  name: i === 0 ? `SELECT * FROM customers WHERE id = $1` : (i === N1_CLUSTER_COUNT - 1 ? `(20 of 50 shown)` : ``),
  service: 'postgres',
  start: N1_CLUSTER_START + i * (N1_PER_QUERY_MS + 1),
  duration: N1_PER_QUERY_MS,
  depth: 2,
  isCluster: true,
}));

const SCENARIOS = [
  {
    id: 'slow-db',
    label: 'Slow DB query',
    description: `A POST /checkout request flowing through six services. One operation is dominating the latency. Click around to find it.`,
    totalMs: 1240,
    spans: [
      { id: 'root',         name: `POST /checkout`,                    service: 'api-gateway',          start: 0,    duration: 1240, depth: 0 },
      { id: 'validate',     name: `validate_input`,                    service: 'api-gateway',          start: 3,    duration: 6,    depth: 1 },
      { id: 'load_cart',    name: `load_cart`,                         service: 'cart-service',         start: 12,   duration: 28,   depth: 1 },
      { id: 'cart_db',      name: `SELECT cart_items WHERE user_id`,   service: 'postgres',             start: 18,   duration: 18,   depth: 2 },
      { id: 'inventory',    name: `check_inventory`,                   service: 'inventory-service',    start: 45,   duration: 1080, depth: 1 },
      { id: 'inv_db',       name: `SELECT FROM inventory (no index)`,  service: 'postgres',             start: 52,   duration: 1065, depth: 2 },
      { id: 'create',       name: `create_order`,                      service: 'orders-service',       start: 1130, duration: 55,   depth: 1 },
      { id: 'order_db',     name: `INSERT INTO orders`,                service: 'postgres',             start: 1140, duration: 35,   depth: 2 },
      { id: 'email',        name: `send_receipt_email`,                service: 'notification-service', start: 1190, duration: 45,   depth: 1 },
    ],
    bottleneckId: 'inv_db',
    analysis: `The inventory SELECT takes 1065ms — 86% of the total request. Drilling in: the inventory table has no usable index for the query's WHERE clause. PostgreSQL falls back to a sequential scan over millions of rows. The fix is a composite index matching the query: CREATE INDEX inventory_sku_loc_idx ON inventory (sku, location_id). Query time drops to under 5ms. Total request goes from 1240ms to ~180ms.`,
    fix: `CREATE INDEX CONCURRENTLY inventory_sku_loc_idx
  ON inventory (sku, location_id);`,
  },
  {
    id: 'slow-external',
    label: 'Slow external API',
    description: `Same /checkout, different production day. The internal services are fast — but one external call is hanging.`,
    totalMs: 1450,
    spans: [
      { id: 'root',         name: `POST /checkout`,                    service: 'api-gateway',          start: 0,    duration: 1450, depth: 0 },
      { id: 'validate',     name: `validate_input`,                    service: 'api-gateway',          start: 3,    duration: 6,    depth: 1 },
      { id: 'load_cart',    name: `load_cart`,                         service: 'cart-service',         start: 12,   duration: 28,   depth: 1 },
      { id: 'inventory',    name: `check_inventory`,                   service: 'inventory-service',    start: 45,   duration: 35,   depth: 1 },
      { id: 'payment',      name: `process_payment`,                   service: 'payment-service',      start: 85,   duration: 1280, depth: 1 },
      { id: 'stripe',       name: `POST stripe.com/v1/charges`,        service: 'stripe-api',           start: 92,   duration: 1265, depth: 2 },
      { id: 'create',       name: `create_order`,                      service: 'orders-service',       start: 1370, duration: 35,   depth: 1 },
      { id: 'email',        name: `send_receipt_email`,                service: 'notification-service', start: 1410, duration: 35,   depth: 1 },
    ],
    bottleneckId: 'stripe',
    analysis: `The Stripe charge call takes 1265ms — 87% of the total. This time the bottleneck is outside your infrastructure entirely. You cannot make Stripe faster, but you can change how you wait. The fix is asynchronous: accept the order, return 202 Accepted immediately, kick off the charge in a background worker, notify the user when it completes. Total perceived response time drops to ~100ms even if Stripe stays slow.`,
    fix: `# Sync (slow):
charge = stripe.Charge.create(...)         # blocks 1.2s
return {"status": "ok", "charge_id": charge.id}

# Async (fast):
job_id = enqueue_charge_job(order_id, ...)  # ~5ms
return {"status": "processing", "job_id": job_id}, 202
# Client polls / receives webhook when charge completes`,
  },
  {
    id: 'n-plus-one',
    label: 'N+1 query problem',
    description: `A GET /orders endpoint listing 50 recent orders with their customer info. Total time is high. Look at the SHAPE of the trace, not just any individual span.`,
    totalMs: 360,
    spans: [
      { id: 'root',       name: `GET /orders`,                       service: 'api-gateway',     start: 0,   duration: 360, depth: 0 },
      { id: 'load',       name: `load_orders_with_customers`,        service: 'orders-service',  start: 3,   duration: 340, depth: 1 },
      { id: 'main_query', name: `SELECT * FROM orders LIMIT 50`,     service: 'postgres',        start: 8,   duration: 32,  depth: 2 },
      ...buildN1Cluster(),
      { id: 'serialize',  name: `serialize_response`,                service: 'orders-service',  start: 340, duration: 18,  depth: 1 },
    ],
    bottleneckId: 'pattern',  // any cluster span counts
    analysis: `Look at the trace shape — the cluster of 50 small queries between t=45ms and t=325ms. Each individual customer lookup takes only 13ms. Fast! But they execute sequentially, totaling ~280ms — 78% of the request. This is the N+1 query problem: 1 query to load orders, then N queries (one per row) to load related data. The fix is to fetch all customers in ONE query.`,
    fix: `# Bad — N+1 queries
orders = db.query("SELECT * FROM orders LIMIT 50")
for order in orders:
    order.customer = db.query("SELECT * FROM customers WHERE id = $1",
                              order.customer_id)
# 1 + 50 = 51 queries

# Good — 2 queries total via IN clause
orders = db.query("SELECT * FROM orders LIMIT 50")
customer_ids = [o.customer_id for o in orders]
customers = db.query("SELECT * FROM customers WHERE id = ANY($1)",
                     customer_ids)
customers_by_id = {c.id: c for c in customers}
for order in orders:
    order.customer = customers_by_id[order.customer_id]
# 2 queries total — regardless of how many orders`,
  },
];

function TraceViewer() {
  const [scenarioIdx, setScenarioIdx] = useState(0);
  const [picks, setPicks] = useState({});  // { scenarioId: pickedSpanId }
  const scenario = SCENARIOS[scenarioIdx];
  const pickedId = picks[scenario.id];

  // Determine if the pick was correct
  const isCorrect = (() => {
    if (!pickedId) return null;
    if (scenario.bottleneckId === 'pattern') {
      const span = scenario.spans.find(s => s.id === pickedId);
      return span?.isCluster === true;
    }
    return pickedId === scenario.bottleneckId;
  })();

  // For wrong picks, compute the percentage to teach "this is only X% of total"
  const pickedSpan = scenario.spans.find(s => s.id === pickedId);
  const pickedPct = pickedSpan ? Math.round((pickedSpan.duration / scenario.totalMs) * 100) : 0;

  const handleClick = (spanId) => {
    if (pickedId === spanId) return;
    setPicks(prev => ({ ...prev, [scenario.id]: spanId }));
  };

  const resetScenario = () => {
    setPicks(prev => ({ ...prev, [scenario.id]: undefined }));
  };

  return (
    <div className="my-6 border border-teal-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-teal-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-teal-300" />
          <span className="text-teal-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · trace bottleneck identifier
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => setScenarioIdx(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === scenarioIdx
                  ? 'border-teal-300 bg-teal-300/15 text-teal-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-teal-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {s.label}
            </button>
          ))}
        </div>

        {/* Description */}
        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13.5px] leading-relaxed italic">
          {scenario.description}
        </div>

        {/* Trace metadata */}
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="text-[11px] text-zinc-500"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            trace · {scenario.spans.length} spans · total: {scenario.totalMs}ms
          </div>
          <div className="text-[10.5px] text-zinc-500 tracking-[0.2em] uppercase"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            click the bottleneck span
          </div>
        </div>

        {/* Gantt chart */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-3 mb-4">
          <div className="space-y-1">
            {scenario.spans.map(span => {
              const left = (span.start / scenario.totalMs) * 100;
              const width = Math.max((span.duration / scenario.totalMs) * 100, 0.5);
              const isPicked = pickedId === span.id;
              const isClickable = span.id !== 'root';
              const barColor = SERVICE_COLORS[span.service] || 'bg-zinc-400';

              // Highlighting after a pick
              let outline = '';
              if (pickedId) {
                if (scenario.bottleneckId === 'pattern') {
                  if (span.isCluster && isCorrect)              outline = 'ring-2 ring-teal-300';
                  else if (isPicked && !isCorrect)              outline = 'ring-2 ring-rose-400';
                } else {
                  if (span.id === scenario.bottleneckId)        outline = 'ring-2 ring-teal-300';
                  else if (isPicked && !isCorrect)              outline = 'ring-2 ring-rose-400';
                }
              }

              return (
                <div key={span.id}
                  onClick={() => isClickable && handleClick(span.id)}
                  className={`flex items-center gap-2 ${isClickable ? 'cursor-pointer hover:bg-zinc-800/40' : 'opacity-80'} py-0.5 px-1 rounded-sm`}>
                  {/* Span label */}
                  <div style={{ paddingLeft: `${span.depth * 14}px`, width: '40%' }}
                    className="shrink-0 text-[11.5px] text-zinc-300 truncate"
                    title={span.name}>
                    {span.depth > 0 && <span className="text-zinc-600">└ </span>}
                    {span.name || <span className="text-zinc-600 italic">·</span>}
                  </div>
                  {/* Bar area */}
                  <div className="flex-1 relative h-4 bg-zinc-900 border border-zinc-800">
                    <div
                      className={`absolute h-full ${barColor} ${outline} transition-all`}
                      style={{ left: `${left}%`, width: `${width}%`, minWidth: '2px' }}
                    />
                  </div>
                  {/* Duration */}
                  <div className="shrink-0 w-14 text-right text-[10.5px] text-zinc-400"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    {span.duration}ms
                  </div>
                </div>
              );
            })}
          </div>

          {/* Service legend */}
          <div className="flex flex-wrap gap-2 mt-3 pt-2 border-t border-zinc-800">
            {[...new Set(scenario.spans.map(s => s.service))].map(svc => (
              <div key={svc} className="flex items-center gap-1 text-[10px] text-zinc-500"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <div className={`w-2 h-2 ${SERVICE_COLORS[svc] || 'bg-zinc-400'}`} />
                {svc}
              </div>
            ))}
          </div>
        </div>

        {/* Feedback */}
        {pickedId && (
          <div className="space-y-3">
            {isCorrect ? (
              <>
                <div className="border border-teal-300 bg-teal-300/10 p-4">
                  <div className="flex items-center gap-2 mb-2 text-teal-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    <Check size={13} strokeWidth={3} />
                    {scenario.bottleneckId === 'pattern' ? `pattern identified` : `bottleneck found`}
                  </div>
                  <div className="text-zinc-200 text-[13.5px] leading-relaxed">{scenario.analysis}</div>
                </div>
                <div>
                  <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-1.5"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    the fix
                  </div>
                  <pre className="bg-zinc-950/80 border border-teal-300/30 p-3 text-[11.5px] text-zinc-200 overflow-x-auto leading-relaxed"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    <code>{scenario.fix}</code>
                  </pre>
                </div>
              </>
            ) : (
              <div className="border border-rose-400/50 bg-rose-400/5 p-3">
                <div className="flex items-center gap-2 mb-1 text-rose-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  <X size={12} strokeWidth={3} />
                  not the bottleneck
                </div>
                <div className="text-zinc-300 text-[13px] leading-relaxed">
                  This span is only {pickedPct}% of the total request time. Keep looking — the bottleneck is the span dominating the trace width.
                  {scenario.bottleneckId === 'pattern' && ` And look at the SHAPE of the trace; the bottleneck here is not a single span.`}
                </div>
              </div>
            )}

            <button onClick={resetScenario}
              className="px-3 py-1.5 border border-zinc-700 text-zinc-400 hover:border-teal-300/50 hover:text-zinc-200 transition-colors text-[11px] flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <RotateCcw size={10} /> reset this scenario
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section04_Observability() {
  return (
    <>
      <SectionLabel>section 04</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Observability — knowing what the API is doing
      </h2>
      <P>
        Caching, idempotency, and pagination are about building the API correctly. Observability
        is about KNOWING what your API is doing while it does it — and being able to answer "why
        is production slow?" with data instead of guesses. The difference between a 30-minute
        incident and a 6-hour incident is almost always the observability layer.
      </P>

      <H2 num="◇ 01">The three pillars — logs, metrics, traces</H2>
      <P>
        Each pillar answers a different question. You need all three.
      </P>
      <Code id="three-pillars" lang="text">{`PILLAR        ANSWERS                                EXAMPLE
──────        ───────                                ───────
Logs          What happened for THIS request?        "POST /checkout returned 500 for user_42 at 12:34"
Metrics       How is the system behaving overall?    "p99 latency for /checkout is 1.2s and rising"
Traces        Where is the time going INSIDE a       "process_payment span is 87% of /checkout's 1.5s"
              request that crosses services?`}</Code>
      <P>
        Modern systems use OpenTelemetry as the standard data model. One instrumentation library
        emits all three pillars; one collector ships them to whichever vendor you use (Datadog,
        Honeycomb, Grafana, etc.). That portability matters — observability vendors are easy to
        get locked into and expensive to migrate away from later.
      </P>

      <H2 num="◇ 02">Structured logging — JSON, not prose</H2>
      <P>
        Every log line should be a parseable JSON object with consistent fields. The contrast:
      </P>
      <Code id="logging-contrast" lang="text">{`# Bad — unstructured prose. Searchable only by string-matching.
2026-06-08 12:34:56 INFO User 42 checked out cart with 3 items totaling $59.95

# Good — structured JSON. Searchable by ANY field.
{
  "ts": "2026-06-08T12:34:56.234Z",
  "level": "INFO",
  "msg": "checkout completed",
  "user_id": 42,
  "cart_items": 3,
  "amount_cents": 5995,
  "currency": "usd",
  "request_id": "req_4f9e8d2a",
  "trace_id": "trace_8b3c2a1f",
  "service": "orders-service"
}`}</Code>
      <P>
        With structured logs, "show me every checkout over $1000 in the last hour" is a query, not
        a regex. Every modern logging backend (Datadog, ELK, CloudWatch Insights, BetterStack) is
        built around structured fields. The cost of switching from prose to JSON is one library
        change — adopt it before you have a million log lines to backfill.
      </P>
      <Callout kind="jolt" title="THE REQUEST_ID + TRACE_ID PATTERN">
        Every log line for a request should include the SAME request_id and trace_id. Then when a
        user reports a bug, you can search by their request_id and see every log line across every
        service that processed it. Pass these IDs through your service boundaries (HTTP headers or
        the trace context); never let them get lost at a service hop.
      </Callout>

      <H2 num="◇ 03">Metrics — the RED method</H2>
      <P>
        The simplest framework for instrumenting services: for every endpoint, track three numbers.
      </P>
      <Code id="red-method" lang="text">{`R · RATE       Requests per second                    "checkout is handling 240 req/s"
E · ERRORS     Error rate (4xx or 5xx)                "0.4% of /checkout requests are 5xx"
D · DURATION  Latency distribution (p50, p95, p99)    "p99 latency is 1.2s (was 200ms yesterday)"`}</Code>
      <P>
        Three numbers per endpoint = a complete service health picture. Alert on any of them moving
        sharply. Dashboards built on RED tell you immediately when something is wrong AND give a
        first hypothesis about WHERE.
      </P>
      <P>
        The companion framework for resources (not services) is USE — Utilization, Saturation,
        Errors. RED for "is the service healthy?"; USE for "is the host / DB / queue healthy?"
        Together they cover most monitoring needs.
      </P>

      <H2 num="◇ 04">Latency percentiles — averages lie</H2>
      <P>
        Most developers first reach for average latency and miss the actual problem.
      </P>
      <Code id="percentiles" lang="text">{`A service handling 1000 requests:
  990 requests at 50ms
  10 requests at 5000ms (some slow path — a cache miss, a long query)

AVERAGE LATENCY:  ~100ms              ← looks fine
P50 (MEDIAN):     50ms                ← fine
P95:              50ms                ← still fine
P99:              5000ms              ← here is the problem
P99.9:            5000ms              ← 1 in 1000 users is having a terrible time

The slow path affects 1% of requests but represents your worst user experience.
Averages hide it. Percentiles surface it.`}</Code>
      <P>
        Always look at percentiles. p99 is the standard "tail latency" measure — it represents
        what your worst 1% of users see. For real-time systems (chat, gaming, financial), p99.9
        matters because that 0.1% is still hundreds of users per day.
      </P>

      <H2 num="◇ 05">Distributed tracing — what spans actually are</H2>
      <P>
        A trace is the complete picture of one request as it flows through your services. It is
        composed of <em>spans</em> — each span representing one operation (an HTTP call, a database
        query, a function call) with a start time, duration, and metadata.
      </P>
      <Code id="trace-shape" lang="text">{`A trace for POST /checkout:

trace_id: trace_8b3c2a1f
└─ span: POST /checkout (api-gateway)           0ms - 1450ms
    ├─ span: validate_input                       3ms -    9ms
    ├─ span: load_cart (cart-service)            12ms -   40ms
    │   └─ span: SELECT cart_items (postgres)    18ms -   36ms
    ├─ span: process_payment (payment-service)   85ms - 1365ms
    │   └─ span: POST stripe.com/v1/charges      92ms - 1357ms
    └─ span: send_email (notification-service)  1410ms - 1445ms

Each span has:
  - trace_id (which request)
  - span_id (which operation)
  - parent_span_id (which operation called this one)
  - service name, operation name, start, duration
  - tags (custom key-value metadata)
  - status (ok / error)`}</Code>
      <P>
        Traces are the single most powerful debugging tool in distributed systems. "The checkout is
        slow" goes from a vague complaint to "the Stripe charge call took 1265ms" in one click.
      </P>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 06">Find the bottleneck in three real production patterns</H2>
      <P>
        Three traces, three different shapes of latency bug. Click around to inspect each trace;
        click the span you think is the bottleneck. The reveal explains WHY it is the bottleneck
        and shows the fix. The third one has no single bottleneck span — the bottleneck is the
        PATTERN, and the lesson is recognizing it.
      </P>

      <TraceViewer />

      <H2 num="◇ 07">SLIs, SLOs, SLAs — measuring promises</H2>
      <P>
        Three terms that get mixed up:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-teal-300">SLI (Service Level Indicator).</strong> The metric. "p99 latency under 500ms" or "success rate." A measurable thing about your service.
        </li>
        <li>
          <strong className="text-teal-300">SLO (Service Level Objective).</strong> The internal target. "p99 latency under 500ms 99.9% of the time over a rolling 30-day window." What YOU promise yourselves.
        </li>
        <li>
          <strong className="text-teal-300">SLA (Service Level Agreement).</strong> The customer-facing legal promise. "99.5% uptime per month." With financial consequences (credits) for missing it. Always looser than the SLO — you give yourself buffer.
        </li>
      </ul>
      <P>
        The pattern: define your SLIs, set SLOs slightly tighter than what your SLAs promise,
        track the gap (your "error budget"). When you are burning through error budget too fast,
        slow down deploys and shift focus to reliability. Most observability tools (Datadog,
        Honeycomb, Grafana) support this directly.
      </P>

      <H2 num="◇ 08">Health checks — /health, /ready, /live</H2>
      <P>
        Three different questions, three different endpoints. Mixing them up is a classic cause of
        production cascading failures.
      </P>
      <Code id="health-checks" lang="text">{`/livez  (liveness)    "Is this process alive at all?"
                       Should return 200 unless the process needs to be killed and restarted.
                       Used by Kubernetes to decide "kill the pod and start a new one."

/readyz (readiness)   "Is this process ready to serve traffic RIGHT NOW?"
                       Returns 503 during startup, deploy, draining, or temporary downstream issues.
                       Used by load balancers to decide "send traffic here or not."

/healthz (deep check) "Are dependencies reachable?"
                       Checks DB, cache, message queue. Used for dashboards and alerting.
                       DO NOT couple to /readyz — a flaky external dependency should not take you out of rotation.`}</Code>
      <Callout kind="warn" title="THE CLASSIC HEALTH-CHECK CASCADE">
        Service A's /healthz checks if it can reach Service B. Service B's /healthz checks if it
        can reach Service A. Service C briefly times out. Cascading dependency check failures take
        all three out of rotation simultaneously. Keep readiness checks LOCAL — does THIS process
        have what it needs? — and let actual dependency failures show up in your traces.
      </Callout>

      <H2 num="◇ 09">Alerting — anomalies beat thresholds</H2>
      <P>
        Static thresholds ("alert on more than 100 errors per minute") have two failure modes:
        too low → noise during busy periods, too high → silent miss during slow periods. Anomaly
        detection ("today is 10x yesterday for this user, endpoint, region") catches real issues
        earlier and silences the noise.
      </P>
      <P>
        Modern observability platforms (Datadog, Honeycomb, Grafana Mimir, etc.) have anomaly
        detection built in. Use it. The cost is the same; the false-positive rate is dramatically
        lower; on-call sleep is dramatically better.
      </P>

      <H2 num="◇ 10">Common observability mistakes</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-rose-400">Logging full request/response bodies on every endpoint.</strong> Storage costs explode; sensitive data leaks; useful signal drowns. Log structured FIELDS, not blobs.</li>
        <li><strong className="text-rose-400">Sampling traces too aggressively.</strong> 1% sampling makes the common case findable but loses the rare bugs. Use tail sampling — keep all errors + slow requests + 10% of the rest.</li>
        <li><strong className="text-rose-400">Dashboards without alerts.</strong> Pretty graphs that nobody looks at do not catch incidents. Every important metric gets either an alert or a deletion.</li>
        <li><strong className="text-rose-400">Alerting on causes, not symptoms.</strong> "CPU is high" is a cause; "latency is high" is what your users actually experience. Alert on user-visible symptoms first; investigate causes second.</li>
        <li><strong className="text-rose-400">PII in logs.</strong> Email addresses, names, free-text user input. Sanitize at the LOG CALL, not in a post-processor that will eventually be skipped.</li>
      </ul>

      <H2 num="◇ 11">Hardening checklist for observability</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Structured JSON logs with consistent fields (timestamp, level, msg, request_id, trace_id, service)</li>
        <li>✓ request_id and trace_id propagated through every service boundary</li>
        <li>✓ RED metrics (rate, errors, duration) per endpoint, with p50/p95/p99 latency</li>
        <li>✓ Distributed tracing on cross-service calls (OpenTelemetry as the standard)</li>
        <li>✓ Health endpoints distinct: /livez, /readyz, /healthz — and not cross-linked</li>
        <li>✓ SLOs defined for the top 5-10 endpoints; error budget tracked and visible</li>
        <li>✓ Alerts on user-visible symptoms (latency, errors) before causes (CPU, memory)</li>
        <li>✓ Anomaly detection rather than static thresholds where the platform supports it</li>
        <li>✓ PII sanitized at log-line write time, not post-process</li>
        <li>✓ Runbook for each alert — what does this alert mean, what should the on-call do?</li>
      </ul>

      {/* ──────────────────────────────────────────────────────────────── */}
      {/* CLOSING — Atlas 19 wrap + 3-atlas series wrap                   */}
      {/* ──────────────────────────────────────────────────────────────── */}

      <SectionLabel>end of atlas</SectionLabel>
      <H2 num="◆">What you can do now</H2>
      <P>Four sections back, "production" was a vague worry. Now you can:</P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-teal-300">Cache deliberately</strong> — pick the right Cache-Control for the content, prevent stampedes, never serve the wrong user's data</li>
        <li><strong className="text-teal-300">Survive retries</strong> — idempotency keys, the three-state machine, the 409 in-flight pattern</li>
        <li><strong className="text-teal-300">Paginate at scale</strong> — cursors over offsets, composite cursors with tie-breakers, indexes matching every supported sort</li>
        <li><strong className="text-teal-300">See inside production</strong> — structured logs, RED metrics, distributed traces, the percentile that matters</li>
      </ul>

      <SectionLabel>end of api series</SectionLabel>
      <H2 num="◆">The three-atlas pattern</H2>
      <P>
        Atlas 17, 18, and 19 ask the same three questions of every API, at three different layers:
      </P>
      <Code id="three-layers" lang="text">{`ATLAS 17 — FOUNDATIONS         "What does this endpoint do?"
                                REST · GraphQL · versioning · errors

ATLAS 18 — SECURITY            "Who is allowed to do it?"
                                Auth · authz · attack surfaces · defense in depth

ATLAS 19 — PRODUCTION          "How does it survive when something goes wrong?"
                                Caching · idempotency · pagination · observability`}</Code>
      <P>
        These three questions are not optional for any API that other people will use. Skip
        foundations and your API is unusable. Skip security and your API gets breached. Skip
        production and your API works in dev and dies on day-one of real traffic. The atlases
        are reference cards for the answers most teams figure out the expensive way.
      </P>
      <Callout kind="win" title="THE SHAPE OF EVERY GOOD API">
        Every API that works at scale has the same shape underneath. You now have the shape. Build
        something with it. Get it wrong in places (everyone does). Use the atlases as the lookup
        when you hit each class of bug. The work between "I can describe this" and "I can build
        this" is reps — go put in the reps.
      </Callout>
      <P>
        The B. Symbolic atlas series continues. Future atlases will move beyond APIs — into
        databases at scale, distributed systems, the design patterns that show up across all
        modern infrastructure. Same approach: see how it works, understand the trade-offs, build
        the muscle memory. Reference index at{' '}
        <Kbd>atlases.vercel.app</Kbd>.
      </P>
      <div className="text-zinc-500 text-center text-[10.5px] tracking-[0.3em] uppercase mt-12 mb-4"
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        ⏣ · atlas nineteen · complete · api series complete
      </div>
    </>
  );
}
