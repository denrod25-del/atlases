/* Section 02 — Idempotency.
 *
 * Prose + Retry Simulator.
 *
 * The simulator: step-through sequence diagram. Three scenarios:
 *   1. No idempotency key — timeout + retry → double charge (the bug)
 *   2. Idempotency key + completed request → cached response (the fix)
 *   3. Idempotency key + retry while first is in-flight → 409 Conflict
 *      pattern with client backoff (the production-realistic case)
 *
 * Each step shows: which actor (CLIENT/SERVER/DB/NETWORK), the action,
 * and the resulting world state (charges ledger + idempotency store).
 * Color-coded actor badges. Visual contrast between scenarios is the
 * teaching: same network conditions, dramatically different outcomes.
 */

import { useState } from 'react';
import { Sparkles, ChevronLeft, ChevronRight, RotateCcw, Zap, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Retry Simulator interactive
// ───────────────────────────────────────────────────────────────────────

const ACTOR_STYLES = {
  CLIENT:  { color: 'text-teal-300',   border: 'border-teal-300/40',   bg: 'bg-teal-300/10' },
  SERVER:  { color: 'text-amber-300',  border: 'border-amber-400/40',  bg: 'bg-amber-400/10' },
  DB:      { color: 'text-violet-300', border: 'border-violet-300/40', bg: 'bg-violet-300/10' },
  NETWORK: { color: 'text-rose-400',   border: 'border-rose-400/50',   bg: 'bg-rose-400/15' },
};

// Steps share a state shape:
//   { charges: [{id, amount, status}], idemStore: {key: {state, response}}, networkOk: bool }

const SCENARIOS = [
  {
    id: 'no-key',
    label: 'Without idempotency key',
    intro: `A POST /payments request to charge $100. The server processes it successfully — but the network drops before the response reaches the client. The client times out and retries. Watch what happens.`,
    steps: [
      { actor: 'CLIENT', action: `POST /payments — { amount: 100 }`,
        charges: [], idemStore: {}, networkOk: true },
      { actor: 'SERVER', action: `Request received. No way to tell if this is a new request or a retry.`,
        charges: [], idemStore: {}, networkOk: true },
      { actor: 'DB', action: `INSERT charge { amount: 100 }`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: {}, networkOk: true },
      { actor: 'SERVER', action: `Sending response 200 OK`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: {}, networkOk: true },
      { actor: 'NETWORK', action: `⚡ Connection drops. Response never reaches client.`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: {}, networkOk: false },
      { actor: 'CLIENT', action: `Timeout. Did the request succeed? No way to know. Retrying.`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: {}, networkOk: true },
      { actor: 'CLIENT', action: `POST /payments — { amount: 100 } (RETRY)`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: {}, networkOk: true },
      { actor: 'SERVER', action: `Request received. Looks identical to the previous one, but server has no way to know.`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: {}, networkOk: true },
      { actor: 'DB', action: `INSERT charge { amount: 100 }`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }, { id: 'charge_2', amount: 100, status: 'committed' }], idemStore: {}, networkOk: true },
      { actor: 'SERVER', action: `Sending response 200 OK`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }, { id: 'charge_2', amount: 100, status: 'committed' }], idemStore: {}, networkOk: true },
      { actor: 'CLIENT', action: `Success received. User happy. Bank statement: not so happy.`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }, { id: 'charge_2', amount: 100, status: 'committed' }], idemStore: {}, networkOk: true },
    ],
    verdict: { kind: 'bad', text: `$200 charged. The user wanted to pay $100. Their bank statement shows two identical charges. Customer support gets a ticket. Refund process begins. Trust erodes.` },
  },
  {
    id: 'with-key',
    label: 'With idempotency key (success path)',
    intro: `Same charge, same network drop. This time the client generates a unique idempotency key (idem_abc123) and includes it in the request header. The server uses it to recognize the retry.`,
    steps: [
      { actor: 'CLIENT', action: `POST /payments — Idempotency-Key: idem_abc123 — { amount: 100 }`,
        charges: [], idemStore: {}, networkOk: true },
      { actor: 'SERVER', action: `Check idempotency store for idem_abc123 — NOT FOUND. New request.`,
        charges: [], idemStore: {}, networkOk: true },
      { actor: 'SERVER', action: `Mark idem_abc123 as IN_FLIGHT in the store. Begin processing.`,
        charges: [], idemStore: { idem_abc123: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'DB', action: `INSERT charge { amount: 100 }`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: { idem_abc123: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'SERVER', action: `Cache response in idempotency store: idem_abc123 → { 200, body, charge_1 }`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: { idem_abc123: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
      { actor: 'SERVER', action: `Sending response 200 OK`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: { idem_abc123: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
      { actor: 'NETWORK', action: `⚡ Connection drops. Response never reaches client.`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: { idem_abc123: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: false },
      { actor: 'CLIENT', action: `Timeout. Retrying with the SAME idempotency key.`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: { idem_abc123: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
      { actor: 'CLIENT', action: `POST /payments — Idempotency-Key: idem_abc123 — { amount: 100 } (RETRY)`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: { idem_abc123: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
      { actor: 'SERVER', action: `Check store for idem_abc123 — FOUND, COMPLETED. Return cached response. No DB write.`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: { idem_abc123: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
      { actor: 'CLIENT', action: `Success received. Same response as the original would have been.`,
        charges: [{ id: 'charge_1', amount: 100, status: 'committed' }], idemStore: { idem_abc123: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
    ],
    verdict: { kind: 'good', text: `$100 charged once. The retry was absorbed by the idempotency layer; the same charge_1 came back as the cached result. The client got exactly the response it would have gotten on the first try.` },
  },
  {
    id: 'in-flight',
    label: 'In-flight retry (409 pattern)',
    intro: `The realistic edge case. Server is still PROCESSING the first request when the client times out and retries. The idempotency key exists but is not yet resolved. What should the server do?`,
    steps: [
      { actor: 'CLIENT', action: `POST /payments — Idempotency-Key: idem_xyz789 — { amount: 50 }`,
        charges: [], idemStore: {}, networkOk: true },
      { actor: 'SERVER', action: `Store has no idem_xyz789. Mark as IN_FLIGHT. Begin processing (calls payment provider — slow).`,
        charges: [], idemStore: { idem_xyz789: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'CLIENT', action: `Client timeout fires (short timeout, request still processing on server).`,
        charges: [], idemStore: { idem_xyz789: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'CLIENT', action: `Retry POST /payments — same Idempotency-Key: idem_xyz789.`,
        charges: [], idemStore: { idem_xyz789: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'SERVER', action: `Check store — idem_xyz789 is IN_FLIGHT. Cannot return a result yet.`,
        charges: [], idemStore: { idem_xyz789: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'SERVER', action: `Return 409 Conflict with header Retry-After: 1 to the retry. Original still processing.`,
        charges: [], idemStore: { idem_xyz789: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'CLIENT', action: `Receives 409. Backs off as instructed.`,
        charges: [], idemStore: { idem_xyz789: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'DB', action: `(meanwhile) Original request completes — INSERT charge { amount: 50 }.`,
        charges: [{ id: 'charge_1', amount: 50, status: 'committed' }], idemStore: { idem_xyz789: { state: 'IN_FLIGHT' } }, networkOk: true },
      { actor: 'SERVER', action: `Cache response in store: idem_xyz789 → { 200, charge_1 }. Mark COMPLETED.`,
        charges: [{ id: 'charge_1', amount: 50, status: 'committed' }], idemStore: { idem_xyz789: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
      { actor: 'CLIENT', action: `Backoff complete. Retry again with same idem_xyz789.`,
        charges: [{ id: 'charge_1', amount: 50, status: 'committed' }], idemStore: { idem_xyz789: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
      { actor: 'SERVER', action: `Check store — idem_xyz789 is COMPLETED. Return cached response.`,
        charges: [{ id: 'charge_1', amount: 50, status: 'committed' }], idemStore: { idem_xyz789: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
      { actor: 'CLIENT', action: `Success received. One charge, even with two retries.`,
        charges: [{ id: 'charge_1', amount: 50, status: 'committed' }], idemStore: { idem_xyz789: { state: 'COMPLETED', response: '200 OK · charge_1' } }, networkOk: true },
    ],
    verdict: { kind: 'good', text: `$50 charged once across three client attempts. The 409 + backoff pattern handles the race condition where the retry arrives while the original is still in flight. This is the production-realistic case most idempotency tutorials skip.` },
  },
];

function RetrySimulator() {
  const [scenarioIdx, setScenarioIdx] = useState(0);
  const [stepByScenario, setStepByScenario] = useState({});
  const scenario = SCENARIOS[scenarioIdx];
  const stepIdx = stepByScenario[scenario.id] ?? 0;
  const currentStep = scenario.steps[stepIdx];
  const isLastStep = stepIdx === scenario.steps.length - 1;

  const setStep = (n) => setStepByScenario(prev => ({ ...prev, [scenario.id]: n }));
  const next = () => { if (!isLastStep) setStep(stepIdx + 1); };
  const prev = () => { if (stepIdx > 0) setStep(stepIdx - 1); };
  const reset = () => setStep(0);

  const actorStyle = ACTOR_STYLES[currentStep.actor];

  return (
    <div className="my-6 border border-teal-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-teal-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-teal-300" />
          <span className="text-teal-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · retry simulator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => setScenarioIdx(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === scenarioIdx
                  ? 'border-teal-300 bg-teal-300/15 text-teal-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-teal-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {s.label}
            </button>
          ))}
        </div>

        {/* Scenario intro */}
        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13.5px] leading-relaxed italic">
          {scenario.intro}
        </div>

        {/* Timeline + world state — two-column layout */}
        <div className="grid md:grid-cols-5 gap-3 mb-4">
          {/* Timeline (3 cols on desktop) */}
          <div className="md:col-span-3 border border-zinc-800 bg-zinc-950/60 p-3">
            <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              timeline · step {stepIdx + 1} of {scenario.steps.length}
            </div>
            <div className="space-y-1.5 max-h-[420px] overflow-y-auto">
              {scenario.steps.map((s, i) => {
                const style = ACTOR_STYLES[s.actor];
                const isPast = i < stepIdx;
                const isCurrent = i === stepIdx;
                const isFuture = i > stepIdx;
                const cls = isCurrent
                  ? `${style.border} ${style.bg}`
                  : isPast
                    ? 'border-zinc-800 opacity-60'
                    : 'border-zinc-800 opacity-30';
                return (
                  <div key={i} className={`flex gap-2 items-start border ${cls} p-2 transition-opacity`}>
                    <div className={`text-[9px] tracking-[0.15em] font-bold px-1.5 py-0.5 border ${isCurrent ? style.color : 'text-zinc-500'} ${isCurrent ? style.border : 'border-zinc-700'} shrink-0 w-16 text-center`}
                      style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                      {s.actor}
                    </div>
                    <div className={`flex-1 text-[12.5px] leading-snug ${isCurrent ? 'text-zinc-100' : 'text-zinc-400'}`}>
                      {isFuture ? (
                        <span className="text-zinc-600">···</span>
                      ) : (
                        s.action
                      )}
                    </div>
                    <div className={`text-[10px] shrink-0 ${isCurrent ? style.color : 'text-zinc-600'}`}
                      style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                      {String(i + 1).padStart(2, '0')}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* World state (2 cols on desktop) */}
          <div className="md:col-span-2 space-y-3">
            <div className="border border-zinc-800 bg-zinc-950/60 p-3">
              <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                charges (db state)
              </div>
              {currentStep.charges.length === 0 ? (
                <div className="text-zinc-600 text-[12px] italic">(none yet)</div>
              ) : (
                <div className="space-y-1">
                  {currentStep.charges.map(c => (
                    <div key={c.id} className={`text-[12px] flex justify-between border-b border-zinc-800/60 pb-1 ${
                      currentStep.charges.length > 1 ? 'text-rose-300' : 'text-teal-200'
                    }`}
                      style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                      <span>{c.id}</span>
                      <span>${c.amount}</span>
                    </div>
                  ))}
                  <div className={`text-[10.5px] tracking-[0.2em] uppercase mt-1.5 ${
                    currentStep.charges.length > 1 ? 'text-rose-400' : 'text-teal-300'
                  }`}
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    total: ${currentStep.charges.reduce((s, c) => s + c.amount, 0)}
                    {currentStep.charges.length > 1 && ' (!)'}
                  </div>
                </div>
              )}
            </div>

            <div className="border border-zinc-800 bg-zinc-950/60 p-3">
              <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                idempotency store
              </div>
              {Object.keys(currentStep.idemStore).length === 0 ? (
                <div className="text-zinc-600 text-[12px] italic">(empty — not in use)</div>
              ) : (
                <div className="space-y-1">
                  {Object.entries(currentStep.idemStore).map(([key, val]) => {
                    const stateColor = val.state === 'IN_FLIGHT' ? 'text-amber-300' : 'text-teal-300';
                    return (
                      <div key={key} className="text-[11.5px] leading-relaxed"
                        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                        <div className="text-zinc-300">{key}</div>
                        <div className={`${stateColor} text-[10.5px]`}>
                          ↳ {val.state}{val.response ? ` · ${val.response}` : ''}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="border border-zinc-800 bg-zinc-950/60 p-3">
              <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                network
              </div>
              <div className={`text-[12px] flex items-center gap-2 ${currentStep.networkOk ? 'text-teal-300' : 'text-rose-400'}`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {currentStep.networkOk ? (
                  <><CheckCircle2 size={12} /> ok</>
                ) : (
                  <><Zap size={12} /> dropped</>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap gap-2 items-center mb-4">
          <button onClick={prev} disabled={stepIdx === 0}
            className="px-3 py-1.5 border border-zinc-700 text-zinc-400 hover:border-teal-300/50 hover:text-zinc-200 transition-colors text-[11.5px] flex items-center gap-1 disabled:opacity-30 disabled:cursor-not-allowed"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <ChevronLeft size={12} /> back
          </button>
          <button onClick={next} disabled={isLastStep}
            className="px-4 py-1.5 border border-teal-300 bg-teal-300/10 text-teal-200 hover:bg-teal-300/20 transition-colors text-[11.5px] flex items-center gap-1 disabled:opacity-30 disabled:cursor-not-allowed font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            step forward <ChevronRight size={12} />
          </button>
          <button onClick={reset}
            className="px-3 py-1.5 border border-zinc-700 text-zinc-500 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[11.5px] flex items-center gap-1"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <RotateCcw size={11} /> reset
          </button>
          {isLastStep && (
            <span className="text-zinc-500 text-[10.5px] ml-2 italic">end of scenario</span>
          )}
        </div>

        {/* Verdict (only on last step) */}
        {isLastStep && (
          <div className={`border p-4 ${
            scenario.verdict.kind === 'good'
              ? 'border-teal-300 bg-teal-300/10'
              : 'border-rose-400 bg-rose-400/10'
          }`}>
            <div className={`flex items-center gap-2 mb-2 text-[11px] tracking-[0.25em] uppercase font-semibold ${
              scenario.verdict.kind === 'good' ? 'text-teal-300' : 'text-rose-400'
            }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {scenario.verdict.kind === 'good' ? <CheckCircle2 size={13} /> : <AlertTriangle size={13} />}
              verdict
            </div>
            <div className="text-zinc-200 text-[13.5px] leading-relaxed">{scenario.verdict.text}</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section02_Idempotency() {
  return (
    <>
      <SectionLabel>section 02</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Idempotency — surviving retries
      </h2>
      <P>
        Networks fail. Connections drop mid-request. Mobile clients lose signal between sending and
        receiving. Cloud load balancers drop in-flight requests during deploys. When any of these
        happen, the client has a hard problem: it does not know whether the request succeeded.
        Retry, and you might double-charge a customer. Do not retry, and you might silently lose
        an order. Idempotency is the discipline of making operations safe to retry — so the answer
        is always "retry, and the server will figure it out."
      </P>

      <H2 num="◇ 01">The HTTP method contract</H2>
      <P>
        The HTTP spec defines which methods are idempotent by their semantics. An idempotent method
        produces the same result whether called once or many times.
      </P>
      <Code id="http-idempotency" lang="text">{`METHOD     IDEMPOTENT?    WHY
──────     ───────────    ───
GET        ✓ Yes           Reading data does not change it. Cache it, retry it freely.
PUT        ✓ Yes           "Set the whole resource to this" — second call is a no-op.
DELETE     ✓ Yes           "Make sure this is gone" — second call finds it already gone.
HEAD       ✓ Yes           Same as GET but no body.
OPTIONS    ✓ Yes           Metadata query, side-effect-free.

POST       ✗ No            "Do this" — repeating it does it twice. This is the dangerous one.
PATCH      ⚠ Maybe         Depends on semantics. "Increment counter by 1" is not idempotent;
                            "Set field to X" is. Treat as not-idempotent by default.`}</Code>
      <P>
        The contract has a catch: HTTP method idempotency is about what the SPEC promises, not what
        your actual server does. If your DELETE handler logs an audit event each time it runs, your
        DELETE is no longer idempotent from a logging perspective. Read your own code; do not assume.
      </P>

      <H2 num="◇ 02">Why POST is the problem</H2>
      <P>
        Most state-changing operations in real APIs are POSTs: create payment, send email, place
        order, send message. POST is not idempotent by design — calling it twice does it twice.
        That is fine when the network is reliable; it is a disaster when the network is the
        internet.
      </P>
      <Callout kind="jolt" title="THE TIMEOUT WAS PROCESSED">
        Picture a payment endpoint. Server receives the request, charges the card, commits to the
        DB, sends the 200 OK response. Network drops the response packet. Client times out, never
        sees the 200. From the client's point of view, the request FAILED. So it retries. Second
        request charges the card again. Customer pays twice. The bug is not in the payment code;
        it is in the fact that no one told the server "if you see this request again, do not redo
        the work."
      </Callout>

      <H2 num="◇ 03">Idempotency keys — the Stripe pattern</H2>
      <P>
        The most widely-deployed pattern: the client generates a unique key for each logical
        operation and includes it in a request header. The server keys an "I have already seen
        this" lookup by that value. The same key seen twice → return the cached response from
        the first; do not re-process.
      </P>
      <Code id="stripe-pattern" lang="http">{`POST /v1/charges HTTP/1.1
Host: api.stripe.com
Authorization: Bearer ...
Idempotency-Key: 4f8e7d6c-3b2a-4f1e-9d8c-7b6a5e4d3c2b
Content-Type: application/json

{
  "amount": 5000,
  "currency": "usd",
  "source": "tok_visa"
}`}</Code>
      <P>
        Properties of a good idempotency key:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-teal-300">Client-generated.</strong> Server cannot detect a retry unless the client tags it. UUIDs are standard.</li>
        <li><strong className="text-teal-300">Unique per logical operation.</strong> "Pay $100 to charge_id 42" gets one key. A SECOND payment, even for the same amount, gets a NEW key.</li>
        <li><strong className="text-teal-300">Stable across retries.</strong> If the client retries the same operation, it uses the SAME key. That is what lets the server recognize the retry.</li>
        <li><strong className="text-teal-300">Reasonable lifetime.</strong> Servers store keys for 24 hours (Stripe), sometimes longer. After that, the same key seen again would be treated as a new operation.</li>
      </ul>

      <H2 num="◇ 04">Implementing idempotency on the server</H2>
      <P>
        The implementation has three states for each key: NOT SEEN, IN FLIGHT, COMPLETED.
      </P>
      <Code id="idem-server" lang="python">{`from datetime import timedelta

def handle_payment(request):
    key = request.headers.get("Idempotency-Key")
    if not key:
        # No key — process normally (caller takes the risk)
        return process_payment(request.json)

    # Atomic: check + lock — important to prevent race conditions
    existing = redis.get(f"idem:{key}")
    if existing:
        cached = json.loads(existing)
        if cached["state"] == "IN_FLIGHT":
            return Response(status=409, headers={"Retry-After": "1"})
        if cached["state"] == "COMPLETED":
            return Response(
                status=cached["status"],
                json=cached["body"],
            )

    # New key — atomically claim it
    claimed = redis.set(
        f"idem:{key}",
        json.dumps({"state": "IN_FLIGHT"}),
        nx=True,                    # only set if not exists — prevents race
        ex=86400,                   # 24h TTL
    )
    if not claimed:
        # Lost the race — another worker claimed it just now
        return Response(status=409, headers={"Retry-After": "1"})

    # Process the actual operation
    try:
        result = process_payment(request.json)
        # Cache the completed result
        redis.set(
            f"idem:{key}",
            json.dumps({
                "state": "COMPLETED",
                "status": 200,
                "body": result.to_dict(),
            }),
            ex=86400,
        )
        return Response(status=200, json=result.to_dict())
    except Exception as e:
        # Important: on failure, REMOVE the in-flight marker so the
        # client can retry. Otherwise we lock the operation forever.
        redis.delete(f"idem:{key}")
        raise`}</Code>
      <P>
        The 409 Conflict for in-flight retries is the production-realistic edge case. Without it,
        a fast-retrying client can double-process if the second request arrives while the first
        is still running. Stripe's API uses exactly this pattern.
      </P>

      <H2 num="◇ 05">Database-level idempotency — UPSERT</H2>
      <P>
        For some operations, the database itself can enforce idempotency without an in-app key
        layer. The UPSERT pattern relies on a unique constraint:
      </P>
      <Code id="upsert-postgres" lang="sql">{`-- Unique constraint on (user_id, external_event_id)
-- A client retry with the same external_event_id is automatically a no-op.

INSERT INTO events (user_id, external_event_id, payload, created_at)
VALUES ($1, $2, $3, NOW())
ON CONFLICT (user_id, external_event_id) DO NOTHING
RETURNING id;

-- If RETURNING returns nothing, the event was already there — return
-- the cached ID by selecting it. Or use ON CONFLICT DO UPDATE if you
-- want to merge fields from the retry.`}</Code>
      <Callout kind="tip" title="WHEN TO USE WHICH">
        Idempotency keys handle ANY operation (multiple DB writes, external API calls, side effects).
        UPSERT only handles single-row writes but is much simpler. For a payment that involves
        charging a card AND updating an order AND sending an email, idempotency keys. For a simple
        "record this event," UPSERT.
      </Callout>

      <H2 num="◇ 06">Idempotency vs deduplication vs exactly-once</H2>
      <P>
        These three terms get mixed up:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-teal-300">Idempotency:</strong> The OPERATION can be invoked
          multiple times safely. Result is the same as one invocation.
        </li>
        <li>
          <strong className="text-teal-300">Deduplication:</strong> The system detects duplicate
          inputs and silently discards them. Often the implementation of idempotency.
        </li>
        <li>
          <strong className="text-teal-300">Exactly-once delivery:</strong> A theoretical property
          of distributed systems. In practice, impossible across an unreliable network — the best
          you get is "at-least-once delivery with idempotent consumers" (the canonical answer to
          the "exactly-once" question in distributed systems).
        </li>
      </ul>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 07">Step through three retry scenarios</H2>
      <P>
        The simulator walks through the same payment request under three conditions: without an
        idempotency key, with one (success path), and with one in the in-flight edge case where
        the retry arrives while the first request is still processing. Click step forward to
        advance. Watch the charges ledger and idempotency store update in real time.
      </P>

      <RetrySimulator />

      <H2 num="◇ 08">Common idempotency mistakes</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-rose-400">Not handling the in-flight case.</strong> Server stores
          the key only AFTER processing completes. Fast retries arrive while the first is still
          running, find no cached result, and process again. Always claim the key BEFORE processing.
        </li>
        <li>
          <strong className="text-rose-400">Forgetting to release on failure.</strong> Processing
          fails halfway. Server crashes. The IN_FLIGHT marker stays in the store forever (until
          TTL). Now the client cannot retry; every attempt returns 409. Always wrap in try/except;
          release the marker on failure.
        </li>
        <li>
          <strong className="text-rose-400">Caching error responses.</strong> Server returns 500
          due to a transient downstream issue; that 500 gets cached against the idempotency key.
          Client retries, gets the cached 500 forever. Only cache responses that represent
          completed state changes (2xx, and explicit 4xx like "card declined").
        </li>
        <li>
          <strong className="text-rose-400">Reusing keys across logically different operations.</strong>{' '}
          Client uses a session ID as the key. User clicks "pay" twice for two different things.
          Second click hits the cached response from the first. Use a key PER LOGICAL OPERATION.
        </li>
        <li>
          <strong className="text-rose-400">No expiration on the idempotency store.</strong> Store
          grows without bound. Eventually Redis runs out of memory and the whole system breaks.
          Always set a TTL — 24h is the Stripe convention.
        </li>
      </ul>

      <H2 num="◇ 09">Hardening checklist for idempotency</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ All POST endpoints that change state accept an Idempotency-Key header</li>
        <li>✓ Server claims the key BEFORE processing (atomic SET NX)</li>
        <li>✓ In-flight retries get 409 Conflict with Retry-After</li>
        <li>✓ Failed operations release the IN_FLIGHT marker</li>
        <li>✓ Only successful (or definitively-failed) responses get cached</li>
        <li>✓ Idempotency store has TTL — 24h is the standard</li>
        <li>✓ Client libraries (your SDKs) auto-generate keys and retry with backoff on transient failures</li>
        <li>✓ UPSERT used for simple "record this event" cases where a unique constraint suffices</li>
        <li>✓ Documentation tells API consumers HOW to generate keys and WHEN to reuse them</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Idempotency handles retries on individual writes. Section 03 covers the analogous problem
        for reads at scale: pagination, and why the obvious approach (LIMIT/OFFSET) breaks
        catastrophically on real data sizes.
      </Callout>
    </>
  );
}
