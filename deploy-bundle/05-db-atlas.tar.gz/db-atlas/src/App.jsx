/* Databases at Scale Atlas — shell with section tabs in the sticky header.
 *
 * Tabs are anchor links. Active tab is auto-highlighted based on which
 * section is in view, via IntersectionObserver. Scroll-margin on each
 * section accounts for the two-row sticky header height.
 */

import { useEffect, useState } from 'react';
import Section01_Indexes from './sections/01-indexes.jsx';
import Section02_QueryOpt from './sections/02-query-optimization.jsx';
import Section03_Transactions from './sections/03-transactions.jsx';
import Section04_Replication from './sections/04-replication.jsx';

const SECTIONS = [
  { id: 'indexes',      label: '01 · Indexes',          comp: Section01_Indexes },
  { id: 'query-opt',    label: '02 · Query Optimization', comp: Section02_QueryOpt },
  { id: 'transactions', label: '03 · Transactions',     comp: Section03_Transactions },
  { id: 'replication',  label: '04 · Replication',      comp: Section04_Replication },
];

function StickyHeader({ activeId }) {
  return (
    <div className="border-b border-zinc-800 bg-zinc-950/95 sticky top-0 z-50 backdrop-blur">
      {/* Brand row */}
      <div className="max-w-5xl mx-auto px-6 py-3 flex items-baseline gap-4">
        <a href="#top" className="text-indigo-300 text-[22px] leading-none"
          style={{ fontFamily: 'serif' }}>▤</a>
        <div className="flex-1">
          <div className="text-zinc-100 text-[14px] font-semibold leading-tight"
            style={{ fontFamily: 'Bricolage Grotesque, sans-serif' }}>
            Databases at Scale
          </div>
          <div className="text-zinc-500 text-[10.5px] tracking-[0.25em] uppercase"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            Atlas · B. Symbolic
          </div>
        </div>
        <a href="https://atlases.vercel.app"
          className="text-zinc-500 hover:text-indigo-300 text-[11px] tracking-[0.2em] uppercase"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          ← all atlases
        </a>
      </div>

      {/* Section tabs row */}
      <div className="border-t border-zinc-800/60 max-w-5xl mx-auto px-6 py-2">
        <div className="flex gap-1.5 overflow-x-auto scrollbar-thin">
          {SECTIONS.map(s => {
            const isActive = activeId === s.id;
            return (
              <a key={s.id} href={`#${s.id}`}
                className={`px-3 py-1.5 border text-[11.5px] whitespace-nowrap transition-colors shrink-0 ${
                  isActive
                    ? 'border-indigo-300 bg-indigo-300/15 text-indigo-200'
                    : 'border-zinc-700/80 text-zinc-400 hover:border-indigo-300/50 hover:text-zinc-200'
                }`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {s.label}
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <div id="top" className="border-b border-zinc-800 bg-gradient-to-b from-zinc-950 to-zinc-900">
      <div className="max-w-5xl mx-auto px-6 py-16">
        <div className="text-indigo-300 text-[11px] tracking-[0.4em] uppercase mb-4"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          atlas twenty · ▤
        </div>
        <h1 className="text-zinc-50 text-[42px] leading-[1.05] mb-4"
          style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 700 }}>
          Databases at Scale
        </h1>
        <p className="text-zinc-400 text-[16px] max-w-2xl leading-relaxed"
          style={{ fontFamily: 'Manrope, sans-serif' }}>
          The foundation under every API. Indexes — how lookups actually go fast.
          Query optimization — speaking the planner&apos;s language. Transactions and isolation —
          surviving concurrency without anomalies. Replication and scaling — outgrowing one
          machine. Opens the data-systems arc of the atlas series.
        </p>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div className="border-t border-zinc-800 mt-20 py-10">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <div className="text-zinc-500 text-[11px] tracking-[0.3em] uppercase mb-2"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          end of atlas
        </div>
        <div className="text-zinc-600 text-[12px]">
          ▤ · Databases at Scale · B. Symbolic ·{' '}
          <a href="https://atlases.vercel.app" className="hover:text-indigo-300">atlases.vercel.app</a>
        </div>
      </div>
    </div>
  );
}

// Scrollspy hook — observes section elements and reports which is in view.
// rootMargin biases activation to the upper third of the viewport so the
// tab updates a beat BEFORE the section header reaches the top of the screen.
function useActiveSection() {
  const [activeId, setActiveId] = useState(SECTIONS[0].id);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        // Pick the entry highest on screen that is currently intersecting
        const visible = entries.filter(e => e.isIntersecting);
        if (visible.length > 0) {
          visible.sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
          setActiveId(visible[0].target.id);
        }
      },
      { rootMargin: '-30% 0px -55% 0px', threshold: 0 }
    );

    SECTIONS.forEach(s => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  return activeId;
}

export default function App() {
  const activeId = useActiveSection();
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <StickyHeader activeId={activeId} />
      <Hero />
      <div className="max-w-5xl mx-auto px-6">
        {SECTIONS.map(s => {
          const Comp = s.comp;
          return (
            // scroll-mt-28 accounts for the two-row sticky header (~7rem tall)
            <div key={s.id} id={s.id} className="scroll-mt-28">
              <Comp />
            </div>
          );
        })}
      </div>
      <Footer />
    </div>
  );
}
