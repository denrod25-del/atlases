/* Section 04 — Replication and Scaling. Closing section of Atlas 20.
 *
 * Prose + Replication Lag Simulator + atlas-closing + arc-opening wraps.
 *
 * The simulator: one primary, three replicas, each with its own lag value.
 * User clicks Write — primary updates immediately, replicas catch up after
 * their respective lag windows. User clicks Read — depending on the chosen
 * strategy, the read hits either a random replica (may be stale), the
 * primary (always fresh), or any node under synchronous replication
 * (always fresh, but writes are slower).
 *
 * Three modes show the trade-offs:
 *   1. Async + default routing — fast writes, stale reads possible
 *   2. Async + read-your-writes — fast writes, your reads stay consistent
 *   3. Synchronous replication — slow writes, always-consistent reads
 *
 * All prose strings use backticks to avoid the apostrophe-in-single-quote
 * parse traps from Atlas 18 section 03.
 */

import { useState, useEffect, useRef } from 'react';
import { Sparkles, Server, ArrowDown, RotateCcw, Edit, Eye, Database, Clock, Activity } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Replication Lag Simulator
// ───────────────────────────────────────────────────────────────────────

const INITIAL_REPLICAS = [
  { id: 'R1', lagMs: 250 },
  { id: 'R2', lagMs: 700 },
  { id: 'R3', lagMs: 1500 },
];

const MODES = [
  {
    id: 'async-default',
    label: 'Async + default routing',
    description: `Standard asynchronous replication. Writes commit on primary immediately. Reads go to a random replica — which may not have caught up yet. The configuration most read-heavy systems start with.`,
  },
  {
    id: 'read-your-writes',
    label: 'Async + read-your-writes',
    description: `Same async replication. But the reading client routes its reads to the primary for a short window after writing, guaranteeing it sees its own changes. Other clients still hit replicas as normal.`,
  },
  {
    id: 'sync',
    label: 'Synchronous replication',
    description: `Primary does not acknowledge the write until all replicas have applied it. Writes are slower — bounded by the slowest replica. But any subsequent read from any replica is guaranteed fresh.`,
  },
];

function ReplicationSimulator() {
  const [mode, setMode] = useState('async-default');
  const [primaryValue, setPrimaryValue] = useState(100);
  const [replicas, setReplicas] = useState(
    INITIAL_REPLICAS.map(r => ({ ...r, value: 100, status: 'idle', pendingValue: null }))
  );
  const [lastRead, setLastRead] = useState(null);  // { targetId, value, stale }
  const [log, setLog] = useState([]);              // recent events
  const [nextValue, setNextValue] = useState(150);
  const [writeInFlight, setWriteInFlight] = useState(false);
  const t0 = useRef(Date.now());
  const timerRef = useRef([]);

  // Clean up timers on unmount or scenario switch
  useEffect(() => () => timerRef.current.forEach(clearTimeout), []);

  const pushLog = (text, tone = 'neutral') => {
    const t = ((Date.now() - t0.current) / 1000).toFixed(2);
    setLog(prev => [{ t, text, tone, id: Date.now() + Math.random() }, ...prev].slice(0, 12));
  };

  const switchMode = (newMode) => {
    // Reset on mode switch
    timerRef.current.forEach(clearTimeout);
    timerRef.current = [];
    setMode(newMode);
    setPrimaryValue(100);
    setReplicas(INITIAL_REPLICAS.map(r => ({ ...r, value: 100, status: 'idle', pendingValue: null })));
    setLastRead(null);
    setLog([]);
    setWriteInFlight(false);
    t0.current = Date.now();
  };

  const reset = () => switchMode(mode);

  const performWrite = () => {
    if (writeInFlight) return;
    const newVal = nextValue;
    setNextValue(prev => prev + 50);
    setPrimaryValue(newVal);

    if (mode === 'sync') {
      // Synchronous: do not "commit" the write until all replicas have applied it
      setWriteInFlight(true);
      pushLog(`WRITE primary = ${newVal}  (waiting for replicas...)`, 'write');
    } else {
      pushLog(`WRITE primary = ${newVal}  (committed)`, 'write');
    }

    // Schedule each replica's catch-up
    setReplicas(prev => prev.map(r => ({ ...r, status: 'syncing', pendingValue: newVal })));

    let completed = 0;
    INITIAL_REPLICAS.forEach((r, i) => {
      const timer = setTimeout(() => {
        setReplicas(prev => prev.map((rep, idx) =>
          idx === i ? { ...rep, value: newVal, status: 'idle', pendingValue: null } : rep
        ));
        pushLog(`${r.id} ← ${newVal}  (replicated after ${r.lagMs}ms)`, 'repl');
        completed++;
        if (completed === INITIAL_REPLICAS.length && mode === 'sync') {
          setWriteInFlight(false);
          pushLog(`WRITE primary = ${newVal}  (now acknowledged to client)`, 'commit');
        }
      }, r.lagMs);
      timerRef.current.push(timer);
    });
  };

  const performRead = () => {
    let targetId, value, stale;

    if (mode === 'read-your-writes') {
      targetId = 'PRIMARY';
      value = primaryValue;
      stale = false;
    } else {
      // Pick a random replica
      const i = Math.floor(Math.random() * replicas.length);
      const r = replicas[i];
      targetId = r.id;
      value = r.value;
      stale = value !== primaryValue && mode !== 'sync';
    }

    setLastRead({ targetId, value, stale });
    pushLog(
      `READ ${targetId} → balance=${value}${stale ? '  (STALE!)' : ''}`,
      stale ? 'stale' : 'read'
    );
  };

  const currentMode = MODES.find(m => m.id === mode);

  return (
    <div className="my-6 border border-indigo-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-indigo-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-indigo-300" />
          <span className="text-indigo-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · replication lag simulator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Mode tabs */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {MODES.map(m => (
            <button key={m.id} onClick={() => switchMode(m.id)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                mode === m.id
                  ? 'border-indigo-300 bg-indigo-300/15 text-indigo-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-indigo-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {m.label}
            </button>
          ))}
        </div>

        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13px] leading-relaxed italic">
          {currentMode.description}
        </div>

        {/* Visualization: primary + replicas */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-5 mb-4">
          {/* Primary */}
          <div className="flex justify-center mb-2">
            <div className="border-2 border-indigo-300 bg-indigo-300/10 px-4 py-3 min-w-[180px]">
              <div className="flex items-center justify-center gap-2 mb-1 text-indigo-300 text-[10px] tracking-[0.25em] uppercase font-semibold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <Server size={11} />
                primary
                {writeInFlight && (
                  <span className="text-amber-300 ml-1">· awaiting replicas</span>
                )}
              </div>
              <div className="text-center text-indigo-100 text-[18px] font-bold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                balance = {primaryValue}
              </div>
            </div>
          </div>

          {/* Connector */}
          <div className="flex justify-center mb-2">
            <ArrowDown size={16} className="text-zinc-700" />
          </div>
          <div className="text-center text-zinc-600 text-[10px] mb-3 tracking-[0.2em] uppercase"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            replication
          </div>

          {/* Replicas */}
          <div className="grid grid-cols-3 gap-3">
            {replicas.map(r => {
              const isLastRead = lastRead?.targetId === r.id;
              const isStale = r.value !== primaryValue;
              const isSyncing = r.status === 'syncing';
              const borderColor = isLastRead
                ? (lastRead.stale ? 'border-rose-400' : 'border-emerald-400')
                : isSyncing
                  ? 'border-amber-400/60'
                  : 'border-zinc-700';
              const bgColor = isLastRead
                ? (lastRead.stale ? 'bg-rose-400/10' : 'bg-emerald-400/10')
                : isSyncing
                  ? 'bg-amber-400/5'
                  : 'bg-zinc-900/40';
              return (
                <div key={r.id} className={`border ${borderColor} ${bgColor} px-3 py-3 transition-colors`}>
                  <div className="flex items-center justify-between mb-1 text-[10px] tracking-[0.2em] uppercase font-semibold text-zinc-400"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    <span className="flex items-center gap-1">
                      <Database size={10} />
                      {r.id}
                    </span>
                    <span className="text-zinc-500 normal-case tracking-normal flex items-center gap-1">
                      <Clock size={9} />
                      {r.lagMs}ms
                    </span>
                  </div>
                  <div className={`text-center text-[16px] font-bold ${
                    isStale ? 'text-amber-300' : 'text-zinc-100'
                  }`}
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    bal = {r.value}
                  </div>
                  <div className={`text-center text-[9.5px] mt-1 tracking-[0.2em] uppercase ${
                    isSyncing ? 'text-amber-400' : (isStale ? 'text-amber-300/70' : 'text-zinc-600')
                  }`}
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    {isSyncing ? `syncing → ${r.pendingValue}` : (isStale ? 'stale' : 'in sync')}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap gap-2 mb-4">
          <button onClick={performWrite} disabled={writeInFlight}
            className="px-4 py-2 border border-indigo-300 bg-indigo-300/10 text-indigo-200 hover:bg-indigo-300/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-[12px] font-semibold flex items-center gap-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Edit size={12} />
            {writeInFlight ? `writing... (awaiting replicas)` : `WRITE balance = ${nextValue}`}
          </button>
          <button onClick={performRead}
            className="px-4 py-2 border border-emerald-400 bg-emerald-400/10 text-emerald-200 hover:bg-emerald-400/20 transition-colors text-[12px] font-semibold flex items-center gap-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Eye size={12} />
            READ
          </button>
          <button onClick={reset}
            className="px-3 py-2 border border-zinc-700 text-zinc-400 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[11px] flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <RotateCcw size={11} /> reset
          </button>
        </div>

        {/* Last read result */}
        {lastRead && (
          <div className={`border p-3 mb-3 ${
            lastRead.stale
              ? 'border-rose-400/60 bg-rose-400/10'
              : 'border-emerald-400/60 bg-emerald-400/10'
          }`}>
            <div className={`text-[10px] tracking-[0.25em] uppercase font-semibold mb-1 ${
              lastRead.stale ? 'text-rose-400' : 'text-emerald-400'
            }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {lastRead.stale ? 'last read · STALE' : 'last read · fresh'}
            </div>
            <div className="text-zinc-200 text-[13px] leading-relaxed">
              Read from <Kbd>{lastRead.targetId}</Kbd> returned <Kbd>balance = {lastRead.value}</Kbd>.
              {lastRead.stale && (
                <> Primary&apos;s actual value is <Kbd>{primaryValue}</Kbd>. The replica had not received the latest write yet. This is read-after-write inconsistency in action.</>
              )}
              {!lastRead.stale && mode === 'read-your-writes' && (
                <> Always fresh — reads from this session are routed to the primary directly.</>
              )}
              {!lastRead.stale && mode === 'sync' && (
                <> Always fresh — synchronous replication guarantees every replica has the latest committed value.</>
              )}
              {!lastRead.stale && mode === 'async-default' && (
                <> By luck — this particular replica had caught up. Run a few more reads to see the stale ones.</>
              )}
            </div>
          </div>
        )}

        {/* Operation log */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <Activity size={10} />
              event log
            </div>
            <div className="text-zinc-600 text-[10px]"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {log.length === 0 ? 'no events yet' : 'most recent on top'}
            </div>
          </div>
          {log.length === 0 ? (
            <div className="text-zinc-600 text-[12px] italic">
              Click WRITE to update the primary, then READ to see the value from a replica.
            </div>
          ) : (
            <div className="space-y-0.5 max-h-44 overflow-y-auto">
              {log.map(entry => {
                const toneCls = {
                  write: 'text-indigo-300',
                  commit: 'text-emerald-400',
                  repl: 'text-zinc-400',
                  read: 'text-emerald-300',
                  stale: 'text-rose-300 font-semibold',
                  neutral: 'text-zinc-400',
                }[entry.tone] || 'text-zinc-400';
                return (
                  <div key={entry.id} className={`text-[11px] flex gap-3 ${toneCls}`}
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    <span className="text-zinc-600 shrink-0 w-12">t={entry.t}s</span>
                    <span>{entry.text}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section04_Replication() {
  return (
    <>
      <SectionLabel>section 04</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Replication and scaling — outgrowing one machine
      </h2>
      <P>
        A single database machine handles a remarkable amount of traffic. Modern hardware
        comfortably runs hundreds of thousands of queries per second on a single Postgres
        instance with proper tuning. But "remarkable" is not "infinite." Eventually one machine
        is not enough — either because the read traffic is too heavy, or the write traffic is
        too heavy, or because you need geographical distribution, or because you cannot afford
        to lose service when one machine dies. Replication and sharding are the two answers.
      </P>

      <H2 num="◇ 01">Primary + replicas — the basic shape</H2>
      <P>
        The standard architecture: one PRIMARY database accepts all writes. One or more REPLICAS
        receive a copy of every change from the primary and serve read traffic. Most read-heavy
        workloads (e.g., a typical web application — 90% reads, 10% writes) scale this way for
        a long time before needing anything more complex.
      </P>
      <Code id="replication-shape" lang="text">{`               WRITES                          READS
                  │                              │
                  ▼                              ▼
            ┌──────────┐                    ┌─────────┐
            │ PRIMARY  │ ──── replicates ──▶│ REPLICA │
            │          │                    │   R1    │
            └──────────┘                    └─────────┘
                  │                          ┌─────────┐
                  ├─── replicates ─────────▶│   R2    │
                  │                          └─────────┘
                  │                          ┌─────────┐
                  └─── replicates ─────────▶│   R3    │
                                             └─────────┘

Add replicas to scale READS horizontally. The PRIMARY remains a single
write bottleneck until you outgrow it — at which point you need sharding
(below).`}</Code>

      <H2 num="◇ 02">Synchronous vs asynchronous replication</H2>
      <P>
        The single most important replication decision. Both modes are widely used in production;
        the trade-off determines what failure modes you have.
      </P>
      <Code id="sync-vs-async" lang="text">{`                         ASYNCHRONOUS                  SYNCHRONOUS
                         ────────────                  ───────────
Write latency            Fast (primary acks immediately)  Slow (waits for replica ack)
Throughput               High                             Bounded by slowest replica
Replica lag              Yes (typically ms to seconds)    No (replicas caught up at ack)
Failover data loss       Possible (uncommitted lag)       None (everything was acked)
Most common default      ✓ (Postgres, MySQL, most cloud)  Only for critical workloads

Postgres supports BOTH. Set per-replica:
  synchronous_standby_names = 'replica-1'  → that replica is sync; others async
  synchronous_commit = off                  → fully async (faster, more risk)
  synchronous_commit = on                   → sync (default, balanced)
  synchronous_commit = remote_apply         → wait until replica has APPLIED it`}</Code>
      <P>
        Most production deployments use a hybrid: one synchronous replica (for failover safety)
        plus several asynchronous replicas (for read scaling). The sync replica is your "warm
        standby" — promotable instantly with zero data loss. The async replicas absorb read
        traffic and tolerate brief lag.
      </P>

      <H2 num="◇ 03">Replication lag — what causes it</H2>
      <P>
        Asynchronous replicas are always behind the primary. By how much depends on:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-indigo-300">Network latency</strong> — bytes have to travel from primary to replica</li>
        <li><strong className="text-indigo-300">Replica apply speed</strong> — typically single-threaded (one big transaction blocks subsequent ones)</li>
        <li><strong className="text-indigo-300">Replica load</strong> — heavy read queries on the replica slow its WAL apply</li>
        <li><strong className="text-indigo-300">Long-running primary transactions</strong> — a transaction holding open until commit is replicated all at once</li>
      </ul>
      <P>
        Typical numbers: 10-100ms on the same data center, 100-500ms cross-region, occasional
        spikes to seconds during heavy write bursts. Monitor it with{' '}
        <Kbd>pg_stat_replication.replay_lag</Kbd> on Postgres or equivalent on your platform.
      </P>

      <H2 num="◇ 04">Read-after-write — the consistency problem</H2>
      <P>
        The classic bug: user updates their profile, the app responds "success", user refreshes
        the page, the app fetches their profile from a read replica — and the replica has not
        caught up yet, so the user sees the OLD profile. From their point of view, the update
        was lost. They update again. Confusion compounds.
      </P>
      <P>
        Three established fixes, in order of complexity:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-emerald-400">Read your own writes from the primary.</strong> For a short window after any write (typically 5-10 seconds), route THIS user&apos;s reads to the primary. Other users keep hitting replicas. Simple to implement; effective for the common case.</li>
        <li><strong className="text-emerald-400">Causal consistency via timestamps.</strong> Each write returns a "last write LSN"; the client includes that LSN in subsequent reads; replicas refuse to serve until they have replayed past it. Used by Spanner and CockroachDB natively.</li>
        <li><strong className="text-emerald-400">Synchronous replication for critical paths.</strong> The expensive option — every write waits for replica ack. Reserve for read-after-write-sensitive flows like payment confirmations.</li>
      </ul>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 05">Watch replication lag in action</H2>
      <P>
        Three modes. Hit WRITE — see the primary update immediately, then watch each replica catch
        up with its own simulated lag. Hit READ — see which replica was selected and whether it
        was stale. The first mode shows the bug; the next two show the fixes. Run each mode
        long enough to see the patterns.
      </P>

      <ReplicationSimulator />

      <H2 num="◇ 06">Sharding — when one primary is not enough</H2>
      <P>
        Replication scales READS but not WRITES — the primary remains a single point through which
        every write must flow. When your write throughput outgrows one machine, sharding is the
        answer. Sharding splits the data across multiple databases ("shards"), with each shard
        responsible for a subset of the rows. Each shard is its own primary that accepts writes;
        each can have its own replicas.
      </P>
      <Code id="sharding-shape" lang="text">{`                          APPLICATION
                          ┌─────────┐
                          │ Router  │  ← decides which shard owns a given row
                          └────┬────┘
              ┌────────────────┼────────────────┐
              ▼                ▼                ▼
        ┌──────────┐    ┌──────────┐    ┌──────────┐
        │  SHARD 1 │    │  SHARD 2 │    │  SHARD 3 │
        │ user_id  │    │ user_id  │    │ user_id  │
        │  1-1M    │    │ 1M-2M    │    │ 2M-3M    │
        └──────────┘    └──────────┘    └──────────┘
        (+ replicas)    (+ replicas)    (+ replicas)`}</Code>

      <H2 num="◇ 07">Picking a shard key — the decision you cannot undo</H2>
      <P>
        The shard key is the column that decides which shard owns each row. Get it right and your
        cluster scales linearly. Get it wrong and you end up either rewriting it later (expensive)
        or living with hot shards forever.
      </P>
      <P>
        Properties of a good shard key:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-indigo-300">High cardinality.</strong> Many distinct values, so rows distribute evenly. <Kbd>user_id</Kbd> good; <Kbd>country</Kbd> bad.</li>
        <li><strong className="text-indigo-300">Even access distribution.</strong> No single value gets disproportionate traffic. Sharding by <Kbd>tenant_id</Kbd> when one tenant has 80% of the data creates a hot shard.</li>
        <li><strong className="text-indigo-300">Stable.</strong> The key should not change after a row is created — otherwise the row needs to move between shards. <Kbd>user_id</Kbd> stable; <Kbd>email</Kbd> sometimes not.</li>
        <li><strong className="text-indigo-300">Matches your query patterns.</strong> Most queries should be able to identify the shard from their WHERE clause. Cross-shard queries are slow and complicated.</li>
      </ul>
      <Callout kind="warn" title="HOT SHARDS ARE THE MOST COMMON SHARDING BUG">
        Sharding by <Kbd>user_id</Kbd> with a top-1% customer who generates 60% of traffic creates
        a hot shard. That shard is now your bottleneck — the other 99 shards are bored while one
        is on fire. The fix is harder than the original sharding decision; resharding existing data
        is expensive. Validate distribution BEFORE you commit to a shard key. Look at production
        traffic, not assumptions.
      </Callout>

      <H2 num="◇ 08">CAP theorem — in plain language</H2>
      <P>
        CAP says: when the network between nodes fails (Partition), a distributed system has to
        choose between Consistency and Availability. You cannot have both during a partition.
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-indigo-300">CP systems</strong> (consistency over availability): during a partition, refuse to serve from the partitioned side. The data stays consistent; clients on the wrong side see errors. Examples: Spanner, CockroachDB, MongoDB with strong consistency settings.</li>
        <li><strong className="text-indigo-300">AP systems</strong> (availability over consistency): keep serving from every partition, accept that they will diverge. Reconcile later. Examples: DynamoDB in default mode, Cassandra, most async-replicated Postgres setups under failover.</li>
        <li><strong className="text-indigo-300">CA?</strong> Technically impossible in a distributed system — partitions DO happen on real networks. "CA" usually means "we are a single-node database; if you partition the network, you partition the database too."</li>
      </ul>
      <Callout kind="deep" title="CAP IS A BAD MODEL FOR EVERYDAY DECISIONS">
        CAP is taught as if it&apos;s the framework. It&apos;s not — partitions are RARE in real
        modern infrastructure (network in a cloud datacenter is far more reliable than the textbook
        suggests). The day-to-day reality is the PACELC extension: when a partition (P) happens,
        trade Availability or Consistency (AC); ELSE in normal operation, trade Latency or
        Consistency (LC). The everyday choice — under normal conditions — is latency vs
        consistency. Async replication chooses latency; synchronous chooses consistency. THAT is
        the real trade-off most teams make. Read about PACELC; let CAP be the introduction, not
        the destination.
      </Callout>

      <H2 num="◇ 09">Eventual consistency in practice</H2>
      <P>
        "Eventual consistency" means: if writes stop, replicas eventually converge to the same
        state. It does NOT mean "you can ignore consistency"; it means "be aware that reads can be
        stale for a bounded window." That window matters:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>Postgres async replica: ~10-100ms typical, sometimes more under load</li>
        <li>DynamoDB eventually-consistent read: ~1 second typical</li>
        <li>Cassandra default consistency: sub-second to seconds depending on configuration</li>
        <li>Multi-region replication: hundreds of milliseconds to seconds, dominated by physics</li>
      </ul>
      <P>
        Show the user a stale read that looks fresh and you have a bug. Show them an obviously-loading
        spinner with their write pending and you do not. UX choices around eventual consistency are
        as important as the database choices. Pick one of the read-after-write fixes from earlier
        in this section.
      </P>

      <H2 num="◇ 10">Hardening checklist for replication and scaling</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Read traffic routed to replicas; write traffic to primary; documented in code</li>
        <li>✓ Replication lag monitored with an alert above an actionable threshold (e.g., 5s sustained)</li>
        <li>✓ At least one synchronous replica for failover safety</li>
        <li>✓ Read-your-writes routing for user-initiated writes (5-10s primary sticky window)</li>
        <li>✓ Failover runbook tested in staging — not just "we have replication"</li>
        <li>✓ Shard key chosen with real production data distribution in mind</li>
        <li>✓ Cross-shard queries identified and minimized (or use a query engine like Vitess / Citus)</li>
        <li>✓ Eventual consistency surfaced in UX where it matters (pending states, optimistic UI)</li>
        <li>✓ Region-specific replicas for global users — but understand the data sovereignty implications</li>
        <li>✓ Backup strategy distinct from replication — replicas replicate corruption; backups do not</li>
      </ul>

      {/* ──────────────────────────────────────────────────────────────── */}
      {/* CLOSING — Atlas 20 wrap + arc-opening for the data series       */}
      {/* ──────────────────────────────────────────────────────────────── */}

      <SectionLabel>end of atlas</SectionLabel>
      <H2 num="◆">What you can do now</H2>
      <P>Four sections back, the database was the layer "under everything." Now you can:</P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-indigo-300">Design indexes that earn their keep</strong> — B-trees, composites, selectivity, the leftmost-prefix rule, covering indexes; and when to leave a column unindexed</li>
        <li><strong className="text-indigo-300">Read query plans</strong> — EXPLAIN ANALYZE syntax, scan types, join algorithms, stats; spot when the planner is wrong and what to do about it</li>
        <li><strong className="text-indigo-300">Pick isolation levels deliberately</strong> — RC vs RR vs SERIALIZABLE, what each prevents, when write skew bites, pessimistic vs optimistic locking, deadlocks</li>
        <li><strong className="text-indigo-300">Reason about replication and scaling</strong> — primary/replica, sync vs async, replication lag, read-your-writes, sharding, CAP/PACELC, eventual consistency</li>
      </ul>

      <SectionLabel>opening the data series</SectionLabel>
      <H2 num="◆">The data-systems arc</H2>
      <P>
        The API series (Atlas 17-19) asked three questions of stateless services: what do they do,
        who can use them, how do they survive production. This atlas opens a parallel series for
        the stateful layer underneath — the data systems that make those services possible. Same
        three-question structure, different layer:
      </P>
      <Code id="data-arc" lang="text">{`ATLAS 20 — DATABASES AT SCALE       "How does the data live and move?"
                                     Indexes · query plans · transactions · replication

ATLAS 21 — DISTRIBUTED SYSTEMS       "What happens when one machine is not enough?"
   (planned)                         Consensus · vector clocks · failure modes

ATLAS 22 — EVENT-DRIVEN ARCHITECTURE "What happens when synchronous calls are not enough?"
   (planned)                         Queues · streams · log compaction · exactly-once-ish`}</Code>
      <P>
        Each atlas in the arc assumes the previous ones. Atlas 21 builds on this atlas&apos;s
        replication chapter and pushes it further into Raft, Paxos, vector clocks, and the
        consistency models we glossed in PACELC. Atlas 22 builds on Atlas 19&apos;s idempotency
        chapter and pushes it into message queues, event sourcing, and stream processing.
      </P>
      <Callout kind="win" title="THE SHAPE OF EVERY GOOD DATA LAYER">
        Every system that handles data at scale has the same shape underneath. You now have the
        first layer of that shape. Build a thing with a real database. Hit the bugs (every system
        does). Use the atlas as the lookup when you do. The atlases are reference cards for the
        answers most teams figure out the expensive way — but the reps belong to you.
      </Callout>
      <P>
        Reference index at <Kbd>atlases.vercel.app</Kbd>. The series continues.
      </P>
      <div className="text-zinc-500 text-center text-[10.5px] tracking-[0.3em] uppercase mt-12 mb-4"
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        ▤ · atlas twenty · complete · data series opening
      </div>
    </>
  );
}
