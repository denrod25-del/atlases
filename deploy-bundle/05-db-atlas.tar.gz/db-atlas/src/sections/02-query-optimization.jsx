/* Section 02 — Query Optimization.
 *
 * Prose + Query Plan Comparator.
 *
 * The comparator: three scenarios, each showing the SAME query under two
 * different conditions, with the resulting EXPLAIN ANALYZE outputs side by
 * side. Students see the planner's decisions made visible.
 *
 *   1. "What an index buys you" — with index vs without index
 *   2. "The planner picks the algorithm" — small data vs large data
 *   3. "When stats lie" — fresh statistics vs stale statistics
 *
 * Each scenario surfaces the key metrics (plan type, cost, actual time,
 * rows) so students can compare without parsing the full EXPLAIN text.
 *
 * All prose strings use backticks (template literals) to avoid the
 * apostrophe-in-single-quote parse traps from Atlas 18 section 03.
 */

import { useState } from 'react';
import { Sparkles, Zap, AlertTriangle, TrendingDown, TrendingUp } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Query Plan Comparator
// ───────────────────────────────────────────────────────────────────────

const SCENARIOS = [
  {
    id: 'index-effect',
    label: 'What an index buys you',
    blurb: `The same SELECT, with and without an index on the filtered column. Watch the plan type change and the actual execution time collapse by four orders of magnitude.`,
    sql: `SELECT * FROM orders WHERE customer_id = 4242;`,
    setup: `orders table: 10,000,000 rows · 42 rows match customer_id=4242`,
    planA: {
      label: 'Without index',
      tone: 'bad',
      explain: `Seq Scan on orders
  (cost=0.00..289037.00 rows=21 width=240)
  (actual time=12.451..8421.298 rows=42 loops=1)
  Filter: (customer_id = 4242)
  Rows Removed by Filter: 9999958
Planning Time: 0.082 ms
Execution Time: 8421.317 ms`,
      metrics: {
        planType: 'Seq Scan',
        rowsScanned: '10,000,000',
        rowsReturned: '42',
        actualTime: '8421 ms',
        cost: '289037.00',
      },
    },
    planB: {
      label: 'With index on customer_id',
      tone: 'good',
      explain: `Index Scan using orders_customer_idx on orders
  (cost=0.43..82.50 rows=21 width=240)
  (actual time=0.023..1.241 rows=42 loops=1)
  Index Cond: (customer_id = 4242)
Planning Time: 0.063 ms
Execution Time: 1.265 ms`,
      metrics: {
        planType: 'Index Scan',
        rowsScanned: '42',
        rowsReturned: '42',
        actualTime: '1.2 ms',
        cost: '82.50',
      },
    },
    verdict: {
      tone: 'good',
      headline: `Speedup: ~6700× from a single CREATE INDEX statement`,
      text: `Without the index, the planner has no choice: it walks all 10 million rows, testing customer_id on each one. With the index, it descends a B-tree (depth ~4 on a table this size) and reads only the 42 matching rows. The cost estimate dropped 3500×; actual time dropped 6700×. This is the difference one well-chosen index makes.`,
    },
  },
  {
    id: 'planner-adapts',
    label: 'The planner picks the algorithm',
    blurb: `Same join query, two different data shapes. The planner chooses a different algorithm for each — and both choices are correct for their situation. Knowing why each one wins teaches you when to suspect a wrong choice.`,
    sql: `SELECT o.*, c.name
FROM orders o
JOIN customers c ON o.customer_id = c.id
WHERE c.country = 'US';`,
    setup: `Indexes on orders.customer_id and customers.country exist`,
    planA: {
      label: 'Small filtered set (~50 US customers)',
      tone: 'good',
      explain: `Nested Loop
  (cost=0.43..142.21 rows=80 width=350)
  (actual time=0.245..3.812 rows=80 loops=1)
  ->  Index Scan on customers c
        (cost=0.42..8.45 rows=50 width=110)
        Index Cond: country = 'US'
  ->  Index Scan using orders_customer_idx on orders o
        (cost=0.43..2.66 rows=2 width=240)
        Index Cond: customer_id = c.id
Planning Time: 0.231 ms
Execution Time: 3.95 ms`,
      metrics: {
        planType: 'Nested Loop',
        rowsScanned: '50 customers × ~1.6 orders',
        rowsReturned: '80',
        actualTime: '3.95 ms',
        cost: '142.21',
      },
    },
    planB: {
      label: 'Large filtered set (~750K US customers)',
      tone: 'good',
      explain: `Hash Join
  (cost=21042.00..89321.45 rows=4500000 width=350)
  (actual time=312.4..2841.7 rows=4502123 loops=1)
  Hash Cond: o.customer_id = c.id
  ->  Seq Scan on orders o
        (cost=0.00..52331.00 rows=10000000 width=240)
  ->  Hash
        (cost=18000.00..18000.00 rows=750000 width=110)
        ->  Seq Scan on customers c
              Filter: country = 'US'
              (rows=750000)
Planning Time: 0.387 ms
Execution Time: 2843.1 ms`,
      metrics: {
        planType: 'Hash Join',
        rowsScanned: '10M orders + 750K customers',
        rowsReturned: '4,502,123',
        actualTime: '2.84 s',
        cost: '89321.45',
      },
    },
    verdict: {
      tone: 'good',
      headline: `Both plans are optimal for their data shape`,
      text: `Nested Loop wins when the outer set is small (50 customers) because each outer row triggers a cheap index lookup on the inner. Hash Join wins when the outer set is large (750K customers) because building one hash table beats doing 750,000 separate index lookups. The planner does this math from row-count estimates. When it gets the estimate wrong, it picks the wrong algorithm — which is the scenario in tab 3.`,
    },
  },
  {
    id: 'stats-lie',
    label: 'When stats lie',
    blurb: `Identical query, identical data, different STATISTICS. After bulk-inserting 10M rows without running ANALYZE, the planner is making decisions based on row-count estimates from when the table was much smaller. The result: a query that worked fine yesterday now seq-scans.`,
    sql: `SELECT * FROM orders
WHERE status = 'pending' AND created_at > '2026-01-01';`,
    setup: `Composite index on (status, created_at) exists. ~50K rows match.`,
    planA: {
      label: 'After ANALYZE (fresh statistics)',
      tone: 'good',
      explain: `Bitmap Heap Scan on orders
  (cost=421.00..12421.00 rows=50000 width=240)
  (actual time=3.821..87.243 rows=50124 loops=1)
  Recheck Cond: status = 'pending' AND created_at > '2026-01-01'
  ->  Bitmap Index Scan on orders_status_created_idx
        (cost=0.00..408.50 rows=50000 width=0)
        Index Cond: status = 'pending' AND created_at > '2026-01-01'
Planning Time: 0.142 ms
Execution Time: 89.1 ms`,
      metrics: {
        planType: 'Bitmap Heap Scan',
        rowsScanned: '50,000',
        rowsReturned: '50,124',
        actualTime: '89 ms',
        cost: '12421.00',
      },
    },
    planB: {
      label: 'Stale statistics (table grew 100× since ANALYZE)',
      tone: 'bad',
      explain: `Seq Scan on orders
  (cost=0.00..289037.00 rows=5000000 width=240)
  (actual time=15.2..8243.7 rows=50124 loops=1)
  Filter: status = 'pending' AND created_at > '2026-01-01'
  Rows Removed by Filter: 9949876
Planning Time: 0.221 ms
Execution Time: 8245.8 ms`,
      metrics: {
        planType: 'Seq Scan',
        rowsScanned: '10,000,000',
        rowsReturned: '50,124',
        actualTime: '8.25 s',
        cost: '289037.00',
      },
    },
    verdict: {
      tone: 'bad',
      headline: `Same data. Same query. Same index. 92× slower because the planner trusted bad numbers.`,
      text: `The planner saw a row estimate of 5,000,000 matches (out of an assumed 50,000 total rows from old stats) and concluded "this returns most of the table — index scan is not worth it; just scan everything." But the table actually has 10M rows and only 50K match. With fresh stats, it would have picked the bitmap scan. The fix is ANALYZE — Postgres auto-runs it, but bulk inserts can race ahead of it. Run ANALYZE manually after any large data change.`,
    },
  },
];

const TONE_STYLES = {
  good: { border: 'border-indigo-300/60', bg: 'bg-indigo-300/5',   accent: 'text-indigo-300',  ring: 'ring-indigo-300/30' },
  bad:  { border: 'border-rose-400/60',   bg: 'bg-rose-400/5',     accent: 'text-rose-400',    ring: 'ring-rose-400/30' },
};

function PlanCard({ plan }) {
  const t = TONE_STYLES[plan.tone];
  const Icon = plan.tone === 'good' ? TrendingDown : TrendingUp;
  return (
    <div className={`border ${t.border} ${t.bg} p-3`}>
      <div className="flex items-center justify-between mb-2">
        <div className="text-zinc-200 text-[12.5px] font-semibold">{plan.label}</div>
        <Icon size={14} className={t.accent} />
      </div>

      <pre className={`bg-zinc-950/80 border border-zinc-800 p-2.5 text-[10.5px] text-zinc-200 overflow-x-auto leading-relaxed mb-2`}
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        <code>{plan.explain}</code>
      </pre>

      <div className="grid grid-cols-2 gap-1 text-[11px]"
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        <div className="text-zinc-500">plan</div>
        <div className={`${t.accent} font-semibold`}>{plan.metrics.planType}</div>
        <div className="text-zinc-500">rows scanned</div>
        <div className="text-zinc-200">{plan.metrics.rowsScanned}</div>
        <div className="text-zinc-500">rows returned</div>
        <div className="text-zinc-200">{plan.metrics.rowsReturned}</div>
        <div className="text-zinc-500">actual time</div>
        <div className={`${t.accent} font-bold`}>{plan.metrics.actualTime}</div>
        <div className="text-zinc-500">cost estimate</div>
        <div className="text-zinc-200">{plan.metrics.cost}</div>
      </div>
    </div>
  );
}

function QueryPlanComparator() {
  const [idx, setIdx] = useState(0);
  const scenario = SCENARIOS[idx];
  const vt = TONE_STYLES[scenario.verdict.tone];

  return (
    <div className="my-6 border border-indigo-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-indigo-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-indigo-300" />
          <span className="text-indigo-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · query plan comparator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => setIdx(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === idx
                  ? 'border-indigo-300 bg-indigo-300/15 text-indigo-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-indigo-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {i + 1}. {s.label}
            </button>
          ))}
        </div>

        {/* Scenario description */}
        <div className="mb-3 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13.5px] leading-relaxed italic">
          {scenario.blurb}
        </div>

        {/* SQL query */}
        <div className="mb-3">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            the query
          </div>
          <pre className="bg-zinc-950/80 border border-zinc-800 p-2.5 text-[12px] text-zinc-200 overflow-x-auto leading-relaxed"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <code>{scenario.sql}</code>
          </pre>
          <div className="text-zinc-500 text-[11px] mt-1 italic">{scenario.setup}</div>
        </div>

        {/* Two plans side by side */}
        <div className="grid md:grid-cols-2 gap-3 mb-4">
          <PlanCard plan={scenario.planA} />
          <PlanCard plan={scenario.planB} />
        </div>

        {/* Verdict */}
        <div className={`border ${vt.border} ${vt.bg} p-4`}>
          <div className={`text-[11px] tracking-[0.25em] uppercase font-semibold mb-1.5 flex items-center gap-2 ${vt.accent}`}
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            {scenario.verdict.tone === 'good' ? <Zap size={12} /> : <AlertTriangle size={12} />}
            {scenario.verdict.headline}
          </div>
          <div className="text-zinc-200 text-[13.5px] leading-relaxed">
            {scenario.verdict.text}
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section02_QueryOpt() {
  return (
    <>
      <SectionLabel>section 02</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Query optimization — speaking the planner&apos;s language
      </h2>
      <P>
        Indexes are the data structure. The query planner decides whether to USE them. Two queries
        that look identical can run a thousand times apart in latency, and the only difference is
        which plan the database chose. This section is about reading those plans, understanding
        why the planner makes the choices it does, and recognizing when it picks badly.
      </P>

      <H2 num="◇ 01">The query planner&apos;s job</H2>
      <P>
        When you send <Kbd>SELECT * FROM orders WHERE customer_id = 4242</Kbd>, the database does
        not just execute that text. It first builds a PLAN — a tree of operations that, run in
        order, produce the result set. There are usually many possible plans for a given query.
        The planner&apos;s job is to estimate the cost of each candidate plan and pick the cheapest.
      </P>
      <Code id="planner-overview" lang="text">{`POSSIBLE PLANS for "WHERE customer_id = 4242":

  PLAN 1   Seq Scan on orders, filter rows where customer_id=4242
              cost: 289,037 (must read all 10M rows)

  PLAN 2   Index Scan on orders_customer_idx, fetch matching rows
              cost: 82 (descend index, read ~42 rows)

  PLAN 3   Bitmap Index Scan → Bitmap Heap Scan
              cost: 95 (build a bitmap of rowids, then fetch in sequential order)

The planner estimates each cost using table statistics (how many rows? how
many distinct values? what is the value distribution?) and picks the
cheapest. PLAN 2 wins here — by 3000x.`}</Code>

      <H2 num="◇ 02">EXPLAIN and EXPLAIN ANALYZE</H2>
      <P>
        These two commands are the most useful database tools you have. They show you what the
        planner picked AND, with ANALYZE, what actually happened when the plan ran.
      </P>
      <Code id="explain-vs-analyze" lang="sql">{`-- EXPLAIN — show the plan, do NOT run the query
EXPLAIN SELECT * FROM orders WHERE customer_id = 4242;

-- EXPLAIN ANALYZE — run the query and show the plan WITH actual timings
EXPLAIN ANALYZE SELECT * FROM orders WHERE customer_id = 4242;

-- EXPLAIN ANALYZE BUFFERS — same plus how much I/O actually happened
EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT * FROM orders WHERE customer_id = 4242;`}</Code>
      <P>
        Read EXPLAIN output bottom-up: leaf operations execute first, their results feed the
        operations above, all the way to the root. Each operation has a cost range
        (<Kbd>cost=startup..total</Kbd>) and an estimated row count. With ANALYZE you also get
        actual time and actual row counts — the gap between estimated and actual is often where
        bugs live.
      </P>
      <Callout kind="deep" title="THE TWO COST NUMBERS">
        <Kbd>cost=0.43..82.50</Kbd> — the first number is the "startup cost" (work done before
        the first row is returned), the second is the "total cost" (work done to return all rows).
        For queries with LIMIT, the planner optimizes for startup cost; for queries without LIMIT,
        for total cost. That is why <Kbd>SELECT ... LIMIT 10</Kbd> sometimes picks a different
        plan than the same query without the LIMIT.
      </Callout>

      <H2 num="◇ 03">The scan types you will see</H2>
      <P>
        Most of what you encounter in EXPLAIN output falls into a handful of "node types." Knowing
        what each one means lets you read any plan:
      </P>
      <Code id="scan-types" lang="text">{`NODE TYPE              WHAT IT MEANS                                  WHEN IT WINS
─────────              ─────────────                                  ─────────────
Seq Scan               Read every row of the table, filter as we go    Small tables, OR matches > ~20% of rows
Index Scan             Descend the index, fetch matching table rows    Selective filter on indexed columns
Index Only Scan        Descend the index, return columns from index    "Covering" — index includes all SELECT columns
Bitmap Heap Scan       Build a bitmap of matching rowids,              Mid-selectivity OR multiple indexed conditions
                       fetch them in sorted (sequential) order
Bitmap Index Scan      Produces the bitmap consumed by Bitmap Heap     Always paired above
Nested Loop            For each outer row, look up matching inner rows Small outer set, indexed inner
Hash Join              Build a hash table of one side, probe with other Large inputs, equality join
Merge Join             Both inputs already sorted on join key,         Both inputs sorted (rare; usually via index)
                       merge in one pass`}</Code>

      <H2 num="◇ 04">Join algorithms — the planner picks one</H2>
      <P>
        Three join algorithms cover essentially all relational joins:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-indigo-300">Nested Loop.</strong> For every row in table A, look up the matching rows in table B (typically via index on B). Wins when A is small AND B has a useful index. Time grows roughly as |A| × log|B|.
        </li>
        <li>
          <strong className="text-indigo-300">Hash Join.</strong> Build a hash table of one side (the smaller one — the "build" side), then scan the other side ("probe" side) and look up each row in the hash. Wins for large equality joins. Time grows roughly as |A| + |B|.
        </li>
        <li>
          <strong className="text-indigo-300">Merge Join.</strong> If both sides are already sorted on the join key, walk them together in a single pass. Wins when sorting is free (both sides come from an indexed scan). Time grows as |A| + |B| but with very low constants.
        </li>
      </ul>
      <P>
        The planner picks based on row-count estimates and the cost of each algorithm at those
        sizes. Different join algorithms for the same query against the same data are completely
        normal — and the comparator below shows exactly that.
      </P>

      <H2 num="◇ 05">Statistics — how the planner knows what to estimate</H2>
      <P>
        Estimates come from statistics the database collects in the background. In Postgres these
        live in <Kbd>pg_statistic</Kbd> and are updated by autovacuum&apos;s ANALYZE runs. They
        include:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>Total row count per table (approximate)</li>
        <li>Number of distinct values per column (<Kbd>n_distinct</Kbd>)</li>
        <li>The most common values and their frequencies (<Kbd>most_common_vals</Kbd>)</li>
        <li>A histogram of value distribution for selectivity estimates on ranges</li>
        <li>Per-column null fraction</li>
      </ul>
      <Callout kind="warn" title="STATS GO STALE — ESPECIALLY AFTER BULK CHANGES">
        Postgres autovacuum runs ANALYZE periodically, but bulk inserts, large deletes, or schema
        migrations can race ahead of it. The planner is then making decisions based on what the
        table USED TO look like. The fix is to run <Kbd>ANALYZE table_name</Kbd> manually after
        any bulk data change. Cheap to run; saves you from the "fast query yesterday, broken
        today" mystery.
      </Callout>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 06">Read three pairs of plans</H2>
      <P>
        Three scenarios, each showing the same query under two conditions. Watch how the plan type,
        cost estimate, and actual time all change. The first scenario is the classic
        "this is what indexes do." The second shows the planner adapting to data shape — both plans
        are correct, just optimal for different inputs. The third is the most subtle: same data,
        same query, different STATISTICS — and a 92× slowdown caused by trusting old numbers.
      </P>

      <QueryPlanComparator />

      <H2 num="◇ 07">When the planner gets it wrong</H2>
      <P>
        Even with fresh statistics, the planner sometimes picks badly. The common causes:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-rose-400">Correlated columns.</strong> The planner assumes column
          selectivities are independent. If 90% of orders with <Kbd>status=&apos;shipped&apos;</Kbd> also
          have <Kbd>shipped_at IS NOT NULL</Kbd>, the planner does not know that — it estimates as
          if the conditions were independent and gets the row count off by 10×. Postgres has{' '}
          <Kbd>CREATE STATISTICS</Kbd> for multi-column statistics; use it where it matters.
        </li>
        <li>
          <strong className="text-rose-400">Skewed value distributions.</strong> A few values that
          appear in 90% of rows can confuse the planner about what AVERAGE selectivity looks like.
          The <Kbd>most_common_vals</Kbd> histogram helps but is bounded in size — heavily skewed
          columns may need <Kbd>SET STATISTICS</Kbd> bumped.
        </li>
        <li>
          <strong className="text-rose-400">Parameterized queries.</strong> When the planner sees
          <Kbd>WHERE col = $1</Kbd> at PREPARE time, it does not know what <Kbd>$1</Kbd> will be.
          It builds a "generic plan" that works for any value — not the optimal plan for the
          actual value you pass in. Postgres falls back to per-execution planning after several
          calls; sometimes you want to skip the generic plan entirely with{' '}
          <Kbd>plan_cache_mode = force_custom_plan</Kbd>.
        </li>
        <li>
          <strong className="text-rose-400">Function calls in WHERE clauses.</strong>{' '}
          <Kbd>WHERE LOWER(email) = &apos;cle@x.com&apos;</Kbd> cannot use a regular index on email — the
          function blocks the planner from using the index. Either index the function
          (<Kbd>CREATE INDEX ON users (LOWER(email))</Kbd>) or store the lowercased form in a column.
        </li>
      </ul>

      <H2 num="◇ 08">statement_timeout — defense against runaway plans</H2>
      <P>
        Even after careful indexing, you will eventually ship a query that produces a bad plan
        on production data. Without protection, a single bad query can saturate a database
        connection for minutes, blocking other queries behind it. The defense is timeouts:
      </P>
      <Code id="statement-timeout" lang="sql">{`-- Set a session-wide timeout
SET statement_timeout = '5s';

-- Or set it in the connection string
postgresql://user:pass@host/db?statement_timeout=5000

-- For Django:
DATABASES = {
    "default": {
        ...
        "OPTIONS": {"options": "-c statement_timeout=5000"},
    }
}

-- For different timeouts on different endpoints:
SET LOCAL statement_timeout = '30s';   -- inside a transaction, just for this txn`}</Code>
      <P>
        A 5-second timeout for user-facing queries, 30-60 seconds for reporting/admin endpoints,
        is a reasonable starting point. The bad query gets killed cleanly; the user sees an error
        instead of an indefinite hang; the database recovers immediately.
      </P>

      <H2 num="◇ 09">Hardening checklist for query optimization</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Every new query reviewed with EXPLAIN ANALYZE on production-realistic data</li>
        <li>✓ Estimated vs actual row counts checked — large gaps mean stats are stale or correlated columns</li>
        <li>✓ Sequential scans flagged on tables with more than ~10K rows (often a missing index)</li>
        <li>✓ ANALYZE run manually after bulk inserts or large schema changes</li>
        <li>✓ Multi-column statistics created for correlated column pairs</li>
        <li>✓ Function calls in WHERE clauses replaced with indexable column expressions, or indexed via functional indexes</li>
        <li>✓ <Kbd>statement_timeout</Kbd> set per role / per endpoint (short for user-facing, longer for admin)</li>
        <li>✓ <Kbd>auto_explain</Kbd> enabled in production to log slow queries with their plans</li>
        <li>✓ A "slow query log" reviewed weekly; recurring offenders get attention</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Indexes and plans are about one query at a time. Section 03 covers what happens when MANY
        queries run at once — transactions, isolation levels, and the four anomalies that show up
        when concurrent code touches the same rows.
      </Callout>
    </>
  );
}
