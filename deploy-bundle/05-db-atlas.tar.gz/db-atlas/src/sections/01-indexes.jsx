/* Section 01 — Indexes.
 *
 * Prose + B-Tree Index Visualizer.
 *
 * The visualizer: a static, pre-built B-tree with 27 values across 9 leaves
 * at depth 3. The student picks a value to look up, then chooses "with index"
 * or "sequential scan" and watches the animated traversal.
 *
 *   - WITH INDEX: 3 hops from root → internal → leaf, ~3 disk reads
 *   - SEQUENTIAL SCAN: walks every node looking for the value, ~13 reads
 *
 * The numeric comparison + visible traversal teaches O(log n) vs O(n) in a
 * way that prose alone cannot. Two modes are animated; user can run them
 * head to head on the same target value.
 *
 * All prose strings use backticks (template literals) to avoid the
 * apostrophe-in-single-quote parse traps from Atlas 18 section 03.
 */

import { useState, useEffect, useRef } from 'react';
import { Sparkles, Search, Layers, Zap, RotateCcw } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// B-Tree Index Visualizer
// ───────────────────────────────────────────────────────────────────────

// Pre-built B-tree of depth 3. Root (1 key) → internal (2 keys × 2 nodes)
// → leaf (3 keys × 9 nodes). Sorted ascending: 5, 10, 15, 22, 28, 30, ...
//
// Each node has an id (used for highlight tracking) and a list of keys.
// Leaves additionally store nothing else — the keys ARE the data for this
// demo (a heap index would have row pointers; an InnoDB primary-key index
// would have full rows; we simplify to just the keys).

const TREE = {
  id: 'root',
  keys: [50],
  children: [
    {
      id: 'i-left',
      keys: [20, 35],
      children: [
        { id: 'l-1', keys: [5, 10, 15] },
        { id: 'l-2', keys: [22, 28, 30] },
        { id: 'l-3', keys: [38, 42, 45] },
      ],
    },
    {
      id: 'i-right',
      keys: [65, 80],
      children: [
        { id: 'l-4', keys: [55, 60, 62] },
        { id: 'l-5', keys: [68, 72, 75] },
        { id: 'l-6', keys: [82, 88, 95] },
      ],
    },
  ],
};

// Flatten all leaf nodes in left-to-right order (for sequential-scan mode)
function flattenLeavesLR(node) {
  if (!node.children) return [node];
  return node.children.flatMap(flattenLeavesLR);
}
const LEAF_ORDER = flattenLeavesLR(TREE);

// All keys in the tree, sorted
const ALL_KEYS = LEAF_ORDER.flatMap(l => l.keys);

// Walk root → leaf to find the path for a given key value.
// Returns the ordered list of node ids visited.
function indexPath(node, target) {
  const path = [node.id];
  if (!node.children) return path;  // leaf
  // Find which child to descend into based on the node's keys
  let childIdx = 0;
  for (let i = 0; i < node.keys.length; i++) {
    if (target < node.keys[i]) { childIdx = i; break; }
    childIdx = i + 1;
  }
  return path.concat(indexPath(node.children[childIdx], target));
}

// ───────────────────────────────────────────────────────────────────────
// Visualizer
// ───────────────────────────────────────────────────────────────────────

function BTreeVisualizer() {
  const [target, setTarget] = useState(42);
  const [mode, setMode] = useState(null);          // null | 'index' | 'scan'
  const [highlighted, setHighlighted] = useState(new Set());
  const [done, setDone] = useState(false);
  const [steps, setSteps] = useState(0);
  const timerRef = useRef([]);

  // Clear any pending animation timers
  const clearTimers = () => {
    timerRef.current.forEach(clearTimeout);
    timerRef.current = [];
  };

  useEffect(() => () => clearTimers(), []);

  const reset = () => {
    clearTimers();
    setMode(null);
    setHighlighted(new Set());
    setDone(false);
    setSteps(0);
  };

  const run = (m) => {
    clearTimers();
    setMode(m);
    setHighlighted(new Set());
    setDone(false);

    const path = m === 'index'
      ? indexPath(TREE, target)
      : ['root', 'i-left', ...LEAF_ORDER.map(l => l.id).slice(0, LEAF_ORDER.findIndex(l => l.keys.includes(target)) + 1)];

    // For sequential scan, we walk through leaves left-to-right. Approximate
    // step count: 1 (root descent) + 1 (first internal) + N leaves visited.
    setSteps(path.length);

    path.forEach((id, i) => {
      const t = setTimeout(() => {
        setHighlighted(prev => new Set([...prev, id]));
        if (i === path.length - 1) setDone(true);
      }, i * 420);
      timerRef.current.push(t);
    });
  };

  const indexHops = indexPath(TREE, target).length;
  const scanHops = (() => {
    const idx = LEAF_ORDER.findIndex(l => l.keys.includes(target));
    return 2 + (idx + 1);  // root + internal + leaves walked
  })();

  // Pick a node visual style based on highlight + mode
  const nodeStyle = (id) => {
    const hl = highlighted.has(id);
    if (!hl) return 'border-zinc-700 bg-zinc-900/60 text-zinc-400';
    if (mode === 'index') return 'border-indigo-300 bg-indigo-300/15 text-indigo-100 ring-1 ring-indigo-300/50';
    if (mode === 'scan')  return 'border-amber-400 bg-amber-400/15 text-amber-100 ring-1 ring-amber-400/40';
    return 'border-zinc-700 bg-zinc-900/60 text-zinc-400';
  };

  // Render a key-cell — highlight the matching key specifically when the
  // node is in the highlighted set AND contains target
  const KeyCell = ({ k, nodeId }) => {
    const matched = highlighted.has(nodeId) && k === target && done;
    return (
      <span className={`px-1.5 py-0.5 text-[12px] ${matched ? 'bg-emerald-400 text-zinc-950 font-bold rounded-sm' : ''}`}
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        {k}
      </span>
    );
  };

  const NodeBox = ({ node }) => (
    <div className={`inline-flex items-center gap-1 px-2 py-1.5 border transition-colors ${nodeStyle(node.id)}`}>
      {node.keys.map((k, i) => (
        <span key={i} className="flex items-center gap-1">
          <KeyCell k={k} nodeId={node.id} />
          {i < node.keys.length - 1 && <span className="text-zinc-700">·</span>}
        </span>
      ))}
    </div>
  );

  return (
    <div className="my-6 border border-indigo-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-indigo-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-indigo-300" />
          <span className="text-indigo-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · b-tree index visualizer
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Tree visualization — 3 levels using flex columns */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-5 mb-4 overflow-x-auto">
          {/* Root */}
          <div className="flex justify-center mb-6">
            <NodeBox node={TREE} />
          </div>
          {/* Internal level */}
          <div className="flex justify-around mb-6 gap-4">
            {TREE.children.map(c => <NodeBox key={c.id} node={c} />)}
          </div>
          {/* Leaves */}
          <div className="flex justify-between gap-1 flex-wrap">
            {TREE.children.flatMap(ic => ic.children).map(leaf => (
              <NodeBox key={leaf.id} node={leaf} />
            ))}
          </div>
          {/* Depth labels */}
          <div className="mt-4 pt-3 border-t border-zinc-800 flex justify-between text-[10px] text-zinc-600"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <span>27 keys total · depth 3 · branching factor ~3</span>
            <span>each level approximately doubles capacity</span>
          </div>
        </div>

        {/* Controls — value picker + run buttons */}
        <div className="grid md:grid-cols-2 gap-3 mb-4">
          <div className="border border-zinc-800 bg-zinc-900/40 p-3">
            <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              look up which key?
            </div>
            <div className="flex flex-wrap gap-1">
              {ALL_KEYS.map(k => (
                <button key={k} onClick={() => { setTarget(k); reset(); }}
                  className={`px-2 py-1 border text-[11px] transition-colors ${
                    k === target
                      ? 'border-indigo-300 bg-indigo-300/15 text-indigo-200'
                      : 'border-zinc-800 text-zinc-500 hover:border-indigo-300/50 hover:text-zinc-200'
                  }`}
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {k}
                </button>
              ))}
            </div>
          </div>

          <div className="border border-zinc-800 bg-zinc-900/40 p-3 flex flex-col">
            <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              search strategy
            </div>
            <div className="flex flex-col gap-2 flex-1">
              <button onClick={() => run('index')}
                className="px-3 py-2 border border-indigo-300 bg-indigo-300/10 text-indigo-200 hover:bg-indigo-300/20 transition-colors text-[12px] flex items-center justify-between font-semibold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <span className="flex items-center gap-2">
                  <Search size={12} />
                  with index (b-tree descent)
                </span>
                <span className="text-[10.5px] opacity-70">~{indexHops} hops</span>
              </button>
              <button onClick={() => run('scan')}
                className="px-3 py-2 border border-amber-400 bg-amber-400/10 text-amber-200 hover:bg-amber-400/20 transition-colors text-[12px] flex items-center justify-between font-semibold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <span className="flex items-center gap-2">
                  <Layers size={12} />
                  sequential scan
                </span>
                <span className="text-[10.5px] opacity-70">~{scanHops} hops</span>
              </button>
              <button onClick={reset}
                className="px-3 py-1.5 border border-zinc-700 text-zinc-500 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[11px] flex items-center gap-1.5"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <RotateCcw size={10} /> reset highlight
              </button>
            </div>
          </div>
        </div>

        {/* Verdict after a run completes */}
        {done && mode && (
          <div className={`border p-3 ${
            mode === 'index'
              ? 'border-indigo-300 bg-indigo-300/10'
              : 'border-amber-400 bg-amber-400/10'
          }`}>
            <div className={`text-[11px] tracking-[0.25em] uppercase font-semibold mb-1 flex items-center gap-2 ${
              mode === 'index' ? 'text-indigo-300' : 'text-amber-400'
            }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {mode === 'index' ? <Zap size={12} /> : <Layers size={12} />}
              {mode === 'index' ? `index lookup complete` : `sequential scan complete`}
            </div>
            <div className="text-zinc-200 text-[13px] leading-relaxed">
              {mode === 'index' ? (
                <>
                  Found <Kbd>{target}</Kbd> in <strong className="text-indigo-200">{steps} node reads</strong> ({steps} disk I/O on a cold cache). On a million-row table the depth would still be ~3-4 — that is the entire point of the B-tree: O(log n) seek time regardless of dataset size.
                </>
              ) : (
                <>
                  Walked through <strong className="text-amber-200">{steps} nodes</strong> to find <Kbd>{target}</Kbd>. On this 27-key tree the cost is bearable. On a million-row table without an index, the equivalent scan would touch every page of the table — typically thousands of reads. That is why the indexed query in the comparator below runs 100,000× faster than the unindexed one at scale.
                </>
              )}
            </div>
          </div>
        )}

        {/* Pre-run note */}
        {!done && (
          <div className="border border-zinc-800 bg-zinc-900/40 p-3 text-zinc-400 text-[12.5px] leading-relaxed italic">
            Pick a key from the grid above, then choose a search strategy. The traversal animates so you can count the steps each strategy takes. Watch how the index ALWAYS takes ~3 hops regardless of which key you target — while sequential scan&apos;s cost grows with how far into the table the value sits.
          </div>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section01_Indexes() {
  return (
    <>
      <SectionLabel>section 01</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Indexes — how lookups actually go fast
      </h2>
      <P>
        Every database query that does not have an index falls back to reading the entire table.
        That works fine on dev seed data and starts to fall apart somewhere between 10K and 1M
        rows. The right index turns a multi-second scan into a sub-millisecond lookup. The wrong
        index slows down every write without speeding up the queries that need it. This section
        is about which is which.
      </P>

      <H2 num="◇ 01">What an index actually is</H2>
      <P>
        An index is a separate data structure that the database maintains alongside your table,
        designed to answer "where are the rows with this value?" faster than scanning the table
        itself. The conceptual model:
      </P>
      <Code id="index-mental-model" lang="text">{`TABLE: orders (10 million rows on disk, unordered by insertion time)
  row 1     id=1     customer_id=4242  amount=99.50  ...
  row 2     id=2     customer_id=8801  amount=12.00  ...
  row 3     id=3     customer_id=4242  amount=8.99   ...
  ...
  row 10M  id=10M   customer_id=4242  amount=22.10  ...

QUESTION: get me every order for customer_id=4242

WITHOUT INDEX:
  Scan every one of the 10 million rows. Test each customer_id against 4242.
  Maybe 50,000 rows match. Cost: 10 million row reads.

WITH INDEX ON customer_id:
  Index entries sorted by customer_id, each pointing back to its table row.
    ...
    customer_id=4242  → rows 1, 3, 7, 12, 89, ..., 10M  (50K entries)
    customer_id=4243  → rows 4, 22, ...
    ...
  Database descends the index to customer_id=4242 (3-4 reads on a B-tree),
  then follows the 50K row pointers. Cost: ~50K reads. 200x faster.`}</Code>

      <H2 num="◇ 02">The B-tree — the index most databases use</H2>
      <P>
        Almost every relational database uses B-trees (technically B+ trees in most implementations)
        as the default index structure. The B-tree is a wide, shallow tree where:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>Each node holds many keys (hundreds to thousands in real implementations)</li>
        <li>Keys within a node are sorted</li>
        <li>Each key acts as a "router" — values less than it go to one child, values greater go to another</li>
        <li>All leaves sit at the same depth</li>
        <li>Depth grows logarithmically: doubling the data adds maybe one level</li>
      </ul>
      <P>
        Concrete: a B-tree with a fan-out of 100 holds 100 million entries at depth 4. Looking up
        any single entry takes 4 disk reads. That is the entire reason indexed lookups are fast.
      </P>
      <Callout kind="deep" title="WHY NOT JUST USE A HASH MAP?">
        Hash indexes exist (Postgres has <Kbd>USING HASH</Kbd>; Redis is one big hash table). Hash
        beats B-tree for single-key equality lookups. But hash indexes cannot serve range queries
        (<Kbd>WHERE id BETWEEN 1000 AND 2000</Kbd>), cannot serve <Kbd>ORDER BY</Kbd>, and cannot
        be used for prefix matches. B-trees can do all of those because their leaves are sorted.
        That versatility is why B-trees are the default.
      </Callout>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 03">Watch the descent vs the scan</H2>
      <P>
        Pick a key from the grid. Choose either "with index" (descend the B-tree) or "sequential
        scan" (walk every node). The visualization runs at human speed so you can count the
        traversal steps each strategy takes. The lesson: index hops stay constant regardless of
        which key you target; scan cost grows with the position of the target.
      </P>

      <BTreeVisualizer />

      <H2 num="◇ 04">Composite indexes — column order matters</H2>
      <P>
        Real indexes often cover multiple columns. The key insight: a composite index on{' '}
        <Kbd>(a, b, c)</Kbd> can serve queries that filter by a leftmost prefix — meaning{' '}
        <Kbd>(a)</Kbd>, <Kbd>(a, b)</Kbd>, or <Kbd>(a, b, c)</Kbd> — but NOT queries that skip{' '}
        <Kbd>a</Kbd> and filter only by <Kbd>b</Kbd> or <Kbd>c</Kbd>.
      </P>
      <Code id="composite-prefix" lang="sql">{`-- Composite index
CREATE INDEX idx_orders ON orders (customer_id, status, created_at);

-- USES the index — leftmost prefix
SELECT * FROM orders WHERE customer_id = 4242;                              -- ✓
SELECT * FROM orders WHERE customer_id = 4242 AND status = 'pending';       -- ✓
SELECT * FROM orders WHERE customer_id = 4242
  AND status = 'pending' AND created_at > '2026-01-01';                     -- ✓

-- Does NOT use the index — skips the leftmost column
SELECT * FROM orders WHERE status = 'pending';                              -- ✗ (falls back to scan)
SELECT * FROM orders WHERE created_at > '2026-01-01';                       -- ✗

-- The leftmost-prefix rule is the reason a composite index can replace
-- multiple single-column indexes when designed thoughtfully — and the
-- reason it does nothing when designed wrong.`}</Code>

      <H2 num="◇ 05">Index selectivity — why some indexes are useless</H2>
      <P>
        An index on a column with very few distinct values does almost nothing. If a{' '}
        <Kbd>gender</Kbd> column has 3 possible values (M / F / NULL), an index lookup for{' '}
        <Kbd>WHERE gender = &apos;F&apos;</Kbd> still has to read roughly a third of the table. The
        planner often skips the index entirely and seq-scans anyway.
      </P>
      <P>
        Selectivity = (distinct values) / (total rows). Higher is better. Some rules of thumb:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-emerald-400">Highly selective</strong> (user_id, email, order_id) — great index candidates</li>
        <li><strong className="text-amber-400">Moderately selective</strong> (city, status with many values) — useful for composite indexes, weak alone</li>
        <li><strong className="text-rose-400">Low selectivity</strong> (gender, is_deleted boolean) — usually NOT worth indexing on their own</li>
      </ul>
      <P>
        The exception: low-selectivity columns can be the LEADING column of a composite index if
        they partition the data usefully. <Kbd>(is_deleted, user_id)</Kbd> is a useful index for
        queries like "active orders for user X" because the <Kbd>is_deleted = false</Kbd> filter
        narrows down to the active rows before the user_id selection.
      </P>

      <H2 num="◇ 06">Covering indexes — when the index alone answers the query</H2>
      <P>
        A covering index includes every column the query needs — both the WHERE filter columns
        AND the SELECT output columns. The database can answer the query from the index alone,
        skipping the table fetch entirely. This is sometimes 10x faster than a regular indexed
        query, because the table fetch (called a "heap lookup" in Postgres terms) is itself a
        random disk read per matched row.
      </P>
      <Code id="covering-index" lang="sql">{`-- Original query — needs an index AND a heap fetch for the amount
SELECT amount FROM orders WHERE customer_id = 4242 AND status = 'pending';

-- Normal index — finds matching rows, then fetches them from the table
CREATE INDEX idx_orders_c_s ON orders (customer_id, status);
-- Cost: index descent + N heap fetches for the amount column

-- Covering index — INCLUDE additional columns so the index itself has them
CREATE INDEX idx_orders_c_s_amount
  ON orders (customer_id, status)
  INCLUDE (amount);
-- Cost: index descent only. No heap fetch. PostgreSQL reports this as
-- "Index Only Scan" in EXPLAIN.`}</Code>
      <Callout kind="tip" title="WHEN COVERING INDEXES SHINE">
        Covering indexes are the difference between "fast" and "absurdly fast" for read-heavy
        queries that always select the same columns. The cost is storage (the index gets bigger)
        and write overhead (the index has to be updated on every column included). Use covering
        indexes for the queries that run thousands of times per second, not for every endpoint.
      </Callout>

      <H2 num="◇ 07">The cost of every index</H2>
      <P>
        Indexes are not free. Each one you add slows down writes and consumes storage:
      </P>
      <Code id="index-cost" lang="text">{`OPERATION         WITHOUT INDEX   WITH 1 INDEX   WITH 5 INDEXES
─────────         ─────────────   ────────────   ───────────────
SELECT by key     ~~~~ slow ~~~~  fast            fast (best matching index used)
INSERT row        fast            +1 index write  +5 index writes
UPDATE col        fast            +1 if indexed   +1 per affected index
DELETE row        fast            +1              +5
Storage           1×              1.2×            ~2×

EVERY index gets updated on every write. Adding indexes "just in case" is a
deferred performance bug — your reads might be fine, but your writes will
slow down as the table grows.`}</Code>

      <H2 num="◇ 08">When NOT to add an index</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-rose-400">Tables with very high write rates and infrequent reads.</strong> Event logs, audit trails. The write tax of maintaining indexes can outweigh the rare-query benefit. Sometimes the right answer is a separate read-replica with extra indexes specifically for reporting.</li>
        <li><strong className="text-rose-400">Columns where every value is unique AND rarely queried.</strong> A free-text comment column that nobody filters by gains nothing from an index.</li>
        <li><strong className="text-rose-400">Low-selectivity columns alone.</strong> See section 05.</li>
        <li><strong className="text-rose-400">Tables small enough to fit in a seq scan in milliseconds.</strong> Under 10K rows, indexes barely beat scans — and the planner knows it.</li>
        <li><strong className="text-rose-400">Columns subject to high churn but rarely filtered.</strong> Indexed updated columns rewrite the index on every change. <Kbd>last_seen_at</Kbd> updated every request, queried weekly? Skip the index; pay the scan cost at query time.</li>
      </ul>

      <H2 num="◇ 09">Hardening checklist for indexes</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Every foreign key has an index (otherwise the parent-row delete checks scan the child table)</li>
        <li>✓ Every commonly-filtered column with high selectivity is indexed</li>
        <li>✓ Composite indexes ordered by selectivity descending where it matches your query patterns</li>
        <li>✓ Covering indexes added for the highest-frequency read queries</li>
        <li>✓ Unused indexes identified (<Kbd>pg_stat_user_indexes</Kbd>) and removed on a schedule</li>
        <li>✓ Index creation done <Kbd>CONCURRENTLY</Kbd> in production to avoid blocking writes</li>
        <li>✓ EXPLAIN ANALYZE checked on every new query to confirm the planner uses the intended index</li>
        <li>✓ Index bloat monitored — periodic <Kbd>REINDEX CONCURRENTLY</Kbd> as tables age</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Indexes are the data structure. Section 02 covers how the database actually USES them —
        the query planner, EXPLAIN ANALYZE, join algorithms, and why your perfectly-good index
        sometimes goes unused.
      </Callout>
    </>
  );
}
