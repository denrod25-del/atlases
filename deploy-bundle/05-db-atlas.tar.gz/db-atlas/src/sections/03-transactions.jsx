/* Section 03 — Transactions and Isolation.
 *
 * Prose + Isolation Level Simulator.
 *
 * The simulator: two concurrent transactions running in parallel, each
 * with a fixed sequence of SQL statements. The student picks an isolation
 * level; the simulator fills in the isolation-dependent step results and
 * shows whether an anomaly occurred.
 *
 * Three scenarios cover the canonical anomalies:
 *   1. Dirty Read    — READ UNCOMMITTED allows; READ COMMITTED+ prevents
 *   2. Non-Repeatable Read — READ COMMITTED allows; REPEATABLE READ+ prevents
 *   3. Write Skew    — even REPEATABLE READ allows; only SERIALIZABLE prevents
 *
 * Postgres semantics throughout. Postgres's REPEATABLE READ uses snapshot
 * isolation, which already prevents phantom reads — so we use write skew
 * as the scenario that requires SERIALIZABLE (more practically interesting
 * than chasing phantoms).
 *
 * All prose strings use backticks (template literals) to avoid the
 * apostrophe-in-single-quote parse traps from Atlas 18 section 03.
 */

import { useState } from 'react';
import { Sparkles, AlertTriangle, ShieldCheck, RotateCcw } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Isolation Level Simulator
// ───────────────────────────────────────────────────────────────────────

const LEVELS = ['READ UNCOMMITTED', 'READ COMMITTED', 'REPEATABLE READ', 'SERIALIZABLE'];

const SCENARIOS = [
  {
    id: 'dirty-read',
    label: 'Dirty Read',
    description: `Transaction B updates a row but has not yet committed. Transaction A reads that row. Does A see B's uncommitted change?`,
    invariant: `accounts table — user_id=42 starts with balance=100`,
    steps: [
      { t: 1, A: { sql: `BEGIN`, result: 'OK' } },
      { t: 2, B: { sql: `BEGIN`, result: 'OK' } },
      { t: 3, B: { sql: `UPDATE accounts SET balance = 50 WHERE user_id = 42`, result: '1 row updated (NOT YET COMMITTED)' } },
      { t: 4, A: { sql: `SELECT balance FROM accounts WHERE user_id = 42`, isolationDependent: true } },
      { t: 5, B: { sql: `COMMIT`, result: 'OK' } },
      { t: 6, A: { sql: `COMMIT`, result: 'OK' } },
    ],
    outcomes: {
      'READ UNCOMMITTED': {
        stepResults: { 4: `50  ←  sees B's uncommitted value` },
        anomaly: 'DIRTY READ',
        bad: true,
        explanation: `A read a value that B had not committed yet. If B had rolled back instead of committing, A would have made decisions based on data that never existed. This is the dirty read anomaly — and the reason almost nobody uses READ UNCOMMITTED in practice. (Postgres does not even implement it; asking for READ UNCOMMITTED gives you READ COMMITTED.)`,
      },
      'READ COMMITTED': {
        stepResults: { 4: `100  ←  B's uncommitted change is invisible` },
        anomaly: null,
        bad: false,
        explanation: `A sees only committed data. B's uncommitted UPDATE is invisible. After B commits at step 5, A's subsequent reads would see the new value — but the value during step 4 was the still-committed 100. This is the Postgres default.`,
      },
      'REPEATABLE READ': {
        stepResults: { 4: `100  ←  same as READ COMMITTED here` },
        anomaly: null,
        bad: false,
        explanation: `Same outcome as READ COMMITTED for this scenario. Dirty reads are prevented at every level above READ UNCOMMITTED.`,
      },
      'SERIALIZABLE': {
        stepResults: { 4: `100  ←  same as READ COMMITTED here` },
        anomaly: null,
        bad: false,
        explanation: `Same outcome as READ COMMITTED for this scenario. Dirty reads are prevented at every level above READ UNCOMMITTED.`,
      },
    },
  },
  {
    id: 'non-rep-read',
    label: 'Non-Repeatable Read',
    description: `Transaction A reads the same row twice. Between A's two reads, Transaction B updates and commits the row. Does A see the same value on its second read?`,
    invariant: `accounts table — user_id=42 starts with balance=100`,
    steps: [
      { t: 1, A: { sql: `BEGIN`, result: 'OK' } },
      { t: 2, A: { sql: `SELECT balance FROM accounts WHERE user_id = 42`, result: '100' } },
      { t: 3, B: { sql: `BEGIN`, result: 'OK' } },
      { t: 4, B: { sql: `UPDATE accounts SET balance = 50 WHERE user_id = 42`, result: '1 row updated' } },
      { t: 5, B: { sql: `COMMIT`, result: 'OK' } },
      { t: 6, A: { sql: `SELECT balance FROM accounts WHERE user_id = 42`, isolationDependent: true } },
      { t: 7, A: { sql: `COMMIT`, result: 'OK' } },
    ],
    outcomes: {
      'READ UNCOMMITTED': {
        stepResults: { 6: `50  ←  sees B's committed change` },
        anomaly: 'NON-REPEATABLE READ',
        bad: true,
        explanation: `Two reads of the same row inside ONE transaction returned different values. A is making decisions based on inconsistent data. Classic bug: A checks balance >= 100, takes some action, then checks again to log "before/after" and gets 50.`,
      },
      'READ COMMITTED': {
        stepResults: { 6: `50  ←  B's commit became visible mid-transaction` },
        anomaly: 'NON-REPEATABLE READ',
        bad: true,
        explanation: `Postgres default. Each statement reads from the current committed state. B committed between A's two SELECTs, so A's second read sees the new value. Acceptable in most cases — but if you need stable reads across a transaction, you need REPEATABLE READ.`,
      },
      'REPEATABLE READ': {
        stepResults: { 6: `100  ←  A's snapshot is frozen at BEGIN` },
        anomaly: null,
        bad: false,
        explanation: `A's view of the database is frozen at the moment of BEGIN. B's commit happened, but A's transaction does not see it. Postgres implements this with MVCC snapshots — every read in A's transaction returns data as of its snapshot, regardless of what committed in between.`,
      },
      'SERIALIZABLE': {
        stepResults: { 6: `100  ←  same as REPEATABLE READ here` },
        anomaly: null,
        bad: false,
        explanation: `Same outcome as REPEATABLE READ for this scenario. Both use snapshot isolation; non-repeatable reads are prevented at both levels.`,
      },
    },
  },
  {
    id: 'write-skew',
    label: 'Write Skew',
    description: `The doctor-on-call problem. Both transactions read consistent data, both decide independently that it is safe to act, both commit — and together violate an invariant.`,
    invariant: `Hospital rule: at least 1 doctor must have on_call=true at all times. Currently 2 doctors are on call (Alice, Bob).`,
    steps: [
      { t: 1, A: { sql: `BEGIN`, result: 'OK' } },
      { t: 2, B: { sql: `BEGIN`, result: 'OK' } },
      { t: 3, A: { sql: `SELECT COUNT(*) FROM doctors WHERE on_call = true`, result: '2' } },
      { t: 4, B: { sql: `SELECT COUNT(*) FROM doctors WHERE on_call = true`, result: '2' } },
      { t: 5, A: { sql: `-- "2 are on call, safe to clock out" --\nUPDATE doctors SET on_call = false WHERE name = 'Alice'`, result: '1 row updated' } },
      { t: 6, B: { sql: `-- "2 are on call, safe to clock out" --\nUPDATE doctors SET on_call = false WHERE name = 'Bob'`, result: '1 row updated' } },
      { t: 7, A: { sql: `COMMIT`, isolationDependent: true } },
      { t: 8, B: { sql: `COMMIT`, isolationDependent: true } },
    ],
    outcomes: {
      'READ UNCOMMITTED': {
        stepResults: { 7: 'OK', 8: `OK  ←  invariant now violated (0 doctors on call)` },
        anomaly: 'WRITE SKEW',
        bad: true,
        explanation: `Both transactions saw 2 doctors on call, both decided it was safe to clock one out, both committed. Final state: 0 doctors on call. The invariant is broken — and no one noticed because each transaction in isolation looks fine.`,
      },
      'READ COMMITTED': {
        stepResults: { 7: 'OK', 8: `OK  ←  invariant now violated (0 doctors on call)` },
        anomaly: 'WRITE SKEW',
        bad: true,
        explanation: `Postgres default. Each statement sees committed data. Neither transaction saw the other's uncommitted UPDATE because they ran in parallel. Both committed cleanly. Invariant broken.`,
      },
      'REPEATABLE READ': {
        stepResults: { 7: 'OK', 8: `OK  ←  invariant now violated (0 doctors on call)` },
        anomaly: 'WRITE SKEW',
        bad: true,
        explanation: `Snapshot isolation does NOT save you here. Both transactions had consistent snapshots showing 2 doctors on call. Their reads were stable. But their WRITES affected different rows in a correlated way — and snapshot isolation does not track that. This is the famous gap in REPEATABLE READ.`,
      },
      'SERIALIZABLE': {
        stepResults: { 7: 'OK', 8: `ERROR: could not serialize access due to read/write dependencies among transactions (SQLSTATE 40001)` },
        anomaly: 'PREVENTED',
        bad: false,
        explanation: `Postgres uses SSI (Serializable Snapshot Isolation). At commit time, it detects that A and B have a read-write dependency cycle (each read what the other wrote) and aborts the second committer. B's transaction must retry. When B retries, it sees only 1 doctor on call (Alice clocked out), and the application logic correctly refuses to clock Bob out. Invariant preserved.`,
      },
    },
  },
];

function IsolationSimulator() {
  const [scenarioIdx, setScenarioIdx] = useState(0);
  const [level, setLevel] = useState(null);
  const scenario = SCENARIOS[scenarioIdx];
  const outcome = level ? scenario.outcomes[level] : null;

  const setScenario = (i) => {
    setScenarioIdx(i);
    setLevel(null);  // reset level when switching scenarios
  };

  return (
    <div className="my-6 border border-indigo-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-indigo-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-indigo-300" />
          <span className="text-indigo-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · isolation level simulator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => setScenario(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === scenarioIdx
                  ? 'border-indigo-300 bg-indigo-300/15 text-indigo-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-indigo-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {i + 1}. {s.label}
            </button>
          ))}
        </div>

        {/* Scenario description + invariant */}
        <div className="mb-3 p-3 border border-zinc-800 bg-zinc-900/40">
          <div className="text-zinc-300 text-[13.5px] leading-relaxed italic mb-2">
            {scenario.description}
          </div>
          <div className="text-zinc-500 text-[11.5px] tracking-wide pt-2 border-t border-zinc-800"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <span className="text-indigo-300 mr-2">setup:</span>{scenario.invariant}
          </div>
        </div>

        {/* Isolation level picker */}
        <div className="mb-4">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            pick an isolation level
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-1.5">
            {LEVELS.map(l => (
              <button key={l} onClick={() => setLevel(l)}
                className={`px-2 py-2 border text-[10.5px] text-center transition-colors ${
                  level === l
                    ? 'border-indigo-300 bg-indigo-300/15 text-indigo-200 font-semibold'
                    : 'border-zinc-700 text-zinc-400 hover:border-indigo-300/50 hover:text-zinc-200'
                }`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Timeline — two-column view of both transactions */}
        <div className="mb-4 border border-zinc-800 bg-zinc-950/60 overflow-hidden">
          {/* Header row */}
          <div className="grid grid-cols-[40px_1fr_1fr] gap-0 bg-zinc-900 text-[10px] tracking-[0.2em] uppercase text-zinc-500"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <div className="p-2 text-center border-r border-zinc-800">t</div>
            <div className="p-2 border-r border-zinc-800 text-indigo-300">Transaction A</div>
            <div className="p-2 text-amber-300">Transaction B</div>
          </div>
          {/* Steps */}
          {scenario.steps.map(step => {
            const isA = !!step.A;
            const action = isA ? step.A : step.B;
            const isolDep = action.isolationDependent;
            const resolvedResult = isolDep && outcome
              ? outcome.stepResults[step.t]
              : action.result;
            const stepBg = isolDep
              ? (outcome
                  ? (outcome.bad ? 'bg-rose-400/10' : 'bg-indigo-300/10')
                  : 'bg-amber-400/5')
              : '';
            return (
              <div key={step.t}
                className={`grid grid-cols-[40px_1fr_1fr] gap-0 border-t border-zinc-800/60 ${stepBg}`}>
                <div className="p-2 text-center text-zinc-600 text-[10px] border-r border-zinc-800/60"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {step.t}
                </div>
                {/* Column A */}
                <div className={`p-2 border-r border-zinc-800/60 ${!isA && 'bg-zinc-950/40'}`}>
                  {isA && (
                    <div>
                      <pre className="text-[11px] text-zinc-200 whitespace-pre-wrap leading-snug"
                        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                        {action.sql}
                      </pre>
                      {resolvedResult && (
                        <div className={`text-[10.5px] mt-1 ${
                          isolDep
                            ? (outcome
                                ? (outcome.bad ? 'text-rose-300' : 'text-indigo-200')
                                : 'text-amber-300')
                            : 'text-zinc-500'
                        }`}
                          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                          → {resolvedResult}
                        </div>
                      )}
                      {isolDep && !outcome && (
                        <div className="text-[10px] text-amber-300/70 italic mt-1">
                          ↳ pick a level to see the result
                        </div>
                      )}
                    </div>
                  )}
                </div>
                {/* Column B */}
                <div className={`p-2 ${isA && 'bg-zinc-950/40'}`}>
                  {!isA && (
                    <div>
                      <pre className="text-[11px] text-zinc-200 whitespace-pre-wrap leading-snug"
                        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                        {action.sql}
                      </pre>
                      {resolvedResult && (
                        <div className={`text-[10.5px] mt-1 ${
                          isolDep
                            ? (outcome
                                ? (outcome.bad ? 'text-rose-300' : 'text-indigo-200')
                                : 'text-amber-300')
                            : 'text-zinc-500'
                        }`}
                          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                          → {resolvedResult}
                        </div>
                      )}
                      {isolDep && !outcome && (
                        <div className="text-[10px] text-amber-300/70 italic mt-1">
                          ↳ pick a level to see the result
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Verdict */}
        {outcome && (
          <div className={`border p-4 ${
            outcome.bad
              ? 'border-rose-400/60 bg-rose-400/10'
              : 'border-indigo-300/60 bg-indigo-300/10'
          }`}>
            <div className={`text-[11px] tracking-[0.25em] uppercase font-semibold mb-2 flex items-center gap-2 ${
              outcome.bad ? 'text-rose-300' : 'text-indigo-300'
            }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {outcome.bad ? <AlertTriangle size={13} /> : <ShieldCheck size={13} />}
              {outcome.anomaly
                ? (outcome.bad ? `anomaly · ${outcome.anomaly}` : `anomaly prevented`)
                : 'no anomaly'}
            </div>
            <div className="text-zinc-200 text-[13.5px] leading-relaxed">
              {outcome.explanation}
            </div>
          </div>
        )}

        {/* Reset hint */}
        {outcome && (
          <button onClick={() => setLevel(null)}
            className="mt-3 px-3 py-1.5 border border-zinc-700 text-zinc-500 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[11px] flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <RotateCcw size={10} /> try another level
          </button>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section03_Transactions() {
  return (
    <>
      <SectionLabel>section 03</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Transactions and isolation — surviving concurrency
      </h2>
      <P>
        Indexes and query plans are about ONE query running. Production databases are running
        thousands of queries simultaneously, often against the same rows. The rules that govern
        how those concurrent queries interact — what one transaction can see of another&apos;s
        work, when writes block each other, when commits get rejected — are the most subtle
        part of databases and the source of bugs that are nearly impossible to debug after the
        fact. This section makes those rules visible.
      </P>

      <H2 num="◇ 01">ACID — what each letter actually promises</H2>
      <Code id="acid-overview" lang="text">{`A · ATOMICITY     All-or-nothing. A transaction either fully completes or fully
                  doesn't — no partial state. If anything fails mid-transaction,
                  every change so far is rolled back.

C · CONSISTENCY   Every transaction takes the database from one valid state
                  to another. Constraints, foreign keys, triggers — none of
                  them ever observe an invalid intermediate state.

I · ISOLATION     Concurrent transactions cannot observe each other's
                  partial work. The degree of isolation is configurable —
                  that is the rest of this section.

D · DURABILITY    Once a transaction commits, it survives crashes. The
                  database has either written it to disk or replicated
                  it to another node before reporting success.`}</Code>
      <P>
        ACID is the SQL-database promise. NoSQL databases vary — some are ACID (newer ones
        increasingly are); many trade some letter for performance. Knowing which letter your
        database guarantees and which it does not is foundational. For Postgres / MySQL /
        SQLite, all four hold under default settings.
      </P>

      <H2 num="◇ 02">Why isolation is hard</H2>
      <P>
        Imagine two transactions running in parallel. Transaction A reads a row. Transaction B
        updates that row. What should A see? Options:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-rose-400">A sees B&apos;s change immediately</strong> — even before B commits. (DIRTY READ — A might see data that gets rolled back.)</li>
        <li><strong className="text-amber-400">A sees B&apos;s change only after B commits</strong> — but possibly mid-transaction. (NON-REPEATABLE READ — A&apos;s view of the database changes underneath it.)</li>
        <li><strong className="text-indigo-300">A sees a consistent snapshot from when A started</strong> — B&apos;s commits are invisible to A. (Repeatable reads, snapshot isolation.)</li>
        <li><strong className="text-emerald-400">A and B behave as if one ran fully before the other</strong> — the strictest possible guarantee. (SERIALIZABLE — but expensive.)</li>
      </ul>
      <P>
        Each option trades correctness for performance. Stricter isolation means more locking, more
        conflict detection, more aborted transactions, slower throughput. The SQL standard codified
        four "isolation levels" so applications could pick where they want to be on the spectrum.
      </P>

      <H2 num="◇ 03">The four isolation levels — and the four anomalies</H2>
      <P>
        The SQL standard defines four levels, ranked by what anomalies they allow:
      </P>
      <Code id="isolation-matrix" lang="text">{`                          DIRTY READ     NON-REPEAT READ   PHANTOM READ   WRITE SKEW
                          ──────────     ───────────────   ────────────   ──────────
READ UNCOMMITTED          ✗ allowed      ✗ allowed         ✗ allowed      ✗ allowed
READ COMMITTED            ✓ prevented    ✗ allowed         ✗ allowed      ✗ allowed
REPEATABLE READ           ✓ prevented    ✓ prevented       ✗ allowed*     ✗ allowed
SERIALIZABLE              ✓ prevented    ✓ prevented       ✓ prevented    ✓ prevented

* Postgres's REPEATABLE READ actually prevents phantom reads too (it uses
  snapshot isolation, which is strictly stronger than SQL standard REPEATABLE
  READ). MySQL InnoDB's REPEATABLE READ also prevents phantoms via gap locks.
  In practice, the only anomaly REPEATABLE READ still allows is WRITE SKEW.`}</Code>
      <Callout kind="deep" title="THE FOUR ANOMALIES IN ONE SENTENCE EACH">
        <strong className="text-rose-400">Dirty Read:</strong> reading another transaction&apos;s uncommitted change. <br />
        <strong className="text-rose-400">Non-Repeatable Read:</strong> reading the same row twice and getting different values, because another transaction committed an update in between. <br />
        <strong className="text-rose-400">Phantom Read:</strong> running the same range query twice and getting different rows, because another transaction inserted a row that matches the filter. <br />
        <strong className="text-rose-400">Write Skew:</strong> two transactions read consistent data, then make uncoordinated writes that together violate an invariant — even though each transaction in isolation looks fine.
      </Callout>

      <H2 num="◇ 04">The real-world defaults</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-indigo-300">Postgres default: READ COMMITTED.</strong> Each statement reads from the current committed state. Mid-transaction the view can change. Most queries fit fine; transactions that need stable reads should explicitly request REPEATABLE READ.</li>
        <li><strong className="text-indigo-300">MySQL InnoDB default: REPEATABLE READ.</strong> Snapshot at transaction start; the view is stable across the transaction. More conservative default than Postgres; rarely causes problems but can hide write conflicts that READ COMMITTED would surface.</li>
        <li><strong className="text-indigo-300">SQLite default: SERIALIZABLE.</strong> Because SQLite runs one writer at a time, serializability is essentially free for it.</li>
        <li><strong className="text-indigo-300">Spanner: external serializability.</strong> Even stronger than SERIALIZABLE — transactions appear to run in real-time order across the entire distributed cluster.</li>
      </ul>
      <P>
        For most applications, the database default is the right choice. Bump up when you have a
        specific consistency requirement; do NOT make every transaction SERIALIZABLE "just in
        case" — you will lose throughput and gain serialization failures.
      </P>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 05">See each anomaly happen — and see it prevented</H2>
      <P>
        Three scenarios, four isolation levels each. Pick a scenario, then pick a level — watch
        the timeline play out under that level&apos;s rules. The first two scenarios show classic
        anomalies and the level that prevents each. The third — Write Skew — is the subtle one:
        snapshot isolation (the typical "REPEATABLE READ") does NOT prevent it, and you have to
        go all the way to SERIALIZABLE.
      </P>

      <IsolationSimulator />

      <H2 num="◇ 06">Pessimistic locking — SELECT FOR UPDATE</H2>
      <P>
        Sometimes you do not want to deal with anomalies after the fact — you want to make sure
        no concurrent transaction can interfere with the row you are about to update. The
        explicit answer is pessimistic locking: take an exclusive lock on the rows you intend
        to modify, and hold it until you commit.
      </P>
      <Code id="select-for-update" lang="sql">{`-- Pattern: lock the row, read it, decide based on the value, write
BEGIN;

SELECT balance FROM accounts
  WHERE user_id = 42
  FOR UPDATE;                       -- ← takes an exclusive row lock

-- Now no other transaction can SELECT FOR UPDATE this row, nor UPDATE it.
-- They block until we COMMIT or ROLLBACK.

-- (application checks balance, decides to charge)

UPDATE accounts SET balance = balance - 50 WHERE user_id = 42;

COMMIT;                              -- ← lock released here`}</Code>
      <P>
        Used when the decision logic lives in the application, not in SQL. Useful for:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>Account balance changes that depend on the current balance</li>
        <li>Inventory decrements where you must NOT go below zero</li>
        <li>"Take the next item from this queue" workflows</li>
        <li>Anywhere a stale read could cause a real-world inconsistency</li>
      </ul>
      <Callout kind="warn" title="LOCK ORDER MATTERS — DEADLOCKS WAIT BELOW">
        Two transactions that try to lock the same set of rows in different orders will deadlock.
        T1 locks row 1 then tries to lock row 2; meanwhile T2 has locked row 2 and is trying to
        lock row 1. Both wait forever. Databases detect this and abort one — but you still get
        a serialization failure your code must handle. The defense: always acquire locks in a
        consistent order (e.g., by primary key ascending). Documented; enforced in shared
        helpers; reviewed.
      </Callout>

      <H2 num="◇ 07">Optimistic locking — version columns</H2>
      <P>
        Pessimistic locking is correct but expensive (locks held; concurrency reduced). Optimistic
        locking takes the opposite approach: assume conflicts are rare, allow concurrent reads,
        and detect conflicts at write time.
      </P>
      <Code id="optimistic-lock" lang="sql">{`-- Add a version column to the table
ALTER TABLE accounts ADD COLUMN version INTEGER NOT NULL DEFAULT 0;

-- Read with version
SELECT balance, version FROM accounts WHERE user_id = 42;
-- → balance=100, version=7

-- (application computes new balance = 50)

-- Write conditional on version
UPDATE accounts
  SET balance = 50, version = version + 1
  WHERE user_id = 42 AND version = 7;
-- → 1 row updated  → success
-- → 0 rows updated → someone else got there first; reload and retry`}</Code>
      <P>
        The trick: the WHERE clause includes the version that was current when we read.
        If anyone else updated the row in between, the version is now 8, our UPDATE finds
        no matching row, and we retry. No locks held during application logic; concurrency
        preserved. The downside: every write must be coded as a check-then-retry.
      </P>

      <H2 num="◇ 08">Deadlocks — what they are, what to do</H2>
      <P>
        A deadlock is a cycle of transactions each waiting for a lock held by another. The
        database detects the cycle (Postgres runs a periodic deadlock check; the algorithm is
        a graph traversal looking for cycles) and aborts one of the transactions with a
        deadlock error.
      </P>
      <Code id="deadlock-example" lang="text">{`TIME   T1                                  T2
─────  ───────────────────────────────     ────────────────────────────────
1      UPDATE rows SET ... WHERE id = 1    UPDATE rows SET ... WHERE id = 2
       (T1 holds lock on row 1)            (T2 holds lock on row 2)

2      UPDATE rows SET ... WHERE id = 2    UPDATE rows SET ... WHERE id = 1
       (T1 waits — T2 holds lock)          (T2 waits — T1 holds lock)

       Both transactions wait forever — until Postgres detects the cycle:

3      ERROR: deadlock detected            (proceeds normally)
       SQLSTATE 40P01
       (T1 is aborted; T2 keeps its locks)`}</Code>
      <P>
        Postgres always aborts ONE side; the other completes. Your application must handle the
        deadlock error by retrying. The mitigations:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-indigo-300">Consistent lock order.</strong> Always lock rows in primary-key ascending order. If every transaction follows this rule, deadlocks become impossible.</li>
        <li><strong className="text-indigo-300">Shorter transactions.</strong> The longer a transaction holds locks, the wider the window for another transaction to deadlock with it.</li>
        <li><strong className="text-indigo-300">Retry with backoff.</strong> Treat deadlocks as transient. Retry the whole transaction; usually the retry succeeds because the other party has finished.</li>
        <li><strong className="text-indigo-300">SELECT FOR UPDATE SKIP LOCKED.</strong> For queue-like workloads. If another transaction holds the row, skip it; pick the next available one. Removes a whole class of contention.</li>
      </ul>

      <H2 num="◇ 09">When to use which level</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-emerald-400">READ COMMITTED (Postgres default):</strong> 90% of transactions. Simple reads and writes, where each statement seeing the latest committed data is fine.</li>
        <li><strong className="text-emerald-400">REPEATABLE READ:</strong> When you need stable reads across a transaction — e.g., generating a report that touches many tables and expects a consistent snapshot. Also when you want to detect concurrent updates and the application is OK with retrying serialization failures.</li>
        <li><strong className="text-emerald-400">SERIALIZABLE:</strong> When write skew is a real concern (invariants over multiple rows, scheduling, inventory totals). Be ready to handle serialization failures (40001) by retrying the transaction.</li>
        <li><strong className="text-rose-400">READ UNCOMMITTED:</strong> Essentially never. Postgres does not even implement it (treats it as READ COMMITTED). MySQL allows it; almost no application benefits.</li>
      </ul>

      <H2 num="◇ 10">Hardening checklist for transactions</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Default isolation level documented per service (most teams have never thought about it)</li>
        <li>✓ Transactions kept short — application logic that does not need the DB lives outside BEGIN/COMMIT</li>
        <li>✓ <Kbd>SELECT FOR UPDATE</Kbd> used for read-modify-write patterns on contended rows</li>
        <li>✓ Locks acquired in consistent order (e.g., by primary key ascending) to prevent deadlocks</li>
        <li>✓ Serialization failures (SQLSTATE 40001) and deadlock errors (40P01) caught and retried with backoff</li>
        <li>✓ Invariants requiring multi-row consistency use SERIALIZABLE, not "we hope concurrent writes do not happen"</li>
        <li>✓ Optimistic locking (version columns) used where the conflict rate is low and lock contention would hurt</li>
        <li>✓ Long-running transactions monitored — they hold locks and block VACUUM in Postgres</li>
        <li>✓ <Kbd>idle_in_transaction_session_timeout</Kbd> set in Postgres to kill connections that left transactions open</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Transactions handle concurrency on one database. Section 04 — the closer — covers what
        happens when one database is not enough: replication for read scaling, replication lag
        and its consequences, sharding to scale writes, and how all of this complicates the
        consistency guarantees you just learned to think about.
      </Callout>
    </>
  );
}
