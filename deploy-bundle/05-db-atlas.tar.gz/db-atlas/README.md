# Databases at Scale — Atlas #20 (B. Symbolic)

Indexes · Query Optimization · Transactions · Replication

Standalone Vite + React + Tailwind project. Opens the data-systems arc of
the atlas series. Same atlas-twenty trilogy framing: this atlas + Atlas 21
(Distributed Systems, planned) + Atlas 22 (Event-Driven Architecture, planned).

Build script uses `node ./node_modules/vite/bin/vite.js build` (Vercel-fix
baked in). `.gitignore` baked in from the first commit. Pre-flight scan for
GitHub Push Protection patterns clean (zero `sk_live_`, `sk_test_`, `AKIA*`,
`ghp_`, `ghs_` matches in source).

## New in this atlas
- **Section tabs in the sticky header** — always visible while scrolling
- **IntersectionObserver scrollspy** — active tab auto-highlights as you scroll

## Run locally
```
npm install
npm run dev          # http://localhost:5173
```

## Deploy
Push to GitHub. Connect at vercel.com/new. Auto-detects Vite. ~60s to live URL.

## Sections (all complete)

### 01 Indexes (504 lines)
Mental model, B-trees, composite indexes, selectivity, covering indexes, costs.
**Interactive:** B-Tree Index Visualizer — depth-3 tree with 27 keys, pick a value
and watch animated descent (3 hops) vs sequential scan (up to 11 hops).

### 02 Query Optimization (523 lines)
Planner mechanics, EXPLAIN ANALYZE, scan types, join algorithms, statistics.
**Interactive:** Query Plan Comparator — three scenarios with side-by-side
EXPLAIN outputs: with/without index (6700× speedup), small-vs-large data shapes
(Nested Loop vs Hash Join), fresh-vs-stale stats (92× slowdown).

### 03 Transactions (590 lines)
ACID, four isolation levels, four anomalies, pessimistic + optimistic locking,
deadlocks. **Interactive:** Isolation Level Simulator — three scenarios mapped
to three classic anomalies (dirty read, non-repeatable read, write skew),
two-column timeline of concurrent transactions, results fill in based on chosen
isolation level. Doctor-on-call write skew scenario shows the SERIALIZABLE-only
prevention via SSI (SQLSTATE 40001).

### 04 Replication (614 lines)
Primary/replicas, sync vs async, replication lag, read-after-write, sharding,
CAP/PACELC, eventual consistency. **Interactive:** Replication Lag Simulator —
primary + 3 replicas (250ms / 700ms / 1500ms lag), three modes (async-default
with random replica reads, read-your-writes routing to primary, synchronous
with bounded write latency), event log, stale-read detection.

## Conventions
- Palette: indigo-300 primary, emerald-400 accent
- Glyph: ▤
- Type: Bricolage Grotesque · JetBrains Mono · Manrope
- Background: zinc-950

## Series
- Atlas 17-19 — API series (Foundations · Security · Production)
- **Atlas 20 — Databases at Scale (this one) — opens data-systems arc**
- Atlas 21 — Distributed Systems (planned)
- Atlas 22 — Event-Driven Architecture (planned)

## Push checklist
1. `git init && git add . && git commit -m "Atlas 20 — Databases at Scale"`
2. Create repo on github.com (suggested: `db-atlas` under `denrod25-del`)
3. `git remote add origin git@github.com:denrod25-del/db-atlas.git`
4. `git push -u origin main`
5. Connect at vercel.com/new → import the repo → deploy
