/* Distributed Systems Atlas — shell with section tabs in the sticky header.
 *
 * Pattern carried over from Atlas 20: two-row sticky header, scroll-mt-28
 * on each section anchor, IntersectionObserver scrollspy biases the active
 * tab to the upper third of the viewport.
 */

import { useEffect, useState } from 'react';
import Section01_WhyHard      from './sections/01-why-hard.jsx';
import Section02_Consensus    from './sections/02-consensus.jsx';
import Section03_VectorClocks from './sections/03-vector-clocks.jsx';
import Section04_Quorum       from './sections/04-quorum.jsx';

const SECTIONS = [
  { id: 'why-hard',      label: '01 · Why distributed is hard', comp: Section01_WhyHard },
  { id: 'consensus',     label: '02 · Consensus',                comp: Section02_Consensus },
  { id: 'vector-clocks', label: '03 · Vector Clocks',            comp: Section03_VectorClocks },
  { id: 'quorum',        label: '04 · Quorum',                   comp: Section04_Quorum },
];

function StickyHeader({ activeId }) {
  return (
    <div className="border-b border-zinc-800 bg-zinc-950/95 sticky top-0 z-50 backdrop-blur">
      <div className="max-w-5xl mx-auto px-6 py-3 flex items-baseline gap-4">
        <a href="#top" className="text-violet-300 text-[22px] leading-none"
          style={{ fontFamily: 'serif' }}>⬢</a>
        <div className="flex-1">
          <div className="text-zinc-100 text-[14px] font-semibold leading-tight"
            style={{ fontFamily: 'Bricolage Grotesque, sans-serif' }}>
            Distributed Systems
          </div>
          <div className="text-zinc-500 text-[10.5px] tracking-[0.25em] uppercase"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            Atlas · B. Symbolic
          </div>
        </div>
        <a href="https://atlases.vercel.app"
          className="text-zinc-500 hover:text-violet-300 text-[11px] tracking-[0.2em] uppercase"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          ← all atlases
        </a>
      </div>

      <div className="border-t border-zinc-800/60 max-w-5xl mx-auto px-6 py-2">
        <div className="flex gap-1.5 overflow-x-auto scrollbar-thin">
          {SECTIONS.map(s => {
            const isActive = activeId === s.id;
            return (
              <a key={s.id} href={`#${s.id}`}
                className={`px-3 py-1.5 border text-[11.5px] whitespace-nowrap transition-colors shrink-0 ${
                  isActive
                    ? 'border-violet-300 bg-violet-300/15 text-violet-200'
                    : 'border-zinc-700/80 text-zinc-400 hover:border-violet-300/50 hover:text-zinc-200'
                }`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {s.label}
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <div id="top" className="border-b border-zinc-800 bg-gradient-to-b from-zinc-950 to-zinc-900">
      <div className="max-w-5xl mx-auto px-6 py-16">
        <div className="text-violet-300 text-[11px] tracking-[0.4em] uppercase mb-4"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          atlas twenty-one · ⬢
        </div>
        <h1 className="text-zinc-50 text-[42px] leading-[1.05] mb-4"
          style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 700 }}>
          Distributed Systems
        </h1>
        <p className="text-zinc-400 text-[16px] max-w-2xl leading-relaxed"
          style={{ fontFamily: 'Manrope, sans-serif' }}>
          What happens when one machine is not enough. Why coordination across machines is
          fundamentally hard, not just slow. Consensus protocols that let a cluster agree on
          a single truth. Logical clocks that make sense of disorder. Quorum-based reads and
          writes that let you tune the consistency-availability dial. Continues the data-systems
          arc.
        </p>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div className="border-t border-zinc-800 mt-20 py-10">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <div className="text-zinc-500 text-[11px] tracking-[0.3em] uppercase mb-2"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          end of atlas
        </div>
        <div className="text-zinc-600 text-[12px]">
          ⬢ · Distributed Systems · B. Symbolic ·{' '}
          <a href="https://atlases.vercel.app" className="hover:text-violet-300">atlases.vercel.app</a>
        </div>
      </div>
    </div>
  );
}

function useActiveSection() {
  const [activeId, setActiveId] = useState(SECTIONS[0].id);
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter(e => e.isIntersecting);
        if (visible.length > 0) {
          visible.sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
          setActiveId(visible[0].target.id);
        }
      },
      { rootMargin: '-30% 0px -55% 0px', threshold: 0 }
    );
    SECTIONS.forEach(s => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);
  return activeId;
}

export default function App() {
  const activeId = useActiveSection();
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <StickyHeader activeId={activeId} />
      <Hero />
      <div className="max-w-5xl mx-auto px-6">
        {SECTIONS.map(s => {
          const Comp = s.comp;
          return (
            <div key={s.id} id={s.id} className="scroll-mt-28">
              <Comp />
            </div>
          );
        })}
      </div>
      <Footer />
    </div>
  );
}
