/* Section 04 — Quorum and Tunable Consistency. Closing section of Atlas 21.
 *
 * Prose + Quorum Configuration Explorer + atlas-closing + arc-middle wraps.
 *
 * The simulator: user picks N (cluster size: 3/5/7), W (write quorum),
 * and R (read quorum). The simulator shows:
 *   - Whether (N, W, R) gives strong or eventual consistency (R+W > N)
 *   - Minimum guaranteed overlap (max(0, R+W-N))
 *   - Fault tolerance (N - max(W, R) — the number of node failures the
 *     cluster can tolerate while still serving reads AND writes)
 *   - Use-case label that matches well-known configurations
 *
 * The "Sample" button picks a random W nodes (violet) and a random R nodes
 * (cyan) and visualizes the overlap. When R+W > N, the overlap is always
 * ≥ 1 — that overlap is THE node guaranteed to have the latest write.
 *
 * All prose strings use backticks (template literals).
 */

import { useState, useMemo } from 'react';
import { Sparkles, Edit, Eye, RotateCcw, Plus, Minus, ShieldCheck, AlertTriangle, Zap } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Quorum Configuration Explorer
// ───────────────────────────────────────────────────────────────────────

const N_OPTIONS = [3, 5, 7];

const PRESETS = [
  { label: 'Balanced quorum',  fn: (n) => ({ w: Math.floor(n / 2) + 1, r: Math.floor(n / 2) + 1 }) },
  { label: 'Read-optimized',   fn: (n) => ({ w: n, r: 1 }) },
  { label: 'Write-optimized',  fn: (n) => ({ w: 1, r: n }) },
  { label: 'Max availability', fn: ()  => ({ w: 1, r: 1 }) },
];

// Pick K random indices from 0..N-1
function pickRandom(N, K) {
  const pool = Array.from({ length: N }, (_, i) => i);
  const out = [];
  for (let i = 0; i < K; i++) {
    const j = Math.floor(Math.random() * pool.length);
    out.push(pool.splice(j, 1)[0]);
  }
  return out;
}

function describeConfig(N, W, R) {
  const strong = (R + W) > N;
  const minOverlap = Math.max(0, R + W - N);
  const writeFaultTolerance = N - W;     // can lose this many and still write
  const readFaultTolerance  = N - R;     // can lose this many and still read
  const overallFaultTolerance = Math.min(writeFaultTolerance, readFaultTolerance);

  // Use-case label
  let label = 'Custom';
  if (W === N && R === 1)             label = 'Read-optimized (strong)';
  else if (W === 1 && R === N)        label = 'Write-optimized (strong)';
  else if (W === 1 && R === 1)        label = 'Maximum availability';
  else if (strong && W === R)         label = 'Balanced quorum (strong)';
  else if (strong)                    label = 'Strong consistency';
  else                                label = 'Eventual consistency';

  return { strong, minOverlap, writeFaultTolerance, readFaultTolerance, overallFaultTolerance, label };
}

function QuorumExplorer() {
  const [N, setN] = useState(5);
  const [W, setW] = useState(3);
  const [R, setR] = useState(3);
  const [sample, setSample] = useState(null);   // { writeNodes, readNodes }

  const cfg = useMemo(() => describeConfig(N, W, R), [N, W, R]);

  const switchN = (newN) => {
    setN(newN);
    // Clamp W and R into [1, newN]; default to majority
    setW(Math.min(W, newN) || Math.floor(newN / 2) + 1);
    setR(Math.min(R, newN) || Math.floor(newN / 2) + 1);
    setSample(null);
  };

  const incW = () => setW(v => Math.min(N, v + 1));
  const decW = () => setW(v => Math.max(1, v - 1));
  const incR = () => setR(v => Math.min(N, v + 1));
  const decR = () => setR(v => Math.max(1, v - 1));

  const applyPreset = (preset) => {
    const { w, r } = preset.fn(N);
    setW(w); setR(r); setSample(null);
  };

  const runSample = () => {
    const writeNodes = new Set(pickRandom(N, W));
    const readNodes  = new Set(pickRandom(N, R));
    setSample({ writeNodes, readNodes });
  };

  const overlap = sample
    ? [...sample.writeNodes].filter(i => sample.readNodes.has(i))
    : [];

  return (
    <div className="my-6 border border-violet-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-violet-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-violet-300" />
          <span className="text-violet-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · quorum configuration explorer
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Cluster size selector */}
        <div className="mb-3">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            cluster size (n)
          </div>
          <div className="flex gap-1.5">
            {N_OPTIONS.map(opt => (
              <button key={opt} onClick={() => switchN(opt)}
                className={`px-3 py-1.5 border text-[12px] font-semibold transition-colors ${
                  N === opt
                    ? 'border-violet-300 bg-violet-300/15 text-violet-200'
                    : 'border-zinc-700 text-zinc-400 hover:border-violet-300/50 hover:text-zinc-200'
                }`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                N = {opt}
              </button>
            ))}
          </div>
        </div>

        {/* W and R steppers */}
        <div className="grid grid-cols-2 gap-3 mb-3">
          {/* Write quorum */}
          <div className="border border-zinc-800 bg-zinc-900/40 p-3">
            <div className="text-violet-300 text-[9.5px] tracking-[0.25em] uppercase mb-2 flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <Edit size={11} /> write quorum (w)
            </div>
            <div className="flex items-center gap-2">
              <button onClick={decW} disabled={W <= 1}
                className="w-8 h-8 border border-violet-300/50 text-violet-300 disabled:opacity-30 hover:bg-violet-300/10 transition-colors flex items-center justify-center">
                <Minus size={14} />
              </button>
              <div className="flex-1 text-center text-violet-100 text-[22px] font-bold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {W}
              </div>
              <button onClick={incW} disabled={W >= N}
                className="w-8 h-8 border border-violet-300/50 text-violet-300 disabled:opacity-30 hover:bg-violet-300/10 transition-colors flex items-center justify-center">
                <Plus size={14} />
              </button>
            </div>
            <div className="text-zinc-500 text-[10px] mt-1.5 text-center"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              acks needed per write
            </div>
          </div>

          {/* Read quorum */}
          <div className="border border-zinc-800 bg-zinc-900/40 p-3">
            <div className="text-cyan-400 text-[9.5px] tracking-[0.25em] uppercase mb-2 flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <Eye size={11} /> read quorum (r)
            </div>
            <div className="flex items-center gap-2">
              <button onClick={decR} disabled={R <= 1}
                className="w-8 h-8 border border-cyan-400/50 text-cyan-400 disabled:opacity-30 hover:bg-cyan-400/10 transition-colors flex items-center justify-center">
                <Minus size={14} />
              </button>
              <div className="flex-1 text-center text-cyan-100 text-[22px] font-bold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {R}
              </div>
              <button onClick={incR} disabled={R >= N}
                className="w-8 h-8 border border-cyan-400/50 text-cyan-400 disabled:opacity-30 hover:bg-cyan-400/10 transition-colors flex items-center justify-center">
                <Plus size={14} />
              </button>
            </div>
            <div className="text-zinc-500 text-[10px] mt-1.5 text-center"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              nodes consulted per read
            </div>
          </div>
        </div>

        {/* Presets */}
        <div className="mb-4">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            common configurations
          </div>
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map(p => (
              <button key={p.label} onClick={() => applyPreset(p)}
                className="px-2.5 py-1 border border-zinc-700 text-zinc-400 hover:border-violet-300/50 hover:text-zinc-200 transition-colors text-[10.5px]"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Analysis panel */}
        <div className={`border p-3 mb-4 ${
          cfg.strong
            ? 'border-violet-300 bg-violet-300/10'
            : 'border-amber-400/60 bg-amber-400/10'
        }`}>
          <div className={`text-[10px] tracking-[0.25em] uppercase font-semibold mb-2 flex items-center gap-2 ${
            cfg.strong ? 'text-violet-300' : 'text-amber-400'
          }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            {cfg.strong ? <ShieldCheck size={11} /> : <AlertTriangle size={11} />}
            {cfg.label}
          </div>
          <div className="grid sm:grid-cols-2 gap-x-4 gap-y-1.5 text-[11.5px]"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <div>
              <span className="text-zinc-500">R + W vs N:</span>{' '}
              <span className={cfg.strong ? 'text-violet-200 font-bold' : 'text-amber-300 font-bold'}>
                {R} + {W} = {R + W} {cfg.strong ? '>' : '≤'} {N}
              </span>
            </div>
            <div>
              <span className="text-zinc-500">min overlap:</span>{' '}
              <span className={cfg.minOverlap > 0 ? 'text-violet-200' : 'text-amber-300'}>
                {cfg.minOverlap} node{cfg.minOverlap === 1 ? '' : 's'}
              </span>
            </div>
            <div>
              <span className="text-zinc-500">writes tolerate:</span>{' '}
              <span className="text-zinc-200">{cfg.writeFaultTolerance} node failure{cfg.writeFaultTolerance === 1 ? '' : 's'}</span>
            </div>
            <div>
              <span className="text-zinc-500">reads tolerate:</span>{' '}
              <span className="text-zinc-200">{cfg.readFaultTolerance} node failure{cfg.readFaultTolerance === 1 ? '' : 's'}</span>
            </div>
          </div>
          <div className="mt-2 pt-2 border-t border-zinc-700 text-zinc-300 text-[12.5px] leading-relaxed">
            {cfg.strong ? (
              <>
                <strong className="text-violet-200">Strong consistency guaranteed.</strong> Any read of R nodes and any write of W nodes must overlap by at least {cfg.minOverlap} node{cfg.minOverlap === 1 ? '' : 's'}. That overlap is the node carrying the freshest value.
              </>
            ) : (
              <>
                <strong className="text-amber-300">Eventual consistency.</strong> Read and write sets can be disjoint — meaning a read might miss the latest write entirely. Replicas converge over time via read-repair and anti-entropy, but at any given moment a read may return stale data.
              </>
            )}
          </div>
        </div>

        {/* Cluster visualization */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-3 mb-3">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-3"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            cluster
          </div>
          <div className="flex justify-center gap-2 mb-3 flex-wrap">
            {Array.from({ length: N }, (_, i) => {
              const inW = sample?.writeNodes.has(i);
              const inR = sample?.readNodes.has(i);
              const inBoth = inW && inR;
              const cls = inBoth
                ? 'border-zinc-100 bg-gradient-to-br from-violet-300 to-cyan-400 text-zinc-900 ring-2 ring-zinc-100'
                : inW
                  ? 'border-violet-300 bg-violet-300/30 text-violet-100'
                  : inR
                    ? 'border-cyan-400 bg-cyan-400/30 text-cyan-100'
                    : 'border-zinc-700 bg-zinc-900 text-zinc-500';
              return (
                <div key={i} className={`w-12 h-12 border-2 ${cls} flex items-center justify-center text-[12px] font-bold transition-all`}
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  N{i + 1}
                </div>
              );
            })}
          </div>
          {sample && (
            <div className="text-zinc-300 text-[12px] leading-relaxed text-center"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <div className="flex justify-center gap-4 flex-wrap mb-2">
                <span className="text-violet-300">■ write set ({W})</span>
                <span className="text-cyan-400">■ read set ({R})</span>
                <span className="text-zinc-100">■ overlap ({overlap.length})</span>
              </div>
              <div className={`mt-1 ${overlap.length > 0 ? 'text-violet-200' : 'text-amber-300'}`}>
                {overlap.length > 0
                  ? `✓ ${overlap.length} node${overlap.length > 1 ? 's' : ''} in both sets — read sees the latest write`
                  : `⚠ disjoint sets — read may not see the latest write`}
              </div>
            </div>
          )}
        </div>

        {/* Sample button */}
        <div className="flex gap-2">
          <button onClick={runSample}
            className="px-3 py-1.5 border border-violet-300 bg-violet-300/10 text-violet-200 hover:bg-violet-300/20 transition-colors text-[11.5px] font-semibold flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Zap size={11} /> sample read &amp; write
          </button>
          <button onClick={() => setSample(null)}
            className="px-3 py-1.5 border border-zinc-700 text-zinc-400 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[11px] flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <RotateCcw size={11} /> clear
          </button>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section04_Quorum() {
  return (
    <>
      <SectionLabel>section 04</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Quorum — tuning the consistency-availability dial
      </h2>
      <P>
        Section 02 used Raft: every write goes through one leader, every read sees that leader&apos;s
        state. Strong consistency by construction; latency bounded by leader contact. Section 03
        used vector clocks: leaderless, every node accepts writes, conflicts detected at read
        time. Maximum availability; weaker consistency. Quorum sits between them — a knob you
        turn to tune how strong-or-eventual your consistency is, and how many failures the
        cluster can tolerate. Amazon&apos;s 2007 Dynamo paper formalized it as the N/W/R model.
      </P>

      <H2 num="◇ 01">The N/W/R model</H2>
      <Code id="nwr-definition" lang="text">{`N    Number of replicas for each piece of data.
     (Often called "replication factor".)
     Common values: 3 (small cluster) or 5 (most production).

W    Number of replicas that must acknowledge a WRITE before it counts.
     1 ≤ W ≤ N. Higher W → more durable, slower writes.

R    Number of replicas consulted on every READ.
     1 ≤ R ≤ N. Higher R → fresher reads, more latency.

THE CRUCIAL PROPERTY:

   R + W > N   →   STRONG CONSISTENCY
                   (any read sees the latest committed write)

   R + W ≤ N   →   EVENTUAL CONSISTENCY
                   (reads may be stale; replicas converge over time)

The "+1 overlap" argument: any W-node write set and any R-node read set
must overlap by at least max(0, R+W-N) nodes. When that's ≥ 1, the read
includes a node that participated in the most recent successful write —
and that node has the value.`}</Code>

      <H2 num="◇ 02">Why the overlap argument works</H2>
      <P>
        The math is straightforward. With N total nodes, if you pick any W of them and any R of
        them, the pigeonhole principle tells you the two sets must share at least{' '}
        <Kbd>max(0, R + W - N)</Kbd> nodes. When R + W &gt; N, that minimum is at least 1 —
        guaranteed.
      </P>
      <Code id="overlap-math" lang="text">{`Cluster size N = 5

  W = 3, R = 3
  R + W = 6 > N = 5   →   minimum overlap = 6 - 5 = 1   ✓ strong
  Any 3-node write set and any 3-node read set MUST share at least 1 node.

  W = 2, R = 2
  R + W = 4 ≤ N = 5   →   sets can be disjoint   ⚠ eventual
  Example: write hits {N1, N2}, read consults {N3, N4}. No overlap.
           The read does not see the write. (Eventually it will, when
           replication catches up.)

  W = 5, R = 1     →   strong, read-optimized
  W = 1, R = 5     →   strong, write-optimized
  W = 3, R = 3     →   strong, balanced (the typical default for N=5)`}</Code>
      <Callout kind="system" title="WHY THIS IS THE SAME ARGUMENT AS RAFT QUORUM">
        Raft&apos;s "majority" rule is the special case of N/W/R where W = R = ⌊N/2⌋ + 1. The
        same overlap argument applies: two majorities of an N-node cluster must overlap by at
        least one node, and that node carries the most recent log entry. N/W/R generalizes
        this — you can shift the trade-off toward read-fast or write-fast by adjusting W and R
        independently, instead of always requiring strict majority on both.
      </Callout>

      <H2 num="◇ 03">Common configurations and their trade-offs</H2>
      <Code id="configurations" lang="text">{`CONFIG               STRONG?   WRITE COST   READ COST   USE CASE
──────               ───────   ──────────   ─────────   ────────
N=5, W=3, R=3        ✓ yes     medium       medium      DEFAULT — most general workloads
N=5, W=5, R=1        ✓ yes     slow         fast        read-heavy + small write rate
N=5, W=1, R=5        ✓ yes     fast         slow        write-heavy + tolerable read latency
N=5, W=1, R=1        ✗ no      fastest      fastest     max availability, no guarantee
N=5, W=2, R=2        ✗ no      fast         fast        eventual; convergence via repair
N=3, W=2, R=2        ✓ yes     medium       medium      small cluster, balanced

REAL-WORLD CHOICES:
  Cassandra default       N=3, W=quorum, R=quorum    → strong
  DynamoDB strong read    N=3, W=2,      R=2         → strong
  DynamoDB eventual read  N=3, W=2,      R=1         → eventual (cheaper, faster)
  Riak default            N=3, W=2,      R=2         → strong (tunable per-bucket)`}</Code>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 04">Turn the dial</H2>
      <P>
        Pick a cluster size. Adjust W and R. Watch the consistency guarantee, the minimum
        overlap, and the fault tolerance update in real time. Click "Sample read &amp; write" to
        randomly pick a W-node write set and an R-node read set — and see whether they overlap.
        The four preset buttons jump to canonical configurations; the cluster visualization
        makes the overlap insight visible.
      </P>

      <QuorumExplorer />

      <H2 num="◇ 05">Sloppy quorum — surviving partitions at a cost</H2>
      <P>
        Strict quorum says: a write counts only when W of the N DESIGNATED replicas acknowledge
        it. During a network partition, if W of those designated replicas are unreachable, the
        write fails. Sloppy quorum relaxes this: accept the write at any W reachable nodes,
        even nodes that are not among the designated N. Available, but the data lives somewhere
        unexpected.
      </P>
      <Code id="sloppy-quorum" lang="text">{`SETUP: N = 3 designated replicas for key K: N1, N2, N3
       Partition isolates N1, N2, N3 from the writing client.
       N4, N5 are reachable but not in the designated set.

STRICT QUORUM: write fails. The cluster preserves consistency by refusing.

SLOPPY QUORUM: write goes to N4, N5 (the reachable nodes) instead.
              The client gets a success ack.
              When the partition heals, N4 and N5 "hand off" the write
              to N1, N2, N3 — the designated replicas.

THE TRADE: availability over strict locality. The risk: if N4 or N5 die
before the handoff completes, the write is silently lost (the designated
replicas never received it; the temporary holders are gone).

Sloppy quorum is opt-in in Cassandra (hinted handoff). Riak makes it the
default. DynamoDB doesn't use it — strong-consistency reads return an
error during a partition rather than accept ambiguity.`}</Code>

      <H2 num="◇ 06">Read repair and anti-entropy</H2>
      <P>
        Eventual-consistency configurations rely on background mechanisms to converge.
        Two cooperate:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-violet-300">Read repair.</strong> Every read consults R replicas. If those R replicas disagree on the value, the coordinator picks the most recent one (by vector clock or timestamp), returns it to the client, AND writes it back to the stale replicas in the background. The act of reading IS the repair. Cheap; eager; opportunistic.
        </li>
        <li>
          <strong className="text-violet-300">Anti-entropy via Merkle trees.</strong> Periodically — typically every hour or day — replicas exchange Merkle tree summaries of their data. Hash mismatches at the root point to subtrees that diverge; the protocol walks down the tree to find specific differing keys, then exchanges actual values. Catches inconsistencies that read repair missed (e.g., data that nobody reads frequently). Expensive; periodic; comprehensive.
        </li>
      </ul>
      <P>
        Together: read repair fixes hot data continuously; anti-entropy fixes cold data
        eventually. Both are running in any production Cassandra / Riak / DynamoDB cluster
        whether you set them up or not.
      </P>

      <H2 num="◇ 07">Where quorum lives in production</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-violet-300">DynamoDB.</strong> Original Dynamo (2007) introduced N/W/R as a tunable. Modern DynamoDB exposes two read modes: "strongly consistent reads" (effectively R+W &gt; N) and "eventually consistent reads" (R=1, cheaper, faster). Per-request choice.
        </li>
        <li>
          <strong className="text-violet-300">Cassandra.</strong> Per-query consistency levels: ONE / TWO / THREE / QUORUM / ALL / LOCAL_QUORUM / EACH_QUORUM (for multi-DC). Same query can be issued with different levels by different code paths.
        </li>
        <li>
          <strong className="text-violet-300">Riak.</strong> Per-bucket configuration. Conflict detection via vector clocks (Atlas 21 §03) returns "siblings" for the application to merge when concurrent writes occur.
        </li>
        <li>
          <strong className="text-violet-300">ScyllaDB / TiKV / Aerospike.</strong> All speak the same N/W/R vocabulary. Aerospike pioneered making strong consistency the default while still allowing per-namespace tunability.
        </li>
        <li>
          <strong className="text-violet-300">PostgreSQL synchronous replicas.</strong> Conceptually similar: <Kbd>synchronous_commit = on</Kbd> with N synchronous replicas requires N+1 acks (primary + N replicas) before a write is durable. Less tunable than Dynamo-style but the same trade-off underneath.
        </li>
      </ul>

      <H2 num="◇ 08">Hardening checklist for quorum-based systems</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ N, W, R chosen deliberately — not "whatever the defaults are"</li>
        <li>✓ Strong consistency configurations verified: R + W &gt; N held in all environments</li>
        <li>✓ Per-table or per-query consistency levels documented (most systems support different levels for different data)</li>
        <li>✓ Sloppy quorum behavior known — silent data loss possible if not understood</li>
        <li>✓ Read repair enabled and tuned (most systems do this by default; verify)</li>
        <li>✓ Anti-entropy (Merkle tree sync) scheduled and monitored — runs successfully on cadence</li>
        <li>✓ Cluster size chosen with quorum-tolerance in mind: N=3 tolerates 1 failure, N=5 tolerates 2, N=7 tolerates 3 — always one fewer than your failure tolerance</li>
        <li>✓ Latency budgets account for tail latency: with W=3 and 99th percentile node latency of 50ms, write latency can spike to 50ms+ when one node is slow</li>
        <li>✓ Multi-DC quorum (LOCAL_QUORUM vs EACH_QUORUM) chosen based on geographic tolerance for stale reads</li>
      </ul>

      {/* ──────────────────────────────────────────────────────────────── */}
      {/* CLOSING — Atlas 21 wrap + middle-of-arc framing toward Atlas 22 */}
      {/* ──────────────────────────────────────────────────────────────── */}

      <SectionLabel>end of atlas</SectionLabel>
      <H2 num="◆">What you can do now</H2>
      <P>Four sections back, "distributed systems" was a phrase that meant "harder somehow." Now you can:</P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-violet-300">Reason about partial failure</strong> — fallacies, the third outcome of network calls (timeouts that hide success-or-failure), quorum math, the FLP limits of what any protocol can guarantee</li>
        <li><strong className="text-violet-300">Read and reason about Raft</strong> — three states, terms as logical clocks, leader election, log replication, the five safety properties, where it ships (etcd, Consul, CockroachDB, Nomad)</li>
        <li><strong className="text-violet-300">Use logical clocks deliberately</strong> — happens-before, Lamport vs vector clocks, concurrent-event detection, when HLCs are the practical compromise</li>
        <li><strong className="text-violet-300">Tune the consistency-availability dial</strong> — N/W/R configurations, overlap math, sloppy quorum trade-offs, read repair vs anti-entropy</li>
      </ul>

      <SectionLabel>middle of the data-systems arc</SectionLabel>
      <H2 num="◆">The arc, so far</H2>
      <P>
        Atlas 20 covered one-machine data systems and introduced replication. Atlas 21 — this
        one — pushes into the protocols and math that make multi-machine systems work. Atlas 22
        will close the trilogy by changing the question entirely: what if you stop trying to
        agree on shared state and instead structure systems around immutable event streams?
      </P>
      <Code id="data-arc-update" lang="text">{`ATLAS 20 — DATABASES AT SCALE       Indexes · query plans · transactions · replication
   ✓ complete                      "How does the data live and move?"

ATLAS 21 — DISTRIBUTED SYSTEMS      Partial failure · consensus · clocks · quorum
   ✓ complete                      "How do machines agree?"

ATLAS 22 — EVENT-DRIVEN             Queues · streams · log compaction · exactly-once-ish
   (next)                           "What if you didn't need agreement?"`}</Code>
      <P>
        Atlas 22 will be the most practical of the three. The previous two were about reasoning
        — building the mental models you need to handle distributed state. Atlas 22 is about
        building patterns that AVOID needing those models for many of your problems:
        append-only logs, consumer groups, idempotent processors, log compaction, the
        exactly-once-ish protocols that real teams ship. Kafka, NATS JetStream, Redis Streams,
        the patterns from Designing Data-Intensive Applications, the operational reality of
        running these in production.
      </P>
      <Callout kind="win" title="THE THREE-ATLAS ARC IN ONE LINE EACH">
        Atlas 20 — your DATA needs to be queryable, indexed, transactional, replicated.<br/>
        Atlas 21 — when one machine is not enough, here is how multiple machines agree (or detect when they cannot).<br/>
        Atlas 22 — sometimes the right answer is to NOT need agreement: stream the events; let consumers replay; embrace eventual ordering.
      </Callout>
      <P>
        Reference index at <Kbd>atlases.vercel.app</Kbd>. The series continues.
      </P>
      <div className="text-zinc-500 text-center text-[10.5px] tracking-[0.3em] uppercase mt-12 mb-4"
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        ⬢ · atlas twenty-one · complete · arc continues
      </div>
    </>
  );
}
