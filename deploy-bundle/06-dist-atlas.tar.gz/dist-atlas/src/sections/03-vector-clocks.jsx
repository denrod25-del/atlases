/* Section 03 — Vector Clocks and Causal Ordering.
 *
 * Prose + Vector Clock Visualizer.
 *
 * The simulator: three nodes (N1, N2, N3) with vertical timelines. Three
 * scripted scenarios walk through canonical cases:
 *
 *   1. Sequential events at one node — vector clock at that node
 *      increments, others stay at zero
 *   2. Causal chain via messages — events at one node, message to another,
 *      the receiver's clock merges with the sender's; the chain creates
 *      a happens-before sequence visible end-to-end
 *   3. Concurrent events — events at different nodes without communication;
 *      vector clock comparison reveals they are concurrent (neither
 *      dominates); a later message merges them
 *
 * Visualization: SVG spacetime diagram. Time runs top-to-bottom. Each node
 * is a vertical column. Events are circles on the column. Messages are
 * diagonal arrows from send-event to receive-event. Vector clock value is
 * rendered next to each event.
 *
 * All prose strings use backticks (template literals).
 */

import { useState, useEffect, useRef } from 'react';
import { Sparkles, Play, Pause, ChevronRight, RotateCcw, ArrowRight } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Vector Clock Visualizer
// ───────────────────────────────────────────────────────────────────────

// Layout constants
const NODE_X = [80, 230, 380];           // x-position of each node's column
const TOP_Y = 50;                        // y-position of first event row
const ROW_H = 56;                        // pixels per time row

// Three scenarios. Each event has:
//   step: time row (1-based)
//   node: 0, 1, or 2
//   label: short event name
//   type: 'local' | 'send' | 'receive'
//   vector: vector clock value at this event
//   target?: receiver node (for 'send')
//   source?: sender node (for 'receive')
//   sourceStep?: step number of the matching 'send' (for drawing arrows)
const SCENARIOS = [
  {
    id: 'sequential',
    label: 'Sequential events at one node',
    description: `Three local events all happening at N1. No communication. The vector clock at N1 increments at each event; the entries for N2 and N3 stay at zero because they have not heard about anything yet.`,
    events: [
      { step: 1, node: 0, label: 'e1', type: 'local', vector: [1, 0, 0] },
      { step: 2, node: 0, label: 'e2', type: 'local', vector: [2, 0, 0] },
      { step: 3, node: 0, label: 'e3', type: 'local', vector: [3, 0, 0] },
    ],
    note: `e1 < e2 < e3 (all causally ordered). e1, e2, e3 are concurrent with everything at N2 and N3 because no message has been exchanged.`,
  },
  {
    id: 'causal-chain',
    label: 'Causal chain via messages',
    description: `An event at N1 triggers a message to N2. N2 does a local event and sends to N3. The chain creates a happens-before sequence: anything before a message must happen before anything after that message at the receiver.`,
    events: [
      { step: 1, node: 0, label: 'e1', type: 'local',   vector: [1, 0, 0] },
      { step: 2, node: 0, label: 'e2', type: 'send',    vector: [2, 0, 0], target: 1 },
      { step: 3, node: 1, label: 'e3', type: 'receive', vector: [2, 1, 0], source: 0, sourceStep: 2 },
      { step: 4, node: 1, label: 'e4', type: 'local',   vector: [2, 2, 0] },
      { step: 5, node: 1, label: 'e5', type: 'send',    vector: [2, 3, 0], target: 2 },
      { step: 6, node: 2, label: 'e6', type: 'receive', vector: [2, 3, 1], source: 1, sourceStep: 5 },
    ],
    note: `Causal chain: e1 < e2 < e3 < e4 < e5 < e6. The vector clock at e6 is [2,3,1] — N3 now "knows about" 2 events at N1 and 3 at N2, even though N3 only received one message directly.`,
  },
  {
    id: 'concurrent',
    label: 'Concurrent events (parallel histories)',
    description: `Events happen at N1 and N3 with no communication between them. Vector clock comparison shows they are CONCURRENT — neither happens-before the other. When N2 later receives messages from both, its clock merges both histories.`,
    events: [
      { step: 1, node: 0, label: 'e1', type: 'local',   vector: [1, 0, 0] },
      { step: 2, node: 2, label: 'e2', type: 'local',   vector: [0, 0, 1] },
      { step: 3, node: 0, label: 'e3', type: 'send',    vector: [2, 0, 0], target: 1 },
      { step: 4, node: 1, label: 'e4', type: 'receive', vector: [2, 1, 0], source: 0, sourceStep: 3 },
      { step: 5, node: 2, label: 'e5', type: 'send',    vector: [0, 0, 2], target: 1 },
      { step: 6, node: 1, label: 'e6', type: 'receive', vector: [2, 2, 2], source: 2, sourceStep: 5 },
    ],
    note: `e1 and e2 are CONCURRENT: [1,0,0] does not dominate [0,0,1] (entry 3 is smaller), and [0,0,1] does not dominate [1,0,0] (entry 1 is smaller). Both parallel histories merge at e6, where the clock [2,2,2] correctly captures everything anyone has heard about.`,
  },
];

// ───────────────────────────────────────────────────────────────────────
// Vector clock comparison
// ───────────────────────────────────────────────────────────────────────

// Returns 'before' | 'after' | 'concurrent' | 'equal'
function compareClocks(a, b) {
  let aLessOrEqual = true;
  let bLessOrEqual = true;
  let strictlyLess = false;
  let strictlyMore = false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] > b[i]) { bLessOrEqual = false; strictlyMore = true; }
    if (a[i] < b[i]) { aLessOrEqual = false; strictlyLess = true; }
  }
  if (aLessOrEqual && !strictlyLess && !strictlyMore) return 'equal';
  if (aLessOrEqual && strictlyLess && !strictlyMore) return 'before';
  if (bLessOrEqual && strictlyMore && !strictlyLess) return 'after';
  return 'concurrent';
}

// ───────────────────────────────────────────────────────────────────────
// Simulator UI
// ───────────────────────────────────────────────────────────────────────

function VectorClockVisualizer() {
  const [scenarioIdx, setScenarioIdx] = useState(0);
  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [compareA, setCompareA] = useState(null);
  const [compareB, setCompareB] = useState(null);
  const intervalRef = useRef(null);

  const scenario = SCENARIOS[scenarioIdx];
  const visibleEvents = scenario.events.slice(0, step + 1);
  const atEnd = step >= scenario.events.length - 1;
  const totalRows = scenario.events.length;

  useEffect(() => {
    if (!playing) return;
    intervalRef.current = setInterval(() => {
      setStep(s => {
        if (s >= scenario.events.length - 1) {
          setPlaying(false);
          return s;
        }
        return s + 1;
      });
    }, 1500);
    return () => clearInterval(intervalRef.current);
  }, [playing, scenario]);

  const switchScenario = (i) => {
    setPlaying(false);
    setScenarioIdx(i);
    setStep(0);
    setCompareA(null);
    setCompareB(null);
  };

  const reset = () => { setPlaying(false); setStep(0); setCompareA(null); setCompareB(null); };
  const advance = () => { if (!atEnd) setStep(s => s + 1); };

  // SVG dimensions
  const width = 460;
  const height = TOP_Y + (totalRows + 1) * ROW_H;

  // Toggle event for comparison
  const toggleCompare = (eventLabel) => {
    if (compareA === eventLabel) { setCompareA(null); return; }
    if (compareB === eventLabel) { setCompareB(null); return; }
    if (!compareA) { setCompareA(eventLabel); return; }
    if (!compareB) { setCompareB(eventLabel); return; }
    // Both set — replace A
    setCompareA(eventLabel);
    setCompareB(null);
  };

  const evA = visibleEvents.find(e => e.label === compareA);
  const evB = visibleEvents.find(e => e.label === compareB);
  const cmpResult = (evA && evB) ? compareClocks(evA.vector, evB.vector) : null;

  return (
    <div className="my-6 border border-violet-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-violet-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-violet-300" />
          <span className="text-violet-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · vector clock visualizer
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => switchScenario(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === scenarioIdx
                  ? 'border-violet-300 bg-violet-300/15 text-violet-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-violet-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {i + 1}. {s.label}
            </button>
          ))}
        </div>

        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13px] leading-relaxed italic">
          {scenario.description}
        </div>

        {/* SVG spacetime diagram */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-3 mb-3 overflow-x-auto">
          <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ minWidth: '440px' }}>
            {/* Column headers */}
            {['N1', 'N2', 'N3'].map((label, i) => (
              <g key={i}>
                <text x={NODE_X[i]} y={28} textAnchor="middle"
                  fontSize={13} fontWeight="bold"
                  className="fill-violet-300"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {label}
                </text>
                <line x1={NODE_X[i]} y1={36} x2={NODE_X[i]} y2={height - 20}
                  stroke="#3f3f46" strokeWidth={1.5} strokeDasharray="2 3" />
              </g>
            ))}

            {/* Time label */}
            <text x={12} y={28} fontSize={9} className="fill-zinc-500"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              time
            </text>
            <line x1={20} y1={36} x2={20} y2={height - 20}
              stroke="#3f3f46" strokeWidth={1} />
            <polygon points={`16,${height - 22} 24,${height - 22} 20,${height - 14}`}
              fill="#52525b" />

            {/* Message arrows (draw first so events appear on top) */}
            {visibleEvents.filter(e => e.type === 'receive').map((recvEvt, idx) => {
              const sendEvt = visibleEvents.find(e => e.step === recvEvt.sourceStep);
              if (!sendEvt) return null;
              const x1 = NODE_X[sendEvt.node] + 12;
              const y1 = TOP_Y + sendEvt.step * ROW_H;
              const x2 = NODE_X[recvEvt.node] - 12;
              const y2 = TOP_Y + recvEvt.step * ROW_H;
              return (
                <g key={`msg-${idx}`}>
                  <line x1={x1} y1={y1} x2={x2} y2={y2}
                    stroke="#22d3ee" strokeWidth={1.5} opacity={0.7} />
                  <polygon points={`${x2},${y2} ${x2 - 6},${y2 - 4} ${x2 - 6},${y2 + 4}`}
                    fill="#22d3ee" opacity={0.85} />
                </g>
              );
            })}

            {/* Event dots + labels + vector clocks */}
            {visibleEvents.map((e, i) => {
              const cx = NODE_X[e.node];
              const cy = TOP_Y + e.step * ROW_H;
              const isLatest = i === visibleEvents.length - 1;
              const isCompared = e.label === compareA || e.label === compareB;
              const fillColor = isCompared
                ? '#22d3ee'
                : isLatest ? '#c4b5fd' : '#a78bfa';
              const radius = isLatest || isCompared ? 8 : 6;
              // Place vector clock label: left or right of dot based on node column
              const textX = e.node === 0 ? cx + 14 : (e.node === 2 ? cx - 14 : cx + 14);
              const textAnchor = e.node === 2 ? 'end' : 'start';
              return (
                <g key={i} onClick={() => toggleCompare(e.label)} style={{ cursor: 'pointer' }}>
                  <circle cx={cx} cy={cy} r={radius}
                    fill={fillColor}
                    stroke={isCompared ? '#06b6d4' : (isLatest ? '#ddd6fe' : '#7c3aed')}
                    strokeWidth={2} />
                  <text x={cx} y={cy + 3} textAnchor="middle"
                    fontSize={9} fontWeight="bold" fill="#09090b"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    {e.label}
                  </text>
                  <text x={textX} y={cy + 3} textAnchor={textAnchor}
                    fontSize={10.5} className="fill-zinc-300"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    [{e.vector.join(',')}]
                  </text>
                </g>
              );
            })}
          </svg>
          <div className="text-zinc-600 text-[10px] mt-1 pt-2 border-t border-zinc-800 flex flex-wrap items-center gap-x-4 gap-y-1"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <span>● event · click any two to compare</span>
            <span className="text-cyan-400">→ message</span>
            <span>[a,b,c] = vector clock</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <button onClick={() => setPlaying(p => !p)} disabled={atEnd && !playing}
            className="px-3 py-1.5 border border-violet-300 bg-violet-300/10 text-violet-200 hover:bg-violet-300/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-[11.5px] font-semibold flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            {playing ? <><Pause size={11} /> pause</> : <><Play size={11} /> play</>}
          </button>
          <button onClick={advance} disabled={atEnd || playing}
            className="px-3 py-1.5 border border-cyan-400 bg-cyan-400/10 text-cyan-200 hover:bg-cyan-400/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-[11.5px] font-semibold flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <ChevronRight size={11} /> step
          </button>
          <button onClick={reset}
            className="px-3 py-1.5 border border-zinc-700 text-zinc-400 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[11px] flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <RotateCcw size={11} /> reset
          </button>
          <div className="ml-auto text-zinc-500 text-[10.5px]"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            step {step + 1} / {scenario.events.length}
          </div>
        </div>

        {/* Comparison panel */}
        {(evA || evB) && (
          <div className="border border-cyan-400/40 bg-cyan-400/5 p-3 mb-3">
            <div className="text-cyan-400 text-[10px] tracking-[0.25em] uppercase font-semibold mb-2"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              causality comparison
            </div>
            {evA && evB ? (
              <div className="text-zinc-200 text-[12.5px] leading-relaxed">
                <div className="flex items-center gap-3 mb-2 flex-wrap"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  <span className="text-cyan-300 font-bold">{evA.label}</span>
                  <span className="text-zinc-400">[{evA.vector.join(',')}]</span>
                  <span className="text-zinc-500">
                    {cmpResult === 'before' && '< '}
                    {cmpResult === 'after' && '> '}
                    {cmpResult === 'concurrent' && '∥ '}
                    {cmpResult === 'equal' && '= '}
                  </span>
                  <span className="text-cyan-300 font-bold">{evB.label}</span>
                  <span className="text-zinc-400">[{evB.vector.join(',')}]</span>
                </div>
                <div className="text-zinc-300 text-[12.5px]">
                  {cmpResult === 'before' && (
                    <>Result: <span className="text-violet-300 font-semibold">{evA.label} happens-before {evB.label}</span>. Every entry of {evA.label}&apos;s clock is ≤ {evB.label}&apos;s, with at least one strictly less. There is a causal path from {evA.label} to {evB.label}.</>
                  )}
                  {cmpResult === 'after' && (
                    <>Result: <span className="text-violet-300 font-semibold">{evB.label} happens-before {evA.label}</span>. Symmetric to the above.</>
                  )}
                  {cmpResult === 'concurrent' && (
                    <>Result: <span className="text-amber-300 font-semibold">{evA.label} and {evB.label} are CONCURRENT</span>. Neither clock dominates the other — there is some entry where {evA.label} is greater, and some entry where {evB.label} is greater. No causal path connects them.</>
                  )}
                  {cmpResult === 'equal' && (
                    <>Result: identical clocks — same event.</>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-zinc-400 text-[12.5px]">
                Selected: <span className="text-cyan-300 font-semibold">{(evA || evB).label}</span>. Click another event to compare.
              </div>
            )}
          </div>
        )}

        {/* Scenario footnote */}
        {atEnd && (
          <Callout kind="info" title="what this scenario teaches">
            {scenario.note}
          </Callout>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section03_VectorClocks() {
  return (
    <>
      <SectionLabel>section 03</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Vector clocks — ordering events without a central authority
      </h2>
      <P>
        Section 02 used Raft to elect a single leader and serialize every write through it.
        Single leader, single timeline, simple. The trade-off: every write waits for the
        leader. When you cannot afford that latency — geographic distribution, leaderless
        replication, peer-to-peer systems — you give up single-timeline order and need a
        different mechanism to reason about cause and effect. Vector clocks are that
        mechanism.
      </P>

      <H2 num="◇ 01">Why wall clocks fail across machines</H2>
      <P>
        The obvious idea: timestamp every event with the wall clock, sort by timestamp. This
        does not work on distributed systems. Three reasons:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-rose-400">Clock skew.</strong> Two machines reading time at the same instant produce different values. NTP keeps them within ~10ms of each other in a datacenter, but ~10ms is enormous compared to event rates (microsecond operations are common). Across regions, skew can be 100ms+. Events ordered by wall clock can appear out of order relative to their actual causality.
        </li>
        <li>
          <strong className="text-rose-400">Clock drift and NTP corrections.</strong> Quartz crystals drift at different rates. NTP corrects this by stepping or slewing time. Step corrections can move the clock BACKWARDS — meaning two consecutive events can have the second one appear to happen "before" the first. Every database that uses wall clocks for timestamps has hit this bug.
        </li>
        <li>
          <strong className="text-rose-400">Leap seconds.</strong> Periodically, UTC inserts an extra second (or removes one). Most kernels handle this by repeating the same second twice, producing two events with identical timestamps. Production outages have been caused by leap-second handling bugs (the famous Reddit / LinkedIn / FAA outages of 2012 and 2017).
        </li>
      </ul>
      <Callout kind="warn" title="THE PRACTICAL RULE">
        Never use wall-clock timestamps for ordering events that cross machine boundaries.
        For display, fine. For "did X happen before Y" decisions, never. Use logical clocks.
      </Callout>

      <H2 num="◇ 02">The happens-before relation</H2>
      <P>
        Leslie Lamport&apos;s 1978 insight: instead of trying to order events by physical time,
        define a partial order based on causality. An event A "happens-before" event B
        (written <Kbd>A → B</Kbd>) if any of these holds:
      </P>
      <Code id="happens-before" lang="text">{`1. A and B happen at the same node, and A comes before B in that node's
   local order. (Local sequencing.)

2. A is the sending of a message, and B is the receiving of that message.
   (Messages propagate causality.)

3. There exists some event C such that A → C and C → B.
   (Transitivity — chains of causality compose.)

If neither A → B nor B → A, then A and B are CONCURRENT (written A ∥ B).
This is the most important case: concurrent events cannot have caused each
other, so the system is free to merge them or report a conflict.`}</Code>
      <P>
        This is a PARTIAL order, not a total order. Some events are ordered (causal); some are
        not (concurrent). For a distributed system, that is reality — pretending events have
        a total order requires either coordination (Raft) or fabrication (wall clocks).
      </P>

      <H2 num="◇ 03">Lamport timestamps — a single counter</H2>
      <P>
        Lamport&apos;s first proposal: each node keeps a single integer counter. On every
        event, increment it. When sending a message, attach the counter. When receiving a
        message with counter <Kbd>T</Kbd>, set the local counter to{' '}
        <Kbd>max(local, T) + 1</Kbd>. The resulting timestamps respect happens-before: if
        A → B, then timestamp(A) &lt; timestamp(B).
      </P>
      <Code id="lamport" lang="text">{`Initial: all nodes counter = 0

N1: local event       → counter = 1, event has timestamp 1
N1: send to N2        → counter = 2, message has timestamp 2
N2 (counter=0): recv  → counter = max(0, 2) + 1 = 3
N2: local event       → counter = 4
N3 (counter=0): local → counter = 1   ← concurrent with N1's events

Causality respected:
  N1's first event (1) → N1's send (2) → N2's receive (3) → N2's event (4)
  All timestamps strictly increase.

But: total order is FAKE.
  N3's event has timestamp 1. So does N1's first event.
  Tied — break with node id. Result: an ARTIFICIAL total order.

THE CATCH: from timestamps alone, you cannot tell if two events are causal
or concurrent. timestamp(A) < timestamp(B) does NOT imply A → B; only the
converse. Lamport timestamps give you one direction of the if-and-only-if.`}</Code>

      <H2 num="◇ 04">Vector clocks — one counter per node</H2>
      <P>
        Vector clocks fix Lamport&apos;s limitation. Instead of a single counter, each node
        maintains a VECTOR — one counter per node in the cluster. The protocol:
      </P>
      <Code id="vector-clock-protocol" lang="text">{`Each node N_i maintains V[N_i] — an array of length N (cluster size).

On any LOCAL event at node i:
    V[i] += 1

On SEND from node i:
    V[i] += 1
    Attach the current V to the outgoing message

On RECEIVE at node j with attached vector W:
    For each k: V[k] := max(V[k], W[k])     // merge with sender's knowledge
    V[j] += 1                                // count this receive as a local event

Result: each entry V[k] tracks "the latest event from node k that this node
has either witnessed or heard about." The whole vector is a snapshot of
what THIS node knows about the cluster's history.`}</Code>

      <H2 num="◇ 05">Comparing vector clocks</H2>
      <P>
        The crucial operation: given two vector clocks A and B, decide if A → B, B → A, or
        A ∥ B (concurrent).
      </P>
      <Code id="vc-comparison" lang="text">{`Define A ≤ B iff for ALL i: A[i] <= B[i]

If A ≤ B and A ≠ B:     A → B   (A happens-before B)
If B ≤ A and A ≠ B:     B → A   (B happens-before A)
If A ≤ B AND B ≤ A:     A == B  (same event)
Otherwise:              A ∥ B   (concurrent — both have entries the other lacks)

EXAMPLES:
[1,0,0] vs [2,0,0]    →   [1,0,0] → [2,0,0]   (A ≤ B, not equal)
[2,1,0] vs [1,0,0]    →   [1,0,0] → [2,1,0]   (B ≤ A, B happens-before A)
[1,0,0] vs [0,0,1]    →   CONCURRENT          (neither dominates)
[2,2,0] vs [1,0,1]    →   CONCURRENT          (each has entry the other lacks)
[2,2,2] vs [1,1,1]    →   [1,1,1] → [2,2,2]   (B ≤ A)`}</Code>
      <P>
        Concurrent events are the case worth attention. They cannot have caused each other —
        which means they originated from different parallel histories of the cluster. A
        distributed database that allows leaderless writes must detect this case and either
        merge the writes intelligently (e.g., add to a shopping cart) or surface the
        conflict to the application (e.g., return both versions and let the client decide).
      </P>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 06">Watch vector clocks evolve</H2>
      <P>
        Three scenarios. Step through each and watch the vector clocks at each event. Click
        any two events to compare their clocks — the simulator tells you whether they are
        causally ordered or concurrent. The third scenario is the most important: events
        happening at different nodes without communication, then merging when a message
        finally arrives.
      </P>

      <VectorClockVisualizer />

      <H2 num="◇ 07">Concurrent events in real systems</H2>
      <P>
        Vector clocks are not a textbook curiosity — they ship in production. The most famous
        deployment was Amazon Dynamo (2007), whose vector-clock-based conflict detection
        influenced essentially every later eventually-consistent system:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-violet-300">Riak.</strong> Uses vector clocks (called "dotted version vectors") to detect concurrent writes. On conflict, returns all sibling versions; the application resolves.
        </li>
        <li>
          <strong className="text-violet-300">CouchDB.</strong> Each document has a revision history forming a tree; concurrent updates create branches that must be merged. Vector-clock-like reasoning underneath.
        </li>
        <li>
          <strong className="text-violet-300">Cassandra (early versions).</strong> Used last-write-wins by wall clock — and got bitten by it. Modern Cassandra uses paxos for "lightweight transactions" when concurrent ordering matters.
        </li>
        <li>
          <strong className="text-violet-300">CRDTs (Conflict-free Replicated Data Types).</strong> Many CRDT designs use vector clocks internally to ensure that concurrent updates merge deterministically. The output is provably the same regardless of message arrival order.
        </li>
        <li>
          <strong className="text-violet-300">Distributed version control (git).</strong> Conceptually similar: each commit has parent pointers; branches that diverge are concurrent histories that merge produces a single combined history.
        </li>
      </ul>

      <H2 num="◇ 08">The cost of vector clocks — and the workarounds</H2>
      <P>
        Vector clocks are not free. Two costs:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-amber-300">Size.</strong> A vector clock has one entry per node. In a 100-node cluster, every message carries 100 counters. In a cluster where nodes come and go (like long-running peer-to-peer systems), the vector can grow unboundedly because retired nodes are still in the vector.
        </li>
        <li>
          <strong className="text-amber-300">Pruning is hard.</strong> Removing a retired node from the vector is safe only if no concurrent writes from that node could still be in flight. Most systems use an epoch counter or a heartbeat-based mechanism; some accept that the vector grows over time and snapshot/compact periodically.
        </li>
      </ul>
      <Callout kind="tip" title="HYBRID LOGICAL CLOCKS — THE MODERN COMPROMISE">
        HLCs (proposed in 2014) combine a physical-clock timestamp with a logical counter for
        tie-breaking and ordering events that race. They are bounded in size (single
        integer, fixed precision), close to wall-clock time for human readability, and
        preserve happens-before like Lamport timestamps. CockroachDB, MongoDB&apos;s causal
        consistency, and YugabyteDB all use HLCs as their event-ordering primitive. They are
        not as expressive as full vector clocks (you cannot detect concurrency from HLCs
        alone), but they handle the common cases at vastly lower cost.
      </Callout>

      <H2 num="◇ 09">Hardening checklist for clock-based ordering</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ No wall-clock timestamps used for cross-machine ordering decisions</li>
        <li>✓ Logical or hybrid clocks chosen explicitly based on what you need (happens-before only? or concurrency detection?)</li>
        <li>✓ Vector clock size bounded if used at scale (epoch counters, retired-node pruning)</li>
        <li>✓ NTP configured on every host, with monitoring for sync state and drift</li>
        <li>✓ Leap-second policy understood and tested (Google&apos;s "smearing" approach is increasingly the default)</li>
        <li>✓ Concurrent-event detection has an application-level merge or conflict-resolution path — not just "pick one and hope"</li>
        <li>✓ For HLC users: monotonicity enforced even across crashes (persist the latest HLC before responding)</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        The final section ties the atlas together by zooming out from individual nodes to the
        cluster-wide consistency dial: how many nodes acknowledge a write before it counts,
        how many participate in a read, and what guarantees each combination gives you. The
        N/W/R model — Dynamo&apos;s contribution — plus the atlas-closing wrap pointing
        forward to event-driven architecture.
      </Callout>
    </>
  );
}
