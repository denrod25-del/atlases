/* Section 01 — Why distributed systems are hard.
 *
 * Prose + Network Partition Simulator.
 *
 * The simulator: a 5-node cluster laid out as a pentagon in SVG. Four
 * scenarios show different partition states — healthy, 3-2 split, single
 * isolated node, multi-partition chaos. For each, the simulator computes
 * which partitions have quorum (size >= 3 of 5) and what the cluster can
 * do in that state: accept writes (a partition has quorum) or refuse
 * (no partition has majority).
 *
 * The teaching aim: make quorum math visible. Quorum = floor(N/2) + 1.
 * Below that threshold, the system either refuses writes (CP) or accepts
 * them but diverges (AP). The simulator shows the CP case — writes are
 * refused when no quorum exists.
 *
 * All prose strings use backticks (template literals).
 */

import { useState } from 'react';
import { Sparkles, AlertTriangle, ShieldCheck, Zap, Network } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Network Partition Simulator
// ───────────────────────────────────────────────────────────────────────

// 5 nodes laid out in a pentagon centered at (160, 130)
const NODE_POSITIONS = [
  { x: 160, y:  35 },   // N1 — top
  { x: 280, y: 105 },   // N2 — upper right
  { x: 233, y: 230 },   // N3 — lower right
  { x:  87, y: 230 },   // N4 — lower left
  { x:  40, y: 105 },   // N5 — upper left
];

const SCENARIOS = [
  {
    id: 'healthy',
    label: 'Healthy',
    description: `All 5 nodes can reach each other. The cluster operates normally. Writes accepted, replication flows, consensus reachable.`,
    partitions: [[0, 1, 2, 3, 4]],
    tone: 'good',
  },
  {
    id: 'three-two',
    label: '3-2 split',
    description: `A network failure splits the cluster into two groups: nodes 1-2-3 on one side, nodes 4-5 on the other. Neither side can talk to the other.`,
    partitions: [[0, 1, 2], [3, 4]],
    tone: 'caution',
  },
  {
    id: 'isolated',
    label: 'One node isolated',
    description: `Node 5 loses its network connection. The other 4 nodes are still healthy and can talk to each other. This is the most common real failure — one VM hiccups or one network interface flaps.`,
    partitions: [[0, 1, 2, 3], [4]],
    tone: 'good',
  },
  {
    id: 'multi',
    label: 'Multi-partition (chaos)',
    description: `Network splits into three isolated groups: {1, 2}, {3, 4}, {5}. Rare but possible during major infrastructure failures (e.g., a switch failure that isolates multiple racks). None of these groups has majority.`,
    partitions: [[0, 1], [2, 3], [4]],
    tone: 'bad',
  },
];

const QUORUM = 3;  // floor(5/2) + 1

// Map a node index → its partition index (0, 1, 2, ...)
function nodeToPartition(scenario) {
  const m = new Map();
  scenario.partitions.forEach((part, pIdx) => {
    part.forEach(nIdx => m.set(nIdx, pIdx));
  });
  return m;
}

// All possible edges in a 5-node complete graph (10 edges)
const ALL_EDGES = (() => {
  const edges = [];
  for (let i = 0; i < 5; i++) {
    for (let j = i + 1; j < 5; j++) {
      edges.push([i, j]);
    }
  }
  return edges;
})();

function NetworkPartitionSimulator() {
  const [idx, setIdx] = useState(0);
  const scenario = SCENARIOS[idx];
  const partMap = nodeToPartition(scenario);

  // Which partition (if any) has quorum?
  const quorumPartition = scenario.partitions.findIndex(p => p.length >= QUORUM);
  const hasQuorum = quorumPartition !== -1;

  const partitionColors = [
    { fill: '#7c3aed', stroke: '#c4b5fd', label: 'text-violet-300' },   // violet
    { fill: '#0891b2', stroke: '#22d3ee', label: 'text-cyan-300' },     // cyan
    { fill: '#a16207', stroke: '#facc15', label: 'text-amber-300' },    // amber
  ];

  // Get color for a partition; the one with quorum gets violet, others get muted
  const partColor = (pIdx) => {
    if (!hasQuorum) {
      // No partition has quorum — everything is amber (no one can make progress)
      return partitionColors[2];
    }
    if (pIdx === quorumPartition) return partitionColors[0];
    return { fill: '#3f3f46', stroke: '#71717a', label: 'text-zinc-400' };
  };

  return (
    <div className="my-6 border border-violet-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-violet-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-violet-300" />
          <span className="text-violet-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · network partition simulator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => setIdx(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === idx
                  ? 'border-violet-300 bg-violet-300/15 text-violet-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-violet-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {i + 1}. {s.label}
            </button>
          ))}
        </div>

        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13.5px] leading-relaxed italic">
          {scenario.description}
        </div>

        <div className="grid md:grid-cols-[1fr_1fr] gap-4">
          {/* Network visualization */}
          <div className="border border-zinc-800 bg-zinc-950/60 p-3">
            <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2 flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <Network size={11} /> cluster topology
            </div>
            <svg viewBox="0 0 320 265" className="w-full">
              {/* Edges */}
              {ALL_EDGES.map(([a, b], i) => {
                const sameP = partMap.get(a) === partMap.get(b);
                const pA = NODE_POSITIONS[a];
                const pB = NODE_POSITIONS[b];
                const colorIdx = partMap.get(a);
                const color = sameP
                  ? (hasQuorum && colorIdx === quorumPartition ? '#a78bfa' : '#52525b')
                  : '#27272a';
                return (
                  <line key={i}
                    x1={pA.x} y1={pA.y} x2={pB.x} y2={pB.y}
                    stroke={color}
                    strokeWidth={sameP ? 1.5 : 1}
                    strokeDasharray={sameP ? 'none' : '3 4'}
                    opacity={sameP ? 0.8 : 0.4} />
                );
              })}
              {/* Nodes */}
              {NODE_POSITIONS.map((p, i) => {
                const pIdx = partMap.get(i);
                const color = partColor(pIdx);
                return (
                  <g key={i}>
                    <circle cx={p.x} cy={p.y} r={22}
                      fill={color.fill} stroke={color.stroke} strokeWidth={2}
                      opacity={0.95} />
                    <text x={p.x} y={p.y + 4} textAnchor="middle"
                      fontSize={11.5} fontWeight="bold" fill="white"
                      style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                      N{i + 1}
                    </text>
                  </g>
                );
              })}
            </svg>
            <div className="text-zinc-600 text-[10px] mt-2 pt-2 border-t border-zinc-800"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              solid line = nodes can communicate · dashed = partitioned
            </div>
          </div>

          {/* Quorum analysis */}
          <div className="border border-zinc-800 bg-zinc-950/60 p-3 flex flex-col">
            <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              quorum analysis
            </div>
            <div className="text-zinc-400 text-[11.5px] mb-3 leading-relaxed"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              N = 5 · quorum threshold = ⌊5/2⌋ + 1 = <span className="text-violet-300 font-bold">3</span>
            </div>

            <div className="space-y-2 mb-3">
              {scenario.partitions.map((part, pIdx) => {
                const isQ = part.length >= QUORUM;
                const c = partColor(pIdx);
                return (
                  <div key={pIdx} className={`border ${
                    isQ && hasQuorum
                      ? 'border-violet-300 bg-violet-300/10'
                      : 'border-zinc-700 bg-zinc-900/40'
                  } px-3 py-2`}>
                    <div className="flex items-center justify-between">
                      <div className={`text-[11.5px] font-semibold ${c.label}`}
                        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                        Group {pIdx + 1}: {`{${part.map(n => `N${n+1}`).join(', ')}}`}
                      </div>
                      <div className="text-[10.5px]"
                        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                        {part.length} of 5
                      </div>
                    </div>
                    <div className={`text-[10.5px] mt-0.5 tracking-[0.2em] uppercase ${
                      isQ ? 'text-violet-300' : 'text-zinc-500'
                    }`}
                      style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                      {isQ ? '✓ has quorum' : '✗ below quorum'}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Verdict */}
            <div className={`mt-auto border p-3 ${
              hasQuorum
                ? 'border-violet-300 bg-violet-300/10'
                : 'border-rose-400 bg-rose-400/10'
            }`}>
              <div className={`text-[10px] tracking-[0.25em] uppercase font-semibold mb-1 flex items-center gap-1.5 ${
                hasQuorum ? 'text-violet-300' : 'text-rose-400'
              }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {hasQuorum ? <ShieldCheck size={11} /> : <AlertTriangle size={11} />}
                {hasQuorum ? 'progress possible' : 'no progress possible'}
              </div>
              <div className="text-zinc-200 text-[12px] leading-relaxed">
                {hasQuorum ? (
                  <>
                    Group {quorumPartition + 1} ({scenario.partitions[quorumPartition].length} of 5) has majority. Writes go through; this side becomes the source of truth. Nodes outside this group refuse writes until the partition heals.
                  </>
                ) : (
                  <>
                    No group has ≥ 3 nodes. Under a CP system (strong consistency), the cluster refuses all writes until partitions heal — every node returns an error. Under an AP system (eventual consistency), each group accepts writes locally and reconciles later.
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        <Callout kind="info" title="WHY MAJORITY AND NOT SOMETHING ELSE">
          Quorum = majority is not arbitrary. The math: if every write must be acknowledged by a
          majority, and every read consults a majority, then ANY two majorities must overlap by
          at least one node. That overlap is what guarantees a read sees the most recent write —
          some node in the read-majority was also in the write-majority. Drop below majority and
          this overlap guarantee disappears.
        </Callout>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section01_WhyHard() {
  return (
    <>
      <SectionLabel>section 01</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Why distributed systems are hard
      </h2>
      <P>
        Atlas 20 ended with replication and sharding — the answers to "outgrew one machine."
        This atlas starts with the question that comes immediately after: how do multiple
        machines agree on what is true? Single-machine systems do not have this problem.
        Distributed systems are HARDER, not just slower, because they have a class of failures
        that no single machine ever experiences. This section is about those failures and the
        math that constrains every possible solution.
      </P>

      <H2 num="◇ 01">The fallacies of distributed computing</H2>
      <P>
        In the 1990s, Peter Deutsch and others enumerated the assumptions every distributed
        system developer makes — and which are all wrong. Twenty-five years later, they are
        still the most concise diagnosis of why distributed systems break:
      </P>
      <Code id="fallacies" lang="text">{`1.  The network is reliable.             — Cables get cut. Switches fail. Cloud providers
                                            have outages. Plan for it.

2.  Latency is zero.                     — Even within a datacenter, round trips are 0.5ms.
                                            Across regions, 100-300ms. To space, seconds.

3.  Bandwidth is infinite.               — Even fast links saturate under load. Backpressure
                                            and queueing happen.

4.  The network is secure.               — Default to mutual TLS. The "trusted internal
                                            network" is a fiction.

5.  Topology does not change.            — Nodes come and go. IPs rotate. DNS lies sometimes.

6.  There is one administrator.          — Different teams run different parts. Coordination
                                            is a feature, not a guarantee.

7.  Transport cost is zero.              — Serialization, encryption, copying — they add up
                                            and matter at high throughput.

8.  The network is homogeneous.          — Different links, different MTUs, different
                                            latencies. The slowest hop dominates.`}</Code>
      <P>
        These are not abstract. Every production outage post-mortem you read traces back to one
        or more of these assumptions being violated. The fallacies define the threat model.
      </P>

      <H2 num="◇ 02">Partial failure — the foundational difference</H2>
      <P>
        On a single machine, failures are atomic: either everything works or the process crashes
        and nothing works. There is no "the database wrote but the function did not return."
        On a distributed system, EVERY operation has a third outcome:
      </P>
      <Code id="partial-failure" lang="text">{`SINGLE MACHINE:
   call f()  ───► { f returns successfully  |  process crashes  }

DISTRIBUTED SYSTEM:
   call f() over network  ───► { f returns successfully    (you know)
                                  f returns an error        (you know)
                                  TIMEOUT — no response     (you do NOT know
                                                              if f ran or not)
                                }`}</Code>
      <P>
        The third outcome — TIMEOUT — is the source of more than half of all distributed bugs.
        Did the request reach the other server? Did it complete? Did the response get lost on
        the way back? You cannot tell from the client side. The standard mistake is to treat
        timeouts as failures and retry — except the original request might have succeeded, so
        the retry is a duplicate. (Atlas 19 §02 on idempotency was the warmup for this.)
      </P>
      <Callout kind="warn" title="EVERY NETWORK CALL CAN BE A DUPLICATE">
        If a request can time out, every retry can be a duplicate. Every operation that crosses
        a network boundary needs to handle duplicate delivery — either by being naturally idempotent
        (PUT semantics, deterministic IDs), or by using idempotency keys. This is non-optional.
        Without it, your system silently double-charges, double-ships, double-emails — quietly,
        in production, only on the slow days.
      </Callout>

      <H2 num="◇ 03">The two generals problem</H2>
      <P>
        Two armies camp on hills on either side of a valley. The enemy is in the valley. The
        armies can only win by attacking simultaneously. They communicate by sending messengers
        through the valley — but messengers can be captured. How do the generals coordinate the
        attack time?
      </P>
      <Code id="two-generals" lang="text">{`General A → "Attack at dawn"        General B
                ── messenger 1 ──►   (received? message captured? — A does not know)

                                     B → "Confirmed. Dawn."
                ◄── messenger 2 ──   (received? — B does not know)

                A → "Acknowledged."
                ── messenger 3 ──►   (received? — A does not know)

                                     B → "Ack ack."
                ◄── messenger 4 ──   ...

The problem: no FINITE number of messages establishes mutual certainty.
Each new message requires its own acknowledgment, and each acknowledgment
requires its own. Mathematically: impossible to guarantee both generals
attack together if messengers can be lost.`}</Code>
      <P>
        This is not a puzzle with a clever answer. It was proven impossible. The implication for
        real systems: you cannot guarantee both sides of a distributed transaction commit
        atomically using ONLY message passing over an unreliable network. You can get arbitrarily
        close to certain — but not absolutely certain.
      </P>
      <P>
        The escape from two generals is to add an assumption: bounded delivery times, or
        bounded failure detection. Real protocols (TCP, Paxos, Raft) work because they assume
        messages will eventually be delivered or eventually be classified as lost — and they
        retry until consensus. They do not solve two generals; they trade absolute certainty
        for practical certainty given timeouts.
      </P>

      <H2 num="◇ 04">FLP impossibility — what no protocol can do</H2>
      <Callout kind="system" title="THE FLP RESULT (FISCHER, LYNCH, PATERSON, 1985)">
        In a fully asynchronous network (no upper bound on message delivery time) with even one
        crash-prone node, no deterministic consensus protocol can guarantee ALL of: safety
        (everyone agrees on the same value), liveness (the protocol eventually terminates), and
        fault tolerance (it works even when nodes fail). Pick any two — one must be sacrificed.
        Real protocols sacrifice strict liveness: under pathological message delays, Paxos and
        Raft can hang. In practice they make progress because real networks are not adversarial.
      </Callout>
      <P>
        Translation: every consensus protocol you will ever use has a corner case where it
        cannot make progress. In normal operation, it terminates quickly. Under adversarial
        conditions (a network partition that flickers in just the wrong way), it might not.
        This is fundamental. There is no protocol that escapes it.
      </P>

      <H2 num="◇ 05">Quorum — the practical way out</H2>
      <P>
        Even when nodes cannot all agree, MAJORITY can. If you require every decision to be
        acknowledged by a majority of nodes, and every read to consult a majority, then any two
        majorities must share at least one node. That shared node is the source of truth: the
        read-majority will see the latest write-majority&apos;s result.
      </P>
      <Code id="quorum-math" lang="text">{`Cluster of N nodes:
  quorum threshold = ⌊ N / 2 ⌋ + 1

  N = 3   →   quorum = 2   (tolerates 1 failure)
  N = 5   →   quorum = 3   (tolerates 2 failures)
  N = 7   →   quorum = 4   (tolerates 3 failures)
  N = 4   →   quorum = 3   (tolerates 1 failure — same as N=3, more cost!)
  N = 6   →   quorum = 4   (tolerates 2 failures — same as N=5, more cost!)

THE LESSON: odd-numbered clusters are strictly better than the next even
number up. N=5 and N=6 tolerate the same number of failures, but N=6 has
to coordinate one more machine for every decision. Real clusters are
almost always N=3, N=5, or N=7.`}</Code>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 06">See partitions and their consequences</H2>
      <P>
        Four scenarios on a 5-node cluster. Watch which side has quorum, what writes can happen,
        and what happens when no side does. The healthy state is the baseline. The 3-2 split is
        the textbook partition. The single-isolated node is the most common real-world failure.
        The multi-partition case is the rare disaster.
      </P>

      <NetworkPartitionSimulator />

      <H2 num="◇ 07">Common failure modes</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-violet-300">Crash failure (fail-stop).</strong> Node dies cleanly. The simplest failure model — easy to detect (no heartbeats) and reason about. Most consensus protocols assume crash failures.
        </li>
        <li>
          <strong className="text-violet-300">Crash-recovery.</strong> Node dies, restarts, possibly with stale state. Protocols must handle re-joining nodes that might have voted for something they no longer remember.
        </li>
        <li>
          <strong className="text-violet-300">Omission failure.</strong> Node drops some messages but not others. Looks healthy in heartbeats but data goes missing.
        </li>
        <li>
          <strong className="text-violet-300">Timing failure.</strong> Node is slow, not crashed. Heartbeats arrive late; quorum protocols falsely conclude the node is dead and elect a new leader — then the old one wakes up and there are two leaders briefly. (Cause of many real outages.)
        </li>
        <li>
          <strong className="text-violet-300">Byzantine failure.</strong> Node sends arbitrary, possibly malicious messages. The threat model for blockchain consensus. Most internal systems assume non-Byzantine; if you do not trust your own nodes, you have bigger problems.
        </li>
        <li>
          <strong className="text-rose-400">The grey failure.</strong> Worst kind: a node that mostly works but is degraded in some subtle way (50% packet loss; 10x normal latency; CPU pinned). Heartbeats pass; leader election does not happen; everything is slow but technically "working." Hardest to detect; most painful to debug.
        </li>
      </ul>

      <H2 num="◇ 08">Mitigations — what actually helps</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-cyan-400">Timeouts everywhere, sized to actual latency.</strong> Every network call has a deadline. Default to short timeouts for fast operations; extend deliberately for known-slow ones. No timeout = hang forever = cascading failure.
        </li>
        <li>
          <strong className="text-cyan-400">Retries with exponential backoff and jitter.</strong> Retry on transient failures, but not immediately, and not all at once. Jitter (randomized backoff) prevents thundering-herd retries from synchronizing.
        </li>
        <li>
          <strong className="text-cyan-400">Circuit breakers.</strong> After N consecutive failures to a downstream service, stop calling it for a window. Better to fast-fail than to pile up timed-out requests holding connections.
        </li>
        <li>
          <strong className="text-cyan-400">Bulkheads.</strong> Isolate resources per-dependency: separate thread pools, separate connection pools. A slow downstream cannot starve the rest of your service of resources.
        </li>
        <li>
          <strong className="text-cyan-400">Health checks that actually check health.</strong> A heartbeat that just returns 200 OK is useless against grey failures. Real health checks call key downstreams, verify recent successful work, and have a freshness threshold.
        </li>
        <li>
          <strong className="text-cyan-400">Idempotency keys on every write that crosses the network.</strong> See Atlas 19 §02. The single highest-leverage practice in distributed systems.
        </li>
      </ul>

      <H2 num="◇ 09">Hardening checklist for distributed services</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Every network call has an explicit timeout (no infinite defaults)</li>
        <li>✓ Retries use exponential backoff with jitter (not naked retry loops)</li>
        <li>✓ Circuit breakers in place for every downstream service</li>
        <li>✓ Bulkheads (per-dependency thread/connection pools) isolate failure</li>
        <li>✓ Health checks verify dependencies, not just process liveness</li>
        <li>✓ Every state-changing API takes an idempotency key</li>
        <li>✓ Clusters configured for odd numbers (3, 5, 7) — never even</li>
        <li>✓ Failure injection tested in staging (Chaos Monkey or equivalent)</li>
        <li>✓ Alerting tuned to detect grey failures (latency percentiles, success rates), not just process-down</li>
        <li>✓ Runbooks exist for partition scenarios — written down before the incident, not during</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Section 02 turns the abstract "we need majority agreement" into a concrete protocol:
        Raft. We walk through leader election, log replication, and the safety properties that
        make Raft the consensus algorithm most modern systems actually use.
      </Callout>
    </>
  );
}
