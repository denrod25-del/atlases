/* Section 02 — Consensus and Raft.
 *
 * Prose + Raft Election Simulator.
 *
 * The simulator: three pre-scripted election scenarios played back step
 * by step. Each step advances time, updates node states, and adds a
 * line to the event log. Students see the protocol behavior they would
 * have to simulate in their head otherwise.
 *
 *   1. Normal election    — leader crashes, one follower times out
 *                            first, wins majority, becomes leader
 *   2. Split vote         — two candidates start elections simultaneously,
 *                            split the vote, both step down, retry with
 *                            new randomized timeouts
 *   3. Partition          — network split during election; minority side
 *                            cannot elect a leader, majority side does
 *
 * The pre-scripted approach keeps the lesson clear: students see the
 * canonical protocol behavior without being able to "break" Raft by
 * choosing impossible inputs.
 *
 * All prose strings use backticks (template literals).
 */

import { useState, useEffect, useRef } from 'react';
import { Sparkles, Play, Pause, ChevronRight, RotateCcw, Crown, User, Zap, X } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Scenario definitions
// ───────────────────────────────────────────────────────────────────────

// Initial state — N3 is leader at term 5, all others are followers who voted for it
const INITIAL_NORMAL = [
  { state: 'follower', term: 5, votedFor: 'N3' },
  { state: 'follower', term: 5, votedFor: 'N3' },
  { state: 'leader',   term: 5, votedFor: null },
  { state: 'follower', term: 5, votedFor: 'N3' },
  { state: 'follower', term: 5, votedFor: 'N3' },
];

// Events are applied in order. Each event has a text description and a
// list of mutations (node-state changes) to apply at that step.
const SCENARIOS = [
  {
    id: 'normal',
    label: 'Normal election',
    description: `Leader N3 crashes. After randomized timeouts, follower N1 fires first, becomes a candidate, requests votes for term 6. The other three live nodes grant their votes; N1 has 4 of 5 — majority — and becomes leader. Total time to recovery: ~half a second.`,
    initial: INITIAL_NORMAL,
    events: [
      { text: `N3 is the current leader (term 5). It sends heartbeats every 100ms.` },
      { text: `Heartbeat: N3 → all followers (term 5). Followers reset their election timers.` },
      { text: `⚠ N3 crashes. No more heartbeats will come.`, mutations: [[2, { state: 'crashed' }]] },
      { text: `Followers wait for heartbeats. Each has a random election timeout (200-400ms).` },
      { text: `N1's election timer expires first (220ms). N1 transitions: Follower → Candidate.` },
      { text: `N1 increments term: 5 → 6. Votes for itself.`, mutations: [[0, { state: 'candidate', term: 6, votedFor: 'N1' }]] },
      { text: `N1 sends RequestVote(term=6, candidate=N1) to N2, N4, N5.` },
      { text: `N2 receives RequestVote. Its term is 5; the candidate's term 6 is higher → update term and vote.`, mutations: [[1, { term: 6, votedFor: 'N1' }]] },
      { text: `N4 receives RequestVote. Same logic — votes for N1.`, mutations: [[3, { term: 6, votedFor: 'N1' }]] },
      { text: `N5 receives RequestVote. Same logic — votes for N1.`, mutations: [[4, { term: 6, votedFor: 'N1' }]] },
      { text: `N1 now has 4 votes (self + N2 + N4 + N5) > ⌊5/2⌋ → wins election.` },
      { text: `N1 transitions: Candidate → Leader (term 6). Starts sending heartbeats.`, mutations: [[0, { state: 'leader', votedFor: null }]] },
      { text: `✓ Cluster has a new leader. Total recovery time: ~250ms.` },
    ],
  },
  {
    id: 'split-vote',
    label: 'Split vote',
    description: `Leader N3 crashes. Two followers (N1 and N5) happen to time out at nearly the same moment. Both become candidates for term 6. Each gets two votes — but neither gets majority. Both step down, wait randomized timeouts again, retry. The second round succeeds.`,
    initial: INITIAL_NORMAL,
    events: [
      { text: `N3 is leader (term 5). Heartbeats flowing normally.` },
      { text: `⚠ N3 crashes.`, mutations: [[2, { state: 'crashed' }]] },
      { text: `N1's election timer expires (215ms). N1 → Candidate, term=6, votes for self.`,
        mutations: [[0, { state: 'candidate', term: 6, votedFor: 'N1' }]] },
      { text: `Almost simultaneously, N5's timer expires (218ms). N5 → Candidate, term=6, votes for self.`,
        mutations: [[4, { state: 'candidate', term: 6, votedFor: 'N5' }]] },
      { text: `N1 sends RequestVote(term=6) to N2, N4, N5. N5 sends RequestVote(term=6) to N1, N2, N4.` },
      { text: `N2 receives N1's request first. Has not voted in term 6 → grants vote to N1.`,
        mutations: [[1, { term: 6, votedFor: 'N1' }]] },
      { text: `N4 receives N5's request first. Has not voted in term 6 → grants vote to N5.`,
        mutations: [[3, { term: 6, votedFor: 'N5' }]] },
      { text: `N2 receives N5's request. Already voted in term 6 → REJECTED.` },
      { text: `N4 receives N1's request. Already voted in term 6 → REJECTED.` },
      { text: `N1 has 2 votes (self + N2). N5 has 2 votes (self + N4). Neither has majority (3). SPLIT VOTE.` },
      { text: `Both candidates wait for next election timeout (new random value).` },
      { text: `N2's timer expires first this time (185ms after split detected). N2 → Candidate, term=7.`,
        mutations: [
          [0, { state: 'follower', votedFor: null }],
          [4, { state: 'follower', votedFor: null }],
          [1, { state: 'candidate', term: 7, votedFor: 'N2' }],
        ] },
      { text: `N2 sends RequestVote(term=7). All others (term 6) update to term 7 and vote yes.`,
        mutations: [
          [0, { term: 7, votedFor: 'N2' }],
          [3, { term: 7, votedFor: 'N2' }],
          [4, { term: 7, votedFor: 'N2' }],
        ] },
      { text: `N2 has 4 votes → wins. Transitions to Leader.`,
        mutations: [[1, { state: 'leader', votedFor: null }]] },
      { text: `✓ Recovery took two rounds due to split vote. Randomized timeouts make this rare.` },
    ],
  },
  {
    id: 'partition',
    label: 'Network partition',
    description: `Leader N3 crashes. Then a network partition isolates N4 and N5 from the rest. The 3-node side ({N1, N2, N3-crashed}) has only 2 live nodes — below quorum. The 2-node side cannot elect either. The cluster is STUCK until either side gets 3 live nodes reachable.`,
    initial: INITIAL_NORMAL,
    events: [
      { text: `N3 is leader (term 5).` },
      { text: `⚠ N3 crashes.`, mutations: [[2, { state: 'crashed' }]] },
      { text: `⚠ Network partition: {N1, N2, N3} cannot reach {N4, N5}.` },
      { text: `N1's election timer expires (220ms). N1 → Candidate, term=6, votes for self.`,
        mutations: [[0, { state: 'candidate', term: 6, votedFor: 'N1' }]] },
      { text: `N1 sends RequestVote to N2 (reachable), to N3 (crashed — no response), to N4 (partitioned — no response), to N5 (partitioned — no response).` },
      { text: `N2 responds — grants vote.`, mutations: [[1, { term: 6, votedFor: 'N1' }]] },
      { text: `N1 has 2 votes (self + N2). Needs 3. NOT enough. Election fails.` },
      { text: `Meanwhile on the other side: N5's election timer expires. N5 → Candidate, term=6.`,
        mutations: [[4, { state: 'candidate', term: 6, votedFor: 'N5' }]] },
      { text: `N5 sends RequestVote to N4 (reachable), others unreachable.` },
      { text: `N4 grants vote.`, mutations: [[3, { term: 6, votedFor: 'N5' }]] },
      { text: `N5 has 2 votes. Needs 3. NOT enough. Election fails.` },
      { text: `Both sides loop: timeout → election → fail → timeout → election → fail. NO leader.` },
      { text: `⚠ CLUSTER STUCK. No writes accepted anywhere. State persists until partition heals OR additional node comes back online.` },
    ],
  },
];

// ───────────────────────────────────────────────────────────────────────
// Simulator UI
// ───────────────────────────────────────────────────────────────────────

const STATE_COLORS = {
  follower:  { bg: 'bg-zinc-800',         border: 'border-zinc-600',     text: 'text-zinc-200',   icon: User,  label: 'follower' },
  candidate: { bg: 'bg-amber-400/15',     border: 'border-amber-400',    text: 'text-amber-200',  icon: Zap,   label: 'candidate' },
  leader:    { bg: 'bg-violet-300/15',    border: 'border-violet-300',   text: 'text-violet-100', icon: Crown, label: 'leader' },
  crashed:   { bg: 'bg-rose-400/10',      border: 'border-rose-400/60',  text: 'text-rose-300',   icon: X,     label: 'crashed' },
};

function applyMutations(nodes, mutations) {
  if (!mutations) return nodes;
  const next = nodes.map(n => ({ ...n }));
  mutations.forEach(([idx, patch]) => {
    next[idx] = { ...next[idx], ...patch };
  });
  return next;
}

// Replay the scenario from step 0 up to (and including) targetStep.
// Returns the node state at that point.
function replayTo(scenario, targetStep) {
  let nodes = scenario.initial.map(n => ({ ...n }));
  for (let i = 0; i <= targetStep && i < scenario.events.length; i++) {
    nodes = applyMutations(nodes, scenario.events[i].mutations);
  }
  return nodes;
}

function RaftElectionSimulator() {
  const [scenarioIdx, setScenarioIdx] = useState(0);
  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(false);
  const intervalRef = useRef(null);

  const scenario = SCENARIOS[scenarioIdx];
  const currentNodes = replayTo(scenario, step);
  const visibleEvents = scenario.events.slice(0, step + 1);
  const atEnd = step >= scenario.events.length - 1;

  // Auto-play
  useEffect(() => {
    if (!playing) return;
    intervalRef.current = setInterval(() => {
      setStep(s => {
        if (s >= scenario.events.length - 1) {
          setPlaying(false);
          return s;
        }
        return s + 1;
      });
    }, 1400);
    return () => clearInterval(intervalRef.current);
  }, [playing, scenario]);

  const switchScenario = (i) => {
    setPlaying(false);
    setScenarioIdx(i);
    setStep(0);
  };

  const advance = () => {
    if (atEnd) return;
    setStep(s => s + 1);
  };

  const reset = () => {
    setPlaying(false);
    setStep(0);
  };

  return (
    <div className="my-6 border border-violet-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-violet-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-violet-300" />
          <span className="text-violet-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · raft election simulator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => switchScenario(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === scenarioIdx
                  ? 'border-violet-300 bg-violet-300/15 text-violet-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-violet-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {i + 1}. {s.label}
            </button>
          ))}
        </div>

        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13px] leading-relaxed italic">
          {scenario.description}
        </div>

        {/* Node grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 mb-4">
          {currentNodes.map((n, i) => {
            const cfg = STATE_COLORS[n.state] || STATE_COLORS.follower;
            const Icon = cfg.icon;
            return (
              <div key={i} className={`border ${cfg.border} ${cfg.bg} p-2.5 transition-colors`}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="text-zinc-100 text-[14px] font-bold"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    N{i + 1}
                  </div>
                  <Icon size={13} className={cfg.text} />
                </div>
                <div className={`text-[9.5px] tracking-[0.2em] uppercase font-semibold ${cfg.text} mb-1.5`}
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {cfg.label}
                </div>
                <div className="text-[10.5px] text-zinc-400 leading-snug"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  <div>term: <span className="text-zinc-200">{n.term}</span></div>
                  <div>voted: <span className="text-zinc-200">{n.votedFor || '—'}</span></div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <button onClick={() => setPlaying(p => !p)} disabled={atEnd && !playing}
            className="px-3 py-1.5 border border-violet-300 bg-violet-300/10 text-violet-200 hover:bg-violet-300/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-[11.5px] font-semibold flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            {playing ? <><Pause size={11} /> pause</> : <><Play size={11} /> play</>}
          </button>
          <button onClick={advance} disabled={atEnd || playing}
            className="px-3 py-1.5 border border-cyan-400 bg-cyan-400/10 text-cyan-200 hover:bg-cyan-400/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-[11.5px] font-semibold flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <ChevronRight size={11} /> step
          </button>
          <button onClick={reset}
            className="px-3 py-1.5 border border-zinc-700 text-zinc-400 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[11px] flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <RotateCcw size={11} /> reset
          </button>
          <div className="ml-auto text-zinc-500 text-[10.5px]"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            step {step + 1} / {scenario.events.length}
          </div>
        </div>

        {/* Event log */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-3 max-h-72 overflow-y-auto">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            event log
          </div>
          {visibleEvents.length === 0 ? (
            <div className="text-zinc-600 text-[12px] italic">Click play or step to begin.</div>
          ) : (
            <div className="space-y-1">
              {visibleEvents.map((e, i) => {
                const isLatest = i === visibleEvents.length - 1;
                const isWarn = e.text.startsWith('⚠');
                const isOk = e.text.startsWith('✓');
                return (
                  <div key={i} className={`text-[11.5px] flex gap-3 leading-relaxed transition-colors ${
                    isLatest
                      ? (isWarn ? 'text-rose-300' : isOk ? 'text-cyan-300' : 'text-violet-200')
                      : 'text-zinc-500'
                  }`}
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    <span className="text-zinc-600 shrink-0 w-8">{String(i + 1).padStart(2, '0')}</span>
                    <span>{e.text}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section02_Consensus() {
  return (
    <>
      <SectionLabel>section 02</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Consensus — how a cluster agrees on a single truth
      </h2>
      <P>
        Section 01 named the problem: distributed systems need majority agreement to make
        progress, but the math says no protocol can perfectly guarantee both safety and
        liveness under arbitrary network conditions. Real systems work anyway — through
        practical protocols that work in normal conditions and degrade predictably under
        bad ones. The dominant such protocol today is Raft. This section is how it works.
      </P>

      <H2 num="◇ 01">Why Raft (and not Paxos)</H2>
      <P>
        Paxos was the consensus protocol from 1989. Mathematically elegant; widely cited;
        notoriously hard to implement correctly. Several major systems (Google Chubby,
        ZooKeeper&apos;s ZAB) used Paxos variants — and most teams that built on them reported
        that "implementing Paxos correctly" was the hardest part.
      </P>
      <P>
        In 2014, Diego Ongaro and John Ousterhout published Raft with an explicit design goal:
        UNDERSTANDABILITY. The math is equivalent to Paxos; the protocol is decomposed into
        three orthogonal sub-problems (leader election, log replication, safety) that can be
        reasoned about separately. Within a year, etcd, Consul, CockroachDB, and TiKV had all
        adopted Raft. ZooKeeper is now the legacy choice; Raft dominates new builds.
      </P>
      <Callout kind="system" title="THE DESIGN PRINCIPLE THAT WON">
        Raft chose "easy to understand and implement correctly" as a first-class design goal,
        not an afterthought. The result was provably equivalent guarantees with a protocol
        most engineers can hold in their head after one reading. The lesson generalizes:
        when a protocol&apos;s correctness depends on getting many subtle details right,
        UNDERSTANDABILITY is a safety property — not a luxury.
      </Callout>

      <H2 num="◇ 02">The three states</H2>
      <P>
        Every Raft node is in exactly one of three states at any time:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-zinc-200">Follower.</strong> The default state. Listens for heartbeats from a leader. Replicates log entries it receives. Votes for at most one candidate per term. If no heartbeat arrives within the election timeout, transitions to Candidate.
        </li>
        <li>
          <strong className="text-amber-300">Candidate.</strong> Trying to become leader. Increments its term, votes for itself, sends RequestVote RPCs to all other nodes. If it receives votes from a majority → becomes Leader. If it sees a higher term from anyone else → steps back to Follower.
        </li>
        <li>
          <strong className="text-violet-200">Leader.</strong> The single node accepting writes. Sends heartbeats every ~50-150ms to maintain authority. Replicates log entries to followers. There is at most one leader per term — but term numbers monotonically increase, so a stale leader from a previous term can be detected and rejected.
        </li>
      </ul>

      <H2 num="◇ 03">Terms — Raft&apos;s logical clock</H2>
      <P>
        Raft does not use wall clocks for ordering — wall clocks are unreliable across nodes
        (Atlas 21 §03 covers this). Instead, every node tracks the current TERM number. Terms
        are monotonically increasing integers. Each term begins with an election attempt. If
        the election succeeds, that term has a leader; if it fails (split vote, no quorum), the
        next term starts with a new election.
      </P>
      <Code id="terms" lang="text">{`TERM 1 ──┬── leader: N3   (election 1 succeeded)
         │   heartbeats, log replication, normal operation
         │
TERM 2 ──┼── leader: N1   (N3 crashed, N1 won election)
         │   heartbeats, log replication, normal operation
         │
TERM 3 ──┼── leader: ???  (split vote, no winner — term 3 has NO leader)
         │
TERM 4 ──┴── leader: N2   (next election succeeded)

The term number ALWAYS goes up. Every RPC includes the sender's term;
the receiver compares and either:
  - Accepts if sender.term >= receiver.term, possibly updating its own term
  - Rejects if sender.term <  receiver.term (and tells the sender its term is stale)`}</Code>
      <P>
        Terms make stale leaders self-correcting. A leader that gets partitioned, recovers
        later, and tries to keep leading discovers from any peer that its term is now stale —
        and steps down without causing damage.
      </P>

      <H2 num="◇ 04">Leader election — the protocol</H2>
      <Code id="election-protocol" lang="text">{`STEP 1 — A follower's election timer expires (200-400ms random)
   No heartbeat received from the leader in this window.
   The follower assumes the leader is dead.

STEP 2 — Transition to Candidate
   - state := candidate
   - currentTerm += 1
   - votedFor := self
   - reset election timer (new random value)
   - send RequestVote(currentTerm, self) to all other nodes

STEP 3 — Other nodes evaluate the RequestVote
   if RequestVote.term > my.currentTerm:
       update currentTerm := RequestVote.term
       grant vote (votedFor := candidate)
   else if RequestVote.term == my.currentTerm and votedFor in (null, candidate):
       grant vote
   else:
       reject (already voted in this term, or sender's term is stale)

STEP 4 — Candidate counts votes
   if votes received >= ⌊N/2⌋ + 1:
       state := leader
       start sending heartbeats immediately
   else if receives RPC with term > currentTerm:
       state := follower
       update currentTerm := other.term
   else if election timer expires:
       start a new election (back to step 2, term += 1)`}</Code>

      <H2 num="◇ 05">Election timeouts — randomization is the trick</H2>
      <P>
        The detail that makes Raft robust: election timeouts are RANDOMIZED per node, typically
        in the range 150-300ms (or 200-400ms in production tunings). Without randomization, all
        followers would time out simultaneously when the leader dies, all become candidates at
        once, all split the vote, and the cluster would never elect a new leader.
      </P>
      <P>
        With randomization, one follower&apos;s timer almost always expires meaningfully before
        the others. It becomes a candidate first, sends RequestVotes, and wins votes from peers
        who have not yet timed out. The election succeeds in one round. Split votes still
        happen occasionally — see scenario 2 of the simulator — but they self-resolve quickly
        because the next round&apos;s timeouts are also randomized.
      </P>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 06">See an election in action</H2>
      <P>
        Three scripted scenarios. Click play to auto-advance, or step through manually to read
        every event. Watch each node&apos;s state, term, and voted-for as they evolve. The first
        scenario is the textbook case. The second shows split-vote resolution. The third shows
        what happens when no side can muster majority — the cluster is genuinely stuck until
        the partition heals.
      </P>

      <RaftElectionSimulator />

      <H2 num="◇ 07">Log replication — how writes propagate</H2>
      <P>
        After election, the leader accepts client writes and replicates them to followers via
        AppendEntries RPCs. The replicated log is the heart of Raft&apos;s correctness — every
        node maintains an ordered log of operations, and these logs converge as long as a
        majority is reachable.
      </P>
      <Code id="log-replication" lang="text">{`CLIENT SENDS WRITE → LEADER

1. Leader appends the entry to its OWN log (not yet committed)
       log: [term=6, idx=42, cmd="SET balance=150"]

2. Leader sends AppendEntries(term=6, prevIdx=41, prevTerm=6, entries=[42])
   to ALL followers in parallel

3. Each follower:
   - If sender's term is current, AND prev entry matches:
       append the entry to its log → respond OK
   - Otherwise:
       respond REJECTED (leader will retry with earlier entries to find
       the common point and bring follower up to date)

4. Leader counts ACKs.
   When a MAJORITY of followers (including itself) have the entry:
       commit it — apply to state machine, respond to client

5. Heartbeats include the latest commit index → followers commit too`}</Code>
      <P>
        The "log matching property" — if two logs have an entry at the same index with the same
        term, all earlier entries are identical — is what lets the leader bring lagging followers
        back into sync quickly: walk backwards until you find a matching index/term, then
        replicate forward from there.
      </P>

      <H2 num="◇ 08">Safety — the five guarantees</H2>
      <Callout kind="info" title="RAFT'S SAFETY PROPERTIES">
        <strong className="text-violet-200">Election safety:</strong> at most one leader per term.<br />
        <strong className="text-violet-200">Leader append-only:</strong> a leader never deletes or overwrites entries in its own log.<br />
        <strong className="text-violet-200">Log matching:</strong> if two logs agree on an entry at a given index, they agree on all earlier entries.<br />
        <strong className="text-violet-200">Leader completeness:</strong> if a log entry is committed in term T, it is present in the log of every leader of every term &gt; T.<br />
        <strong className="text-violet-200">State machine safety:</strong> if a server applies a log entry at a given index, no other server ever applies a different entry at that index.<br /><br />
        These five properties — taken together — prove that Raft never has two state machines
        diverge. Once committed, an entry persists across every future leader. The protocol&apos;s
        correctness reduces to maintaining these five invariants.
      </Callout>

      <H2 num="◇ 09">Membership changes — adding and removing nodes safely</H2>
      <P>
        Adding or removing a node from a Raft cluster is dangerous done naively — during the
        change, you can briefly have two disjoint majorities (in the old configuration and the
        new one), leading to split brain. Raft handles this with JOINT CONSENSUS: for a window,
        any commit requires majority in BOTH the old and the new configuration. Once both
        configurations have committed the new membership, the cluster is safely transitioned.
      </P>
      <P>
        In production: most teams add/remove nodes one at a time. With single-node changes the
        old majority and new majority always overlap, so joint consensus is not strictly
        necessary — but the protocol supports it for batch changes.
      </P>

      <H2 num="◇ 10">Where Raft runs in production</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-violet-300">etcd</strong> — Kubernetes&apos; control plane storage. Stores cluster state for thousands of K8s clusters worldwide.</li>
        <li><strong className="text-violet-300">Consul</strong> — HashiCorp&apos;s service mesh and KV store. Raft underneath every Consul cluster.</li>
        <li><strong className="text-violet-300">CockroachDB / TiKV / TiDB</strong> — Per-range Raft groups across thousands of ranges in a cluster.</li>
        <li><strong className="text-violet-300">Nomad</strong> — HashiCorp&apos;s scheduler. Raft for state.</li>
        <li><strong className="text-violet-300">RabbitMQ Quorum Queues</strong> — message-queue durability via Raft.</li>
        <li><strong className="text-violet-300">Many internal-only systems</strong> — when teams need consensus, Raft is the default reach.</li>
      </ul>

      <H2 num="◇ 11">Hardening checklist for Raft clusters</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Cluster size 3 or 5 (never even) — tolerates 1 or 2 node failures respectively</li>
        <li>✓ Nodes spread across availability zones — a single-AZ outage cannot kill majority</li>
        <li>✓ Election timeout tuned for actual inter-node latency (~10x typical heartbeat RTT)</li>
        <li>✓ Disk fsync verified on every WAL write — Raft&apos;s safety assumes durable storage</li>
        <li>✓ Leader-step-down on disk write failure — a node that cannot persist cannot lead</li>
        <li>✓ Monitoring: leader stability, election rate, follower lag, commit latency percentiles</li>
        <li>✓ Membership changes scheduled (one node at a time), never during incidents</li>
        <li>✓ Backups distinct from the Raft cluster — replicas replicate corruption; backups do not (carries over from Atlas 20)</li>
        <li>✓ Snapshotting tuned — without periodic snapshots, the log grows unbounded</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Raft gives you a single agreed-upon order. Section 03 covers the harder case: when you
        do NOT want global consensus on order — because consensus is expensive — but still
        need to reason about cause and effect. Vector clocks. Lamport timestamps. The math of
        "happens before" without a central authority.
      </Callout>
    </>
  );
}
