# Distributed Systems — Atlas #21 (B. Symbolic)

Why distributed is hard · Consensus · Vector Clocks · Quorum

Middle of the data-systems arc. Atlas 20 (Databases at Scale) covered
one-machine systems and introduced replication; this atlas pushes into the
protocols and math of multi-machine systems; Atlas 22 will close the
trilogy by changing the question — what if you don't need agreement at all?

Build script uses `node ./node_modules/vite/bin/vite.js build` (Vercel-fix
baked in). `.gitignore` baked in from the first commit. Pre-flight scan
clean (zero `sk_live_`, `sk_test_`, `AKIA*`, `ghp_`, `ghs_` matches).

## Conventions
- Palette: violet-300 primary, cyan-400 accent
- Glyph: ⬢
- Type: Bricolage Grotesque · JetBrains Mono · Manrope
- Background: zinc-950
- New callout kind: `system` (hexagon icon) for foundational distributed concepts (FLP, the Raft design principle, quorum overlap math)

## Run locally
```
npm install
npm run dev          # http://localhost:5173
```

## Deploy
Push to GitHub. Connect at vercel.com/new. Auto-detects Vite. ~60s to live URL.

## Sections (all complete)

### 01 Why distributed is hard (511 lines)
Fallacies, partial failure, two generals, FLP, quorum math.
**Interactive:** Network Partition Simulator — 5-node pentagon SVG, four scenarios
(healthy, 3-2 split, single-isolated node, multi-partition chaos), shows quorum
analysis and which group can make progress.

### 02 Consensus (552 lines)
Raft vs Paxos, three states, terms, leader election, log replication, the five
safety properties, membership changes. **Interactive:** Raft Election Simulator
— three scripted scenarios (normal election, split vote, network partition) with
play/step/reset controls, 5 node-state cards (Follower/Candidate/Leader/Crashed),
numbered event log with tone-coded most-recent event.

### 03 Vector Clocks (586 lines)
Why wall clocks fail, happens-before, Lamport timestamps, vector clock protocol,
comparison rules, concurrent events, HLCs. **Interactive:** Vector Clock
Visualizer — SVG spacetime diagram with three vertical node timelines, events as
clickable circles, message arrows between sender and receiver, click any two
events to compute causality (before/after/concurrent).

### 04 Quorum (552 lines)
N/W/R model, overlap argument for R+W>N, sloppy quorum, read repair,
anti-entropy via Merkle trees. **Interactive:** Quorum Configuration Explorer —
N selector (3/5/7), W/R steppers, four preset configurations, real-time
analysis panel (consistency guarantee, min overlap, fault tolerance), cluster
visualization with "Sample read & write" button showing overlap.

Atlas closes with the middle-of-arc framing: Atlas 20 / 21 / 22 trilogy with
the one-line summary for each.

## Series
- Atlas 17-19 — API series (Foundations · Security · Production)
- Atlas 20 — Databases at Scale (opens data-systems arc)
- **Atlas 21 — Distributed Systems (this one) — middle of data-systems arc**
- Atlas 22 — Event-Driven Architecture (planned)

## Push checklist
1. `git init && git add . && git commit -m "Atlas 21 — Distributed Systems"`
2. Create repo on github.com (suggested: `dist-atlas` under `denrod25-del`)
3. `git remote add origin git@github.com:denrod25-del/dist-atlas.git`
4. `git push -u origin main`
5. Connect at vercel.com/new → import the repo → deploy
