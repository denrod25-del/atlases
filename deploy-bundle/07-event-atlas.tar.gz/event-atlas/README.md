# Event-Driven Architecture — Atlas #22 (B. Symbolic)

Queues vs Streams · Delivery Semantics · Log Compaction · Outbox & Sagas

**Closes the data-systems arc.** Atlas 20 covered single-machine data systems
and introduced replication. Atlas 21 covered the protocols and math of
multi-machine systems. This atlas takes the sideways move — what if you don't
NEED agreement? — and tackles the patterns that real teams ship: queues vs
streams, the exactly-once-ish reality, log compaction + event sourcing, and the
outbox pattern that fixes the dual-write bug everyone hits sooner or later.

Build script uses `node ./node_modules/vite/bin/vite.js build` (Vercel-fix
baked in). `.gitignore` baked in from first commit. Pre-flight secret scan clean.

## Conventions
- Palette: fuchsia-300 primary, lime-400 accent
- Glyph: ≋ (three wavy lines — stream/flow)
- Type: Bricolage Grotesque · JetBrains Mono · Manrope
- New callout kind: `stream` (Waves icon) for event-flow concepts

## Sections (all complete)

### 01 Queues vs Streams (549 lines)
The fundamental distinction, consumer groups, partitioning, hybrid systems.
**Interactive:** Queue/Stream Visualizer — two modes (queue work distribution
with disappearing events vs stream event log with per-consumer offsets and
replay).

### 02 Delivery Semantics (621 lines)
The three semantic levels, why exactly-once is impossible across systems,
Kafka EOS internals, the idempotent consumer pattern.
**Interactive:** Delivery Semantics Simulator — 3 scenarios × 3 semantics =
9 distinct timelines showing same failure, different outcomes.

### 03 Log Compaction (503 lines)
Why streams grow forever, time-based vs key-based retention, tombstones, event
sourcing, snapshots, CQRS. **Interactive:** Log Compaction Visualizer — add
keyed events, watch obsolete ones get struck through, click compact, see
latest-per-key survive.

### 04 Outbox & Sagas (684 lines)
The dual-write fix, outbox + relay worker pattern, CDC alternative,
choreography vs orchestration, compensating transactions, operational
realities (backpressure, DLQs, lag, schema evolution).
**Interactive:** Outbox Pattern Simulator — 3 scenarios × 2 approaches showing
that no ordering fixes dual-write but the outbox does.

Atlas closes with:
- "What you can do now" recap
- The data-systems arc trilogy summary (Atlas 20-21-22)
- "What you can build with all three" win callout
- Preview of the operations arc (Atlas 23-25: Observability / Reliability / Incident Response)

## Run locally
```
npm install
npm run dev          # http://localhost:5173
```

## Series
- Atlas 17-19 — API series (Foundations · Security · Production)
- Atlas 20-22 — Data-systems arc (Databases · Distributed · **Event-Driven this one — arc complete**)
- Atlas 23-25 — Operations arc (planned: Observability · Reliability · Incident Response)

## Push checklist
1. `git init && git add . && git commit -m "Atlas 22 — Event-Driven Architecture"`
2. Create repo on github.com (suggested: `event-atlas` under `denrod25-del`)
3. `git remote add origin git@github.com:denrod25-del/event-atlas.git`
4. `git push -u origin main`
5. Connect at vercel.com/new → import the repo → deploy
