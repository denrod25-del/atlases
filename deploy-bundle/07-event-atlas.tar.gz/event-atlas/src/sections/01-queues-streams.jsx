/* Section 01 — Queues vs Streams.
 *
 * Prose + Queue-vs-Stream Visualizer.
 *
 * The simulator: two modes tabs (queue / stream), one producer, multiple
 * consumers. The student can click "Produce event" and per-consumer "Read"
 * buttons to see how events flow:
 *
 *   QUEUE mode  — 2 consumers compete; each event goes to exactly ONE;
 *                 events DISAPPEAR after consumption
 *   STREAM mode — 3 consumers each have their own offset; ALL of them
 *                 see EVERY event; events stay in the log; consumers can
 *                 reset to replay
 *
 * The lesson: queues distribute work, streams broadcast events. Same
 * producer + same events; opposite semantics. Choosing one when you need
 * the other is the #1 architecture mistake in event-driven systems.
 *
 * All prose strings use backticks (template literals).
 */

import { useState, useRef } from 'react';
import { Sparkles, Send, Inbox, ArrowRight, RotateCcw, Trash2, Layers, Eye } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Queue vs Stream Visualizer
// ───────────────────────────────────────────────────────────────────────

const QUEUE_CONSUMERS = ['Worker-A', 'Worker-B'];
const STREAM_CONSUMERS = ['Analytics', 'Notifier', 'Audit'];

function QueueMode() {
  const [pending, setPending] = useState([]);   // events in queue
  const [counter, setCounter] = useState(1);    // next event id
  const [consumed, setConsumed] = useState({ 'Worker-A': [], 'Worker-B': [] });
  const [nextConsumer, setNextConsumer] = useState(0);  // round-robin pointer (visual hint only)

  const produce = () => {
    const evt = { id: `e${counter}`, payload: `event ${counter}` };
    setPending(prev => [...prev, evt]);
    setCounter(c => c + 1);
  };

  const consume = (workerIdx) => {
    if (pending.length === 0) return;
    const worker = QUEUE_CONSUMERS[workerIdx];
    const [head, ...rest] = pending;
    setPending(rest);
    setConsumed(prev => ({ ...prev, [worker]: [...prev[worker], head] }));
    setNextConsumer((workerIdx + 1) % 2);
  };

  const reset = () => {
    setPending([]);
    setConsumed({ 'Worker-A': [], 'Worker-B': [] });
    setCounter(1);
    setNextConsumer(0);
  };

  return (
    <div className="space-y-3">
      {/* Producer + queue */}
      <div className="border border-zinc-800 bg-zinc-950/60 p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="text-fuchsia-300 text-[10px] tracking-[0.25em] uppercase flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Send size={11} /> producer → queue (FIFO)
          </div>
          <button onClick={produce}
            className="px-2.5 py-1 border border-fuchsia-300 bg-fuchsia-300/10 text-fuchsia-200 hover:bg-fuchsia-300/20 transition-colors text-[10.5px] font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            + produce event
          </button>
        </div>

        {/* Queue visualization */}
        <div className="min-h-[60px] bg-zinc-900 border border-zinc-800 p-2 flex items-center gap-2 overflow-x-auto">
          {pending.length === 0 ? (
            <span className="text-zinc-600 text-[11px] italic"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              queue empty — click "produce event"
            </span>
          ) : (
            pending.map((e, i) => (
              <div key={e.id}
                className={`shrink-0 px-2 py-1.5 border border-fuchsia-300/60 bg-fuchsia-300/15 text-fuchsia-100 text-[10.5px] font-bold ${i === 0 ? 'ring-2 ring-fuchsia-300/40' : ''}`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {e.id}
                {i === 0 && <span className="ml-1 text-fuchsia-300 text-[8.5px]">next →</span>}
              </div>
            ))
          )}
        </div>
        <div className="text-zinc-500 text-[10px] mt-1.5"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          {pending.length} pending · oldest dequeued first
        </div>
      </div>

      {/* Consumers */}
      <div className="grid grid-cols-2 gap-2">
        {QUEUE_CONSUMERS.map((w, i) => {
          const items = consumed[w];
          const isNext = nextConsumer === i;
          return (
            <div key={w} className={`border ${isNext ? 'border-lime-400/60' : 'border-zinc-700'} bg-zinc-900/40 p-3`}>
              <div className="flex items-center justify-between mb-2">
                <div className={`text-[10px] tracking-[0.25em] uppercase font-semibold flex items-center gap-1.5 ${isNext ? 'text-lime-400' : 'text-zinc-400'}`}
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  <Inbox size={11} /> {w}
                </div>
                <button onClick={() => consume(i)} disabled={pending.length === 0}
                  className="px-2 py-1 border border-zinc-600 text-zinc-300 hover:border-fuchsia-300/50 hover:text-zinc-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-[10px]"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  read next
                </button>
              </div>
              <div className="min-h-[40px] flex flex-wrap gap-1">
                {items.length === 0 ? (
                  <span className="text-zinc-600 text-[10.5px] italic"
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    no events consumed yet
                  </span>
                ) : (
                  items.map(e => (
                    <span key={e.id} className="px-1.5 py-0.5 border border-zinc-700 bg-zinc-950 text-zinc-300 text-[10px]"
                      style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                      {e.id}
                    </span>
                  ))
                )}
              </div>
              <div className="text-zinc-500 text-[10px] mt-1.5"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                processed: {items.length}
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex justify-between items-center pt-1">
        <div className="text-zinc-500 text-[10.5px] italic"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          Each event goes to exactly one worker. After consumption, the event is GONE.
        </div>
        <button onClick={reset}
          className="px-2.5 py-1 border border-zinc-700 text-zinc-500 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[10.5px] flex items-center gap-1.5"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          <RotateCcw size={10} /> reset
        </button>
      </div>
    </div>
  );
}

function StreamMode() {
  const [log, setLog] = useState([]);
  const [counter, setCounter] = useState(1);
  const [offsets, setOffsets] = useState({ 'Analytics': 0, 'Notifier': 0, 'Audit': 0 });

  const produce = () => {
    const evt = { id: `e${counter}`, payload: `event ${counter}` };
    setLog(prev => [...prev, evt]);
    setCounter(c => c + 1);
  };

  const advance = (consumer) => {
    setOffsets(prev => {
      if (prev[consumer] >= log.length) return prev;
      return { ...prev, [consumer]: prev[consumer] + 1 };
    });
  };

  const resetOffset = (consumer) => {
    setOffsets(prev => ({ ...prev, [consumer]: 0 }));
  };

  const reset = () => {
    setLog([]);
    setCounter(1);
    setOffsets({ 'Analytics': 0, 'Notifier': 0, 'Audit': 0 });
  };

  return (
    <div className="space-y-3">
      {/* Producer + log */}
      <div className="border border-zinc-800 bg-zinc-950/60 p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="text-fuchsia-300 text-[10px] tracking-[0.25em] uppercase flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Layers size={11} /> producer → append-only log
          </div>
          <button onClick={produce}
            className="px-2.5 py-1 border border-fuchsia-300 bg-fuchsia-300/10 text-fuchsia-200 hover:bg-fuchsia-300/20 transition-colors text-[10.5px] font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            + produce event
          </button>
        </div>

        <div className="min-h-[60px] bg-zinc-900 border border-zinc-800 p-2 flex items-center gap-2 overflow-x-auto relative">
          {log.length === 0 ? (
            <span className="text-zinc-600 text-[11px] italic"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              log empty — click "produce event"
            </span>
          ) : (
            log.map((e, i) => (
              <div key={e.id} className="shrink-0 px-2 py-1.5 border border-fuchsia-300/60 bg-fuchsia-300/15 text-fuchsia-100 text-[10.5px] font-bold"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <div>{e.id}</div>
                <div className="text-zinc-500 text-[8.5px] font-normal">off={i}</div>
              </div>
            ))
          )}
        </div>
        <div className="text-zinc-500 text-[10px] mt-1.5"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          {log.length} entries · events stay forever (subject to retention)
        </div>
      </div>

      {/* Consumers */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {STREAM_CONSUMERS.map(c => {
          const off = offsets[c];
          const atHead = off >= log.length;
          const lagging = log.length - off;
          return (
            <div key={c} className="border border-zinc-700 bg-zinc-900/40 p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="text-zinc-300 text-[10px] tracking-[0.25em] uppercase font-semibold flex items-center gap-1.5"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  <Eye size={11} /> {c}
                </div>
              </div>
              <div className="text-zinc-200 text-[11px] mb-2 leading-snug"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <div>offset: <span className="text-fuchsia-300 font-bold">{off}</span> / {log.length}</div>
                <div className="text-zinc-500">
                  {atHead ? '✓ caught up' : `lag: ${lagging} event${lagging === 1 ? '' : 's'}`}
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <button onClick={() => advance(c)} disabled={atHead}
                  className="px-2 py-1 border border-lime-400/60 bg-lime-400/10 text-lime-200 hover:bg-lime-400/20 disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-[10px] flex items-center justify-center gap-1"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  <ArrowRight size={10} /> read next
                </button>
                <button onClick={() => resetOffset(c)}
                  className="px-2 py-1 border border-zinc-700 text-zinc-500 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[10px] flex items-center justify-center gap-1"
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  <RotateCcw size={10} /> replay (off=0)
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex justify-between items-center pt-1">
        <div className="text-zinc-500 text-[10.5px] italic max-w-[70%]"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          All three consumers see every event. Each tracks its own offset. Replay = reset offset.
        </div>
        <button onClick={reset}
          className="px-2.5 py-1 border border-zinc-700 text-zinc-500 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[10.5px] flex items-center gap-1.5"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          <Trash2 size={10} /> clear log
        </button>
      </div>
    </div>
  );
}

function QueueStreamVisualizer() {
  const [mode, setMode] = useState('queue');

  return (
    <div className="my-6 border border-fuchsia-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-fuchsia-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-fuchsia-300" />
          <span className="text-fuchsia-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · queue vs stream visualizer
          </span>
        </div>
      </div>

      <div className="p-4">
        <div className="flex gap-1.5 mb-4">
          <button onClick={() => setMode('queue')}
            className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
              mode === 'queue'
                ? 'border-fuchsia-300 bg-fuchsia-300/15 text-fuchsia-200'
                : 'border-zinc-700 text-zinc-400 hover:border-fuchsia-300/50 hover:text-zinc-200'
            }`}
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            queue mode · work distribution
          </button>
          <button onClick={() => setMode('stream')}
            className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
              mode === 'stream'
                ? 'border-fuchsia-300 bg-fuchsia-300/15 text-fuchsia-200'
                : 'border-zinc-700 text-zinc-400 hover:border-fuchsia-300/50 hover:text-zinc-200'
            }`}
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            stream mode · event log
          </button>
        </div>

        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13px] leading-relaxed italic">
          {mode === 'queue'
            ? `Two workers compete for work from a single FIFO queue. Each produced event goes to exactly ONE worker. After it is read, the event is gone. Click "produce event" a few times, then click "read next" on each worker — watch the work distribute. Try producing 5 events first, then read from one worker only. Notice how the unread events pile up.`
            : `Three consumers — Analytics, Notifier, and Audit — each track their own position (offset) in an append-only log. ALL three see EVERY event. Produce a few events, then advance each consumer at its own pace. Click "replay" on any consumer to reset its offset to 0 and re-read everything. This is the move that distinguishes streams from queues: history is replayable.`
          }
        </div>

        {mode === 'queue' ? <QueueMode /> : <StreamMode />}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section01_QueuesStreams() {
  return (
    <>
      <SectionLabel>section 01</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Queues vs Streams — the two patterns
      </h2>
      <P>
        Atlas 20 covered the data layer. Atlas 21 covered the protocols that let machines agree.
        This atlas takes a sideways approach: what if you stopped trying to agree on shared
        state and instead structured systems around immutable event streams? Two patterns
        dominate the event-driven world. They look superficially similar — both involve
        producers publishing events for consumers to process — but their semantics are
        fundamentally different. Picking the wrong one is the most common architecture mistake
        teams make when starting on event-driven systems.
      </P>

      <H2 num="◇ 01">The fundamental distinction</H2>
      <Code id="queue-vs-stream" lang="text">{`QUEUES                              STREAMS
──────                              ───────
Purpose: distribute WORK            Purpose: broadcast EVENTS
                                    
Each message goes to ONE consumer   Each event is seen by ALL consumers
After consumption: message GONE     After consumption: event STAYS in log
Multiple workers share the load     Each consumer tracks its own offset
Reliability via ack/redeliver       Reliability via offset commits + replay
                                    
Mental model:                       Mental model:
  a task list to work through         a history book to read through

Implementations:                    Implementations:
  RabbitMQ, Amazon SQS,               Apache Kafka, AWS Kinesis,
  ActiveMQ, RabbitMQ (work mode),     Apache Pulsar (also queues),
  Sidekiq, Celery, BullMQ             Redis Streams, NATS JetStream`}</Code>
      <P>
        Two real examples that make this concrete:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-fuchsia-300">"Send 1 million welcome emails."</strong> This is a QUEUE workload. Each email is independent work. You want 50 worker processes splitting the load so it completes in minutes instead of hours. After an email is sent, that work is done — no point keeping it around.
        </li>
        <li>
          <strong className="text-fuchsia-300">"User completed checkout. Tell analytics, fraud detection, fulfillment, and the recommendation engine."</strong> This is a STREAM workload. Every subscriber needs the same event. Subscribers come and go over time (you add a new "customer welcome" service next month). New subscribers should be able to replay history. Events have value beyond their first processing.
        </li>
      </ul>

      <H2 num="◇ 02">The queue model in depth</H2>
      <P>
        A queue is a first-in-first-out collection of messages. Producers append. Consumers
        pop. The fundamental operations:
      </P>
      <Code id="queue-ops" lang="text">{`PRODUCER → enqueue(msg)         add a message to the back
CONSUMER → dequeue()            atomically remove from the front (or block)
CONSUMER → ack(msg_id)          confirm processing succeeded; safe to delete
CONSUMER → nack(msg_id, retry)  processing failed; requeue or send to DLQ

DELIVERY GUARANTEE (typical):
  "at least once" — message is redelivered if no ack received within a timeout.
                    Consumers MUST be idempotent (we covered this in Atlas 19 §02).

SCALING:
  N consumers reading from the same queue share the load.
  Throughput scales horizontally — until contention on the queue itself.

THE GAP:
  Queues do not preserve history. Once acked, the message is gone.
  If a new consumer joins, it sees only messages produced AFTER it joined.
  No replay. No "read what happened last week."`}</Code>

      <H2 num="◇ 03">The stream model in depth</H2>
      <P>
        A stream is an append-only log of events with a position pointer for each consumer.
        Producers append. Consumers track their offset and read forward.
      </P>
      <Code id="stream-ops" lang="text">{`PRODUCER → append(event)              event added at the next offset
CONSUMER → read(from_offset, count)   read events forward
CONSUMER → commit_offset(offset)      "I have processed up to here"

KEY DIFFERENCES from queue:

1. EVENTS ARE NOT REMOVED after reading.
   They live in the log until retention policy deletes them (typically 7-30 days,
   or until a size cap, or forever for "compacted" topics).

2. EACH CONSUMER TRACKS ITS OWN OFFSET.
   Analytics service reads from offset 100. Notification service reads from
   offset 250. Both see exactly the same events, just at their own pace.

3. NEW CONSUMERS CAN REPLAY HISTORY.
   Reset offset to 0 — replay every event from the beginning. Crucial for:
     - Building a new derived view from history (CQRS)
     - Recovering from a bug that processed events wrong
     - Onboarding a new service that needs to "catch up"

4. ORDERING is preserved WITHIN a partition (more below).
   This is the property that lets you reason about CAUSAL sequences:
   if event A appears before event B in the log, A definitively happened first.`}</Code>

      <H2 num="◇ 04">Consumer groups — the scaling pattern</H2>
      <P>
        Both queue and stream systems support "consumer groups" — multiple consumer processes
        cooperating to handle load. The semantics differ:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-fuchsia-300">Queue consumer group:</strong> all consumers in the group share one queue. Each message goes to exactly one consumer in the group (round-robin or competing). Add more consumers = more throughput, same load. This is just "more workers."
        </li>
        <li>
          <strong className="text-fuchsia-300">Stream consumer group (Kafka-style):</strong> the stream is divided into PARTITIONS. Each partition is assigned to exactly one consumer in the group. Add more consumers (up to the partition count) to parallelize processing within the same logical stream — but EVERY consumer group still sees EVERY event independently of other groups.
        </li>
      </ul>
      <Callout kind="stream" title="THE KAFKA CONSUMER GROUP MENTAL MODEL">
        Imagine a stream split into 10 partitions. Consumer group "Analytics" has 4 consumers;
        Kafka assigns 2-3 partitions to each. Consumer group "Notifier" has 10 consumers; Kafka
        gives each one partition. Both groups see EVERY event, but within each group, work is
        divided. If "Analytics" has 20 consumers but only 10 partitions, 10 of them sit idle —
        partition count caps parallelism. This is why partition count is a planning decision,
        not a runtime knob.
      </Callout>

      <H2 num="◇ 05">Partitioning — ordering and parallelism</H2>
      <P>
        Streams scale beyond one machine via partitioning. The stream is split into N
        partitions, each appended to independently. Ordering is guaranteed WITHIN a partition
        but NOT across partitions.
      </P>
      <Code id="partitioning" lang="text">{`Event { user_id: 42, action: "click" } → hash(user_id) % N → partition 3
Event { user_id: 42, action: "purchase" } → hash(user_id) % N → partition 3
Event { user_id: 99, action: "click" } → hash(user_id) % N → partition 7

PARTITION KEY = user_id

All events for user 42 land in partition 3. They are processed IN ORDER
by whichever consumer owns partition 3.

Events for user 99 are in partition 7. They are processed in order
WITHIN partition 7, but their relative order to user 42's events is not
guaranteed — they may be processed by different consumers in parallel.

THE TRADE:
  Partitioning increases throughput.
  Within a partition, you have ordering.
  Across partitions, you have parallelism without ordering.

  Choose your partition key based on what you need ordered:
    user_id → ordering per user, parallel across users
    order_id → ordering per order, parallel across orders
    No key → events spread randomly, max parallelism, NO ordering`}</Code>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 06">Switch between the two and feel the difference</H2>
      <P>
        Two tabs. Queue mode: two workers compete; events disappear after consumption. Stream
        mode: three consumers each have their own offset; events stay forever; click "replay"
        to reset a consumer to offset 0 and re-read every event from the start. Produce a few
        events, advance each consumer at its own pace, then hit replay on Analytics to see
        what it looked like to a newcomer who just joined.
      </P>

      <QueueStreamVisualizer />

      <H2 num="◇ 07">When to use which</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-lime-400">Use a QUEUE when:</strong> the unit of work belongs to exactly one processor (send email, process payment, resize image), the work is purely "completed or not" (binary), and you do not need to replay or share with other services. Background jobs are the canonical case.
        </li>
        <li>
          <strong className="text-lime-400">Use a STREAM when:</strong> the event has informational value beyond its first processing, multiple services need to react to the same event, you may add NEW consumers in the future who want history, ordering matters within some grouping (user, order, account), or you are building event-sourcing / CQRS systems.
        </li>
        <li>
          <strong className="text-rose-400">Do NOT use a stream for short-lived work that needs ack-then-delete semantics.</strong> Streams keep everything; long-term retention of acknowledged work is wasteful and confusing.
        </li>
        <li>
          <strong className="text-rose-400">Do NOT use a queue when multiple services need the same event.</strong> The common anti-pattern: each service subscribes to its own copy of the queue, producers publish to all of them. This is "manual fan-out" — and it breaks when you add a service (need to remember to add the queue) or when one service is slow (now every producer waits or buffers).
        </li>
      </ul>

      <H2 num="◇ 08">Hybrid systems — when the line blurs</H2>
      <P>
        Modern systems often blur the queue/stream distinction. The interesting examples:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-fuchsia-300">Apache Pulsar:</strong> supports both queue semantics (Shared subscription mode) and stream semantics (Exclusive / Failover subscription mode) on the same topic. The TOPIC is the broker abstraction; subscription mode picks the consumption pattern.
        </li>
        <li>
          <strong className="text-fuchsia-300">NATS JetStream:</strong> stream-first design with optional queue-like work distribution via "pull consumers" and configurable redelivery. Lightweight; great for cases where you want stream replay AND distributed work.
        </li>
        <li>
          <strong className="text-fuchsia-300">Redis Streams:</strong> stream semantics with consumer groups built in. Works as a stream when each consumer has its own group; works as a queue when multiple consumers join the same group. The API is the same; behavior follows from your setup.
        </li>
        <li>
          <strong className="text-fuchsia-300">Kafka Streams (the library, not the broker):</strong> reads from streams, builds derived streams, can act as a queue consumer pattern at the application level. Stateful stream processing on top of the stream primitive.
        </li>
      </ul>

      <H2 num="◇ 09">Hardening checklist for queue/stream choice</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Architecture choice (queue vs stream) documented per topic / per workload</li>
        <li>✓ For queues: dead-letter queue configured for messages that repeatedly fail</li>
        <li>✓ For streams: retention policy set explicitly (time-based, size-based, or compacted)</li>
        <li>✓ For streams: partition count chosen based on expected parallelism needs (it&apos;s hard to change later)</li>
        <li>✓ Partition key chosen so all related events land together (user_id, order_id, etc.)</li>
        <li>✓ Consumer groups documented — which group has which responsibility</li>
        <li>✓ Consumer lag monitored with alerts at meaningful thresholds (e.g., &gt;5 minutes behind)</li>
        <li>✓ Idempotent consumers across the board (every consumer can handle a duplicate without harm)</li>
        <li>✓ Replay procedure documented — how to reset a consumer&apos;s offset to recover from a bug</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Now that we have the two patterns, the next question is delivery semantics: what does
        the system actually guarantee when networks fail or processes crash mid-handling? The
        canonical "at-most-once / at-least-once / exactly-once" trilemma, the truth about
        Kafka&apos;s "exactly-once semantics," and the idempotent-consumer pattern that makes
        it work in practice.
      </Callout>
    </>
  );
}
