/* Section 04 — Outbox, Sagas, and the Operational Realities.
 * Closes Atlas 22 AND the data-systems trilogy (20 → 21 → 22).
 *
 * Prose + Outbox Pattern Simulator + atlas-closing + trilogy-closing.
 *
 * The simulator: three scenarios (happy path, crash after DB write, crash
 * after publish) × two approaches (dual-write vs outbox). Same pattern as
 * Atlas 22 §02's Delivery Semantics Simulator — scenario tabs at top,
 * approach picker below, timelines + final state + verdict fill in based
 * on the combination.
 *
 * The teaching aim: dual-write is unfixable by retry-ordering — both
 * orderings have failure modes. Outbox makes the event-publish part of
 * the same transaction as the state change.
 *
 * All prose strings use backticks (template literals).
 */

import { useState } from 'react';
import { Sparkles, Database, Send, AlertTriangle, CheckCircle2, X, Cog, RefreshCw } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Outbox Pattern Simulator
// ───────────────────────────────────────────────────────────────────────

const SCENARIOS = [
  {
    id: 'happy',
    label: 'Happy path',
    description: `Request handler runs cleanly. DB write succeeds. Event publish succeeds (or, for the outbox approach, gets picked up by the relay worker). Both approaches reach the same final state.`,
    dualWrite: {
      title: 'Dual-write (DB write, then queue.publish)',
      steps: [
        { actor: 'app', text: `INSERT order INTO orders`, tone: 'ok' },
        { actor: 'app', text: `queue.publish(OrderCreated)`, tone: 'ok' },
      ],
      final: { db: '✓ order saved', queue: '✓ event published', consistent: true },
      verdict: `Both writes succeeded. State is consistent — DB has the order, queue has the event. Both downstream services will see OrderCreated and act on it.`,
    },
    outbox: {
      title: 'Outbox pattern (one transaction + relay worker)',
      handlerSteps: [
        { text: `BEGIN TRANSACTION`, tone: 'neutral' },
        { text: `INSERT order INTO orders`, tone: 'ok' },
        { text: `INSERT into outbox (OrderCreated payload, published_at=NULL)`, tone: 'ok' },
        { text: `COMMIT`, tone: 'ok' },
      ],
      relaySteps: [
        { text: `(relay worker poll) SELECT FROM outbox WHERE published_at IS NULL`, tone: 'neutral' },
        { text: `queue.publish(OrderCreated)`, tone: 'ok' },
        { text: `UPDATE outbox SET published_at = now()`, tone: 'ok' },
      ],
      final: { db: '✓ order saved', outbox: '✓ marked published', queue: '✓ event published', consistent: true },
      verdict: `Two-phase but eventually consistent: the handler commits both rows atomically; the relay worker publishes within seconds. Consumer sees the event with bounded lag.`,
    },
  },
  {
    id: 'crash-after-db',
    label: 'Crash after DB write',
    description: `Request handler successfully writes the order to the database, then the process crashes before publishing to the queue. This is the canonical dual-write failure mode.`,
    dualWrite: {
      title: 'Dual-write (DB write, then queue.publish)',
      steps: [
        { actor: 'app', text: `INSERT order INTO orders`, tone: 'ok' },
        { actor: 'app', text: `⚠ process crashes before queue.publish()`, tone: 'error' },
      ],
      final: { db: '✓ order saved', queue: '✗ event LOST', consistent: false },
      verdict: `BROKEN. DB has the order; queue never received the event. Downstream services (fulfillment, fraud detection, notifications) don't know the order exists. On restart, the handler has no way to detect that the order was saved without the event — and re-running would create a duplicate order. This bug ships to production constantly because every teammate who's seen it suggests "add a retry," which only moves the failure window without fixing it.`,
    },
    outbox: {
      title: 'Outbox pattern (one transaction + relay worker)',
      handlerSteps: [
        { text: `BEGIN TRANSACTION`, tone: 'neutral' },
        { text: `INSERT order INTO orders`, tone: 'ok' },
        { text: `INSERT into outbox (OrderCreated, published_at=NULL)`, tone: 'ok' },
        { text: `COMMIT`, tone: 'ok' },
        { text: `(returns 200 to client; process is free to crash now)`, tone: 'neutral' },
      ],
      relaySteps: [
        { text: `(relay worker poll, 1 second later)`, tone: 'neutral' },
        { text: `SELECT FROM outbox WHERE published_at IS NULL`, tone: 'neutral' },
        { text: `→ finds the OrderCreated row`, tone: 'ok' },
        { text: `queue.publish(OrderCreated)`, tone: 'ok' },
        { text: `UPDATE outbox SET published_at = now()`, tone: 'ok' },
      ],
      final: { db: '✓ order saved', outbox: '✓ marked published', queue: '✓ event published (with ~1s lag)', consistent: true },
      verdict: `SAFE. The handler's transaction committed atomically — both the order row AND the outbox row are durable. Even if the handler process crashes immediately after COMMIT, the relay worker (which runs in a separate process) will pick up the unpublished outbox row on its next poll and deliver it. Consumers see the event a second later instead of immediately, but they see it.`,
    },
  },
  {
    id: 'crash-after-publish',
    label: 'Crash after publish (reversed order)',
    description: `Some teams "fix" dual-write by reversing the order — publish FIRST, then write to DB. This scenario shows what goes wrong. The outbox approach is unaffected because there is no equivalent failure mode.`,
    dualWrite: {
      title: 'Dual-write (queue.publish first, then DB write)',
      steps: [
        { actor: 'app', text: `queue.publish(OrderCreated)`, tone: 'ok' },
        { actor: 'app', text: `⚠ process crashes before INSERT order INTO orders`, tone: 'error' },
      ],
      final: { db: '✗ no order row', queue: '✓ event published — but for nothing', consistent: false },
      verdict: `BROKEN in a DIFFERENT WAY. Queue has the event; DB has no order. Downstream services see OrderCreated and try to look up the order — and find nothing. Ghost events. This is arguably worse than the previous scenario because the failure surfaces as "downstream service can't find the order it just got told about" — and the bug looks like it's in the downstream service, not the producer. The lesson: reversing the order does not fix dual-write. There is NO ordering that makes two unrelated writes atomic.`,
    },
    outbox: {
      title: 'Outbox pattern (one transaction + relay worker)',
      handlerSteps: [
        { text: `(no ordering problem to "fix" — both writes are in one TX)`, tone: 'neutral' },
        { text: `BEGIN TRANSACTION`, tone: 'neutral' },
        { text: `INSERT order INTO orders`, tone: 'ok' },
        { text: `INSERT into outbox (OrderCreated, published_at=NULL)`, tone: 'ok' },
        { text: `⚠ process crashes BEFORE COMMIT`, tone: 'error' },
        { text: `→ transaction rolls back — neither row persists`, tone: 'warn' },
        { text: `Client sees an error; can safely retry the entire request`, tone: 'ok' },
      ],
      relaySteps: [
        { text: `(relay worker poll)`, tone: 'neutral' },
        { text: `SELECT FROM outbox WHERE published_at IS NULL`, tone: 'neutral' },
        { text: `→ no unpublished rows (transaction rolled back)`, tone: 'ok' },
        { text: `nothing to do`, tone: 'neutral' },
      ],
      final: { db: '✗ no order row (rolled back)', outbox: '✗ no row (rolled back)', queue: '✗ no event published', consistent: true },
      verdict: `SAFE because of ATOMICITY. The transaction either commits everything or commits nothing. There is no "partial" state where the order exists but the event does not. The client sees an error and retries; the retry succeeds cleanly. This is the fundamental property the outbox pattern provides — and exactly why it works while dual-write does not.`,
    },
  },
];

// ───────────────────────────────────────────────────────────────────────
// UI helpers
// ───────────────────────────────────────────────────────────────────────

const TONE_STYLES = {
  neutral: { text: 'text-zinc-300',  icon: null },
  ok:      { text: 'text-lime-300',  icon: CheckCircle2 },
  warn:    { text: 'text-amber-300', icon: AlertTriangle },
  error:   { text: 'text-rose-300',  icon: X },
};

function StepRow({ text, tone, num }) {
  const style = TONE_STYLES[tone] || TONE_STYLES.neutral;
  const Icon = style.icon;
  return (
    <div className="grid grid-cols-[24px_1fr] gap-2 py-1 px-2 items-start">
      <div className="text-zinc-600 text-[9.5px] text-right pt-0.5"
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        {String(num).padStart(2, '0')}
      </div>
      <div className={`text-[11px] leading-snug flex items-start gap-1.5 ${style.text}`}
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        {Icon && <Icon size={10} className="shrink-0 mt-0.5" />}
        <span>{text}</span>
      </div>
    </div>
  );
}

function OutboxSimulator() {
  const [scenarioIdx, setScenarioIdx] = useState(1);  // start on the interesting one
  const [approach, setApproach] = useState('dual');   // 'dual' | 'outbox'

  const scenario = SCENARIOS[scenarioIdx];
  const data = approach === 'dual' ? scenario.dualWrite : scenario.outbox;
  const consistent = data.final.consistent;

  return (
    <div className="my-6 border border-fuchsia-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-fuchsia-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-fuchsia-300" />
          <span className="text-fuchsia-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · outbox pattern simulator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => setScenarioIdx(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === scenarioIdx
                  ? 'border-fuchsia-300 bg-fuchsia-300/15 text-fuchsia-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-fuchsia-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {i + 1}. {s.label}
            </button>
          ))}
        </div>

        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13px] leading-relaxed italic">
          {scenario.description}
        </div>

        {/* Approach picker */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          <button onClick={() => setApproach('dual')}
            className={`px-3 py-2 border text-[11px] transition-colors text-left ${
              approach === 'dual'
                ? 'border-rose-400 bg-rose-400/10 text-rose-200'
                : 'border-zinc-700 text-zinc-400 hover:border-rose-400/50 hover:text-zinc-200'
            }`}
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <div className="font-semibold flex items-center gap-1.5">
              <X size={11} /> dual-write (broken)
            </div>
            <div className="text-[10px] opacity-80 mt-0.5">two unrelated writes, no atomicity</div>
          </button>
          <button onClick={() => setApproach('outbox')}
            className={`px-3 py-2 border text-[11px] transition-colors text-left ${
              approach === 'outbox'
                ? 'border-lime-400 bg-lime-400/10 text-lime-200'
                : 'border-zinc-700 text-zinc-400 hover:border-lime-400/50 hover:text-zinc-200'
            }`}
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <div className="font-semibold flex items-center gap-1.5">
              <CheckCircle2 size={11} /> outbox (correct)
            </div>
            <div className="text-[10px] opacity-80 mt-0.5">transaction + relay worker</div>
          </button>
        </div>

        {/* Title */}
        <div className={`text-[10.5px] tracking-[0.25em] uppercase font-semibold mb-2 ${
          approach === 'dual' ? 'text-rose-300' : 'text-lime-300'
        }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          {data.title}
        </div>

        {/* Timeline */}
        {approach === 'dual' ? (
          <div className="border border-zinc-800 bg-zinc-950/60 mb-3">
            <div className="bg-zinc-900 px-2 py-1 text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <Cog size={10} /> request handler
            </div>
            <div className="divide-y divide-zinc-800/60">
              {data.steps.map((s, i) => (
                <StepRow key={i} text={s.text} tone={s.tone} num={i + 1} />
              ))}
            </div>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-3 mb-3">
            <div className="border border-zinc-800 bg-zinc-950/60">
              <div className="bg-zinc-900 px-2 py-1 text-fuchsia-300 text-[9.5px] tracking-[0.25em] uppercase flex items-center gap-1.5"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <Cog size={10} /> request handler (synchronous)
              </div>
              <div className="divide-y divide-zinc-800/60">
                {data.handlerSteps.map((s, i) => (
                  <StepRow key={i} text={s.text} tone={s.tone} num={i + 1} />
                ))}
              </div>
            </div>
            <div className="border border-zinc-800 bg-zinc-950/60">
              <div className="bg-zinc-900 px-2 py-1 text-lime-400 text-[9.5px] tracking-[0.25em] uppercase flex items-center gap-1.5"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <RefreshCw size={10} /> relay worker (asynchronous)
              </div>
              <div className="divide-y divide-zinc-800/60">
                {data.relaySteps.map((s, i) => (
                  <StepRow key={i} text={s.text} tone={s.tone} num={i + 1} />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Final state */}
        <div className="border border-zinc-800 bg-zinc-900/40 p-3 mb-3">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            final state
          </div>
          <div className="grid sm:grid-cols-3 gap-2 text-[11px]"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <div className="flex items-center gap-1.5">
              <Database size={11} className="text-zinc-500" />
              <span className="text-zinc-500">db:</span>
              <span className={data.final.db?.startsWith('✓') ? 'text-lime-300' : 'text-rose-300'}>
                {data.final.db}
              </span>
            </div>
            {data.final.outbox && (
              <div className="flex items-center gap-1.5">
                <Database size={11} className="text-zinc-500" />
                <span className="text-zinc-500">outbox:</span>
                <span className={data.final.outbox?.startsWith('✓') ? 'text-lime-300' : 'text-rose-300'}>
                  {data.final.outbox}
                </span>
              </div>
            )}
            <div className="flex items-center gap-1.5">
              <Send size={11} className="text-zinc-500" />
              <span className="text-zinc-500">queue:</span>
              <span className={data.final.queue?.startsWith('✓') ? 'text-lime-300' : 'text-rose-300'}>
                {data.final.queue}
              </span>
            </div>
          </div>
        </div>

        {/* Verdict */}
        <div className={`border p-3 ${
          consistent
            ? 'border-lime-400/60 bg-lime-400/10'
            : 'border-rose-400/60 bg-rose-400/10'
        }`}>
          <div className={`text-[11px] tracking-[0.25em] uppercase font-semibold mb-1.5 flex items-center gap-2 ${
            consistent ? 'text-lime-400' : 'text-rose-400'
          }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            {consistent ? <CheckCircle2 size={12} /> : <AlertTriangle size={12} />}
            {consistent ? 'consistent' : 'inconsistent'}
          </div>
          <div className="text-zinc-200 text-[13px] leading-relaxed">
            {data.verdict}
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section04_Outbox() {
  return (
    <>
      <SectionLabel>section 04</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Outbox, sagas, and the operational realities
      </h2>
      <P>
        Section 02 ended with a cliffhanger: the dual-write problem. Your service updates the
        database AND publishes an event — and the two writes cannot be made atomic by retry
        ordering. This section solves it. The outbox pattern is the canonical fix; distributed
        sagas handle the broader case where multiple services coordinate; and the operational
        realities (backpressure, dead-letter queues, consumer lag) are what determine whether
        all of this actually works at 3 AM on a Saturday.
      </P>

      <H2 num="◇ 01">The outbox pattern — what it solves</H2>
      <P>
        The bug: your service has TWO durable systems it writes to — a database and a message
        broker. You need both to commit together, but they cannot be enrolled in a single
        transaction. Whichever one you write first can succeed while the second fails, leaving
        you in an inconsistent state with no way to recover by retry.
      </P>
      <Code id="dual-write-recap" lang="text">{`DUAL-WRITE — broken in BOTH orderings:

  Order 1: DB first, then queue
    INSERT order INTO orders          ← succeeds
    queue.publish(OrderCreated)       ← crashes here
    Result: DB has order; queue does NOT. Event lost. Downstream confused.

  Order 2: Queue first, then DB
    queue.publish(OrderCreated)       ← succeeds; consumers START processing
    INSERT order INTO orders          ← crashes here
    Result: Queue has event; DB does NOT. Ghost event. Consumers find nothing.

The fix is NOT a different ordering. The fix is INVOLVING THE DATABASE in the
event-publish step, so both writes share one transaction.`}</Code>
      <P>
        The outbox pattern: add an <Kbd>outbox</Kbd> table to your service&apos;s database.
        When the handler updates state, it ALSO inserts a row representing the event-to-publish,
        in the same transaction. A separate process (the "relay worker") polls the outbox
        table, publishes pending events to the broker, and marks them published.
      </P>
      <Code id="outbox-schema" lang="sql">{`-- Outbox table schema
CREATE TABLE outbox (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    aggregate_id  TEXT NOT NULL,            -- e.g., the order's ID
    event_type    TEXT NOT NULL,            -- e.g., 'OrderCreated'
    payload       JSONB NOT NULL,           -- the event body
    created_at    TIMESTAMP NOT NULL DEFAULT now(),
    published_at  TIMESTAMP                 -- NULL until relay publishes it
);

CREATE INDEX idx_outbox_unpublished
  ON outbox (created_at)
  WHERE published_at IS NULL;             -- partial index — only the work queue
                                            -- becomes very small as old events
                                            -- get marked published`}</Code>
      <Code id="outbox-handler" lang="python">{`# In the request handler — both writes in one transaction
def create_order(request):
    with db.transaction():
        order = db.insert(orders, {
            'customer_id': request.customer_id,
            'total': request.total,
        })
        db.insert(outbox, {
            'aggregate_id': order.id,
            'event_type': 'OrderCreated',
            'payload': {'order_id': order.id, 'customer_id': order.customer_id},
        })
        # Both rows commit atomically — or neither does

    return 200, {'order_id': order.id}
    # Process can crash here; relay worker will publish on its next run`}</Code>

      <H2 num="◇ 02">The relay worker</H2>
      <Code id="outbox-relay" lang="python">{`# Relay worker — separate process or service
# Runs continuously; polls every ~100ms or uses LISTEN/NOTIFY on Postgres

while True:
    with db.transaction():
        # SKIP LOCKED lets multiple workers run safely
        rows = db.query("""
            SELECT * FROM outbox
            WHERE published_at IS NULL
            ORDER BY created_at
            LIMIT 100
            FOR UPDATE SKIP LOCKED
        """)

        for row in rows:
            try:
                queue.publish(row.event_type, row.payload)
                db.execute("""
                    UPDATE outbox SET published_at = now()
                    WHERE id = $1
                """, row.id)
            except QueuePublishError:
                # leave published_at NULL — try again next iteration
                pass

    sleep(0.1)  # or wait on LISTEN/NOTIFY`}</Code>
      <Callout kind="stream" title="WHY THIS WORKS WHERE DUAL-WRITE DOES NOT">
        The two writes that have to commit together (state change + event) are both in the
        SAME database — and a database can give you atomicity across multiple rows. The publish
        to the external queue is moved OUT of the handler&apos;s critical path and into a
        separate process that polls the outbox. If the relay crashes mid-publish, it just
        retries — the queue receives a duplicate, and the (idempotent) consumer handles it
        (see Atlas 22 §02). The handler&apos;s atomicity guarantees that the outbox row exists
        if and only if the state change exists.
      </Callout>

      <H2 num="◇ 03">Change data capture — the no-outbox alternative</H2>
      <P>
        Change Data Capture (CDC) takes a different approach: instead of writing to an outbox
        table, READ from the database&apos;s transaction log (WAL on Postgres, binlog on MySQL).
        Tools like Debezium, Maxwell, AWS DMS subscribe to the WAL and emit a stream of "row
        changed" events. Your service writes to the database normally; CDC turns those writes
        into events automatically.
      </P>
      <Code id="cdc-vs-outbox" lang="text">{`OUTBOX                                  CDC (Debezium et al.)
──────                                  ─────
+ Explicit event types — you design     + Zero extra writes from handlers
  what gets published                   + Automatic — every row change emits an event
+ Schema fully under your control       - Stream is a "table mirror," not a domain event
+ Works with any DB; no special config  - Schema = table schema, not event schema
- Extra table to maintain               - Requires WAL/binlog access (special permissions,
- Extra writes for every handler          replication slot on Postgres, etc.)
                                        - Operating Debezium is a job

REAL-WORLD HYBRID:
  Many teams use BOTH — outbox for domain events ("OrderCreated"), CDC for
  table-mirror streams ("orders.row_inserted"). The downstream consumers each
  pick the stream they want.`}</Code>

      <H2 num="◇ 04">Distributed sagas — coordinating across services</H2>
      <P>
        The outbox pattern handles ONE service publishing reliably. But many business
        operations span multiple services. "Place an order" might involve: reserve inventory,
        charge the card, schedule shipping, send confirmation email. None of these are in
        your database; each lives in its own service with its own database.
      </P>
      <P>
        Sagas are the pattern for these long-running cross-service workflows. Two flavors:
      </P>
      <Code id="sagas" lang="text">{`CHOREOGRAPHY — each service reacts to events from others. No coordinator.

    OrderService:                    InventoryService:
      OrderCreated  ──────►            on OrderCreated:
                                         reserve inventory
                                         emit InventoryReserved

    PaymentService:                  ShippingService:
      on InventoryReserved:            on PaymentCharged:
        charge card                       schedule shipment
        emit PaymentCharged                emit ShipmentScheduled

  + Simple to understand at the per-service level
  + Loose coupling — services don't know about each other
  - Hard to see the whole flow — it's implicit in event subscriptions
  - Compensation logic is scattered (each service implements its own rollback)

ORCHESTRATION — a coordinator service drives the whole workflow.

    OrderSaga (the orchestrator):
      1. send ReserveInventory to InventoryService
         wait for InventoryReserved response
      2. send ChargeCard to PaymentService
         wait for PaymentCharged response
      3. send ScheduleShipment to ShippingService
         wait for ShipmentScheduled response
      4. mark order complete

      ON ANY STEP FAILURE:
        run compensating transactions for the steps that succeeded
        (e.g., refund the card, release the inventory)

  + Workflow is centralized and visible — easy to reason about and modify
  + Compensation logic is centralized
  - Coordinator can become a bottleneck or single point of failure
  - Tighter coupling — coordinator knows about every step`}</Code>
      <Callout kind="info" title="HOW TO CHOOSE">
        Choreography is the natural fit when the number of services is small (2-4), the flow
        is mostly linear, and each service can reasonably know what to do next.
        Orchestration becomes necessary when the workflow has many steps, branching logic,
        or complex compensation. Most real teams end up with a mix — small sagas
        choreographed, complex ones orchestrated. Tools like Temporal, AWS Step Functions,
        and Camunda exist specifically for the orchestration case.
      </Callout>

      <H2 num="◇ 05">Compensating transactions</H2>
      <P>
        Sagas cannot roll back like database transactions. Once an event has been published
        and another service has acted on it, "undo" requires another action — a COMPENSATING
        TRANSACTION. The order matters: undo in reverse order of what was done.
      </P>
      <Code id="compensations" lang="text">{`FORWARD WORKFLOW:                  COMPENSATION:

  ReserveInventory       ◄─────────►  ReleaseInventory
  ChargeCard             ◄─────────►  RefundCard
  ScheduleShipment       ◄─────────►  CancelShipment
  SendConfirmationEmail  ◄─────────►  SendCancellationEmail

If step 3 (ScheduleShipment) fails:
  - run CancelShipment? NO — step 3 never succeeded
  - run RefundCard          ← yes
  - run ReleaseInventory    ← yes
  - mark saga FAILED, notify customer

KEY PROPERTIES OF GOOD COMPENSATIONS:

  + Always succeed if the original succeeded (commutative, in a sense)
  + Are themselves idempotent (compensations can be retried)
  + Logged for audit — refunds especially need a paper trail
  + Sometimes are NOT exact opposites (sending a "we cancelled your order"
    email is not the inverse of "we confirmed your order")`}</Code>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 06">See the dual-write break — and the outbox fix it</H2>
      <P>
        Three scenarios — happy path, crash after DB write, crash after publish (reversed
        order). Two approaches — dual-write vs outbox. For each combination, see the timeline
        of operations, the final state of each system, and the consistency verdict. The two
        failure scenarios show that no ordering of dual-write is correct. The outbox approach
        handles all three cleanly.
      </P>

      <OutboxSimulator />

      <H2 num="◇ 07">Operational realities</H2>
      <P>
        Patterns are necessary but not sufficient. The following operational concerns kill
        event-driven systems in production:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-fuchsia-300">Backpressure.</strong> Producers can outpace consumers. Without backpressure, the queue grows unboundedly until the broker runs out of disk or memory. The defenses: rate limits at the producer, partition-count tuning, queue-depth alerts that page someone before disk fills. The worst variant: a producer that does not slow down when the queue is full — drops messages silently. Always know your broker&apos;s overflow behavior.
        </li>
        <li>
          <strong className="text-fuchsia-300">Dead-letter queues (DLQ).</strong> Some messages will fail repeatedly — bad data, schema mismatches, downstream outage that has lasted hours. After N retries (typically 3-10), route to a DLQ instead of looping forever. The DLQ is for HUMAN review, not silent dropping. Alert when it grows. Have a triage procedure.
        </li>
        <li>
          <strong className="text-fuchsia-300">Consumer lag monitoring.</strong> The single most important metric for event-driven systems. <Kbd>broker_offset - consumer_offset</Kbd> per partition per consumer group, alerted at a meaningful threshold (e.g., 5 minutes for hot paths, 30 minutes for analytics). Lag spikes are early warning for downstream problems.
        </li>
        <li>
          <strong className="text-fuchsia-300">Partition rebalancing.</strong> When a consumer joins or leaves a group, partitions reassign. During rebalance (Kafka&apos;s "stop-the-world" old behavior; the new "cooperative" rebalance is incremental), no events are processed. A flapping consumer can cause perpetual rebalance and total stall. Use stable consumer IDs and avoid frequent restarts.
        </li>
        <li>
          <strong className="text-fuchsia-300">Schema evolution.</strong> Events live forever in compacted topics; producers and consumers ship independently. A breaking schema change can lock out new consumers from old events. Use a schema registry (Confluent, Apicurio), require backward-compatible schema changes, version every event type explicitly.
        </li>
        <li>
          <strong className="text-fuchsia-300">Poison messages.</strong> A single bad message that crashes a consumer can stall a whole partition (consumer keeps retrying, never advances). The defense: catch parse errors specifically, route bad messages to DLQ, never let one bad message block the partition.
        </li>
      </ul>

      <H2 num="◇ 08">Where these patterns ship in production</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-fuchsia-300">Outbox pattern</strong> — Shopify, Stripe, Uber, most fintechs. Reference architecture for transactional event publishing.</li>
        <li><strong className="text-fuchsia-300">Debezium / CDC</strong> — LinkedIn, Wix, many data-engineering pipelines. Stream-table duality made concrete.</li>
        <li><strong className="text-fuchsia-300">Temporal / Cadence</strong> — Uber (original creators), Snap, Doordash, Box, Stripe. The dominant orchestration runtime for long-running sagas.</li>
        <li><strong className="text-fuchsia-300">AWS Step Functions</strong> — broad adoption in cloud-native orgs. Visual workflows, automatic retries, native AWS integration.</li>
        <li><strong className="text-fuchsia-300">Kafka Streams + Confluent Schema Registry</strong> — financial services, telco, broad enterprise. The "do it all in Kafka" stack.</li>
        <li><strong className="text-fuchsia-300">NATS JetStream</strong> — increasingly popular for cloud-native, edge, IoT. Lightweight; great when Kafka is overkill.</li>
      </ul>

      <H2 num="◇ 09">Hardening checklist for event-driven systems</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ No service uses dual-write (DB write + queue publish in the handler) — outbox or CDC instead</li>
        <li>✓ Outbox table indexed for the relay worker&apos;s polling query (partial index on <Kbd>published_at IS NULL</Kbd>)</li>
        <li>✓ Relay worker can be horizontally scaled (uses <Kbd>FOR UPDATE SKIP LOCKED</Kbd> or equivalent)</li>
        <li>✓ Cross-service workflows use sagas, not "fire and pray" — compensation paths defined and tested</li>
        <li>✓ Saga orchestration runtime (Temporal, Step Functions) chosen rather than home-grown</li>
        <li>✓ DLQ configured per consumer, with alerting on growth</li>
        <li>✓ Consumer lag dashboard exists, with per-partition alerting</li>
        <li>✓ Schema registry in front of all producers, backward-compatibility enforced</li>
        <li>✓ Backpressure tested under load — known producer-throttling and broker-overflow behavior</li>
        <li>✓ Poison-message handling tested (deliberately bad message → routed to DLQ, partition keeps moving)</li>
        <li>✓ Idempotent consumers verified across the board (Atlas 22 §02 carries over)</li>
      </ul>

      {/* ──────────────────────────────────────────────────────────────── */}
      {/* CLOSING — Atlas 22 wrap + trilogy-closing + next-arc preview    */}
      {/* ──────────────────────────────────────────────────────────────── */}

      <SectionLabel>end of atlas</SectionLabel>
      <H2 num="◆">What you can do now</H2>
      <P>Four sections back, "event-driven" was a marketing term. Now you can:</P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-fuchsia-300">Pick the right pattern</strong> — queue for work distribution, stream for event broadcasting. Recognize the manual-fan-out anti-pattern. Choose partition keys for the ordering you need.</li>
        <li><strong className="text-fuchsia-300">Reason about delivery semantics honestly</strong> — at-most-once / at-least-once / exactly-once-ish. Make consumers idempotent. Know that Kafka EOS only protects within Kafka.</li>
        <li><strong className="text-fuchsia-300">Use compaction and event sourcing where they fit</strong> — state streams compacted, fact streams retained by time. Snapshots for replay performance. CQRS for fan-out to specialized read models.</li>
        <li><strong className="text-fuchsia-300">Fix dual-write the right way</strong> — outbox pattern or CDC. Coordinate cross-service workflows with sagas. Handle operational realities (DLQs, lag, schema evolution) before they bite.</li>
      </ul>

      <SectionLabel>the data-systems arc — complete</SectionLabel>
      <H2 num="◆">Three atlases, one story</H2>
      <P>
        Atlas 20-21-22 form a complete arc. Each atlas answered one core question; together
        they cover the spectrum of how production systems handle data at scale.
      </P>
      <Code id="trilogy-complete" lang="text">{`ATLAS 20 — DATABASES AT SCALE       ✓ "How does the data live and move on one machine?"
   ▤ · complete                       Indexes · query plans · transactions · replication

ATLAS 21 — DISTRIBUTED SYSTEMS      ✓ "How do machines agree (or detect when they cannot)?"
   ⬢ · complete                       Partial failure · consensus · clocks · quorum

ATLAS 22 — EVENT-DRIVEN             ✓ "What if you don't need agreement at all?"
   ≋ · complete                       Queues · streams · delivery · compaction · outbox

THE ARC IN ONE LINE:
  20 — single-machine guarantees and how to scale them
  21 — multi-machine guarantees and the math that limits them
  22 — the move that sidesteps the agreement problem entirely`}</Code>
      <Callout kind="win" title="WHAT YOU CAN BUILD WITH ALL THREE">
        You now have the architectural vocabulary for any data-handling system at any scale —
        from a single Postgres backing an app, to a 10-node consensus cluster powering control
        plane state, to a Kafka-fronted event-sourced microservice mesh with sagas. The
        right answer is usually the SIMPLEST architecture that solves the actual problem.
        Most teams reach for "event-driven microservices" when a single Postgres with good
        indexes and a couple of background jobs would have worked fine. The atlases give you
        the muscle memory to know which level you actually need.
      </Callout>

      <SectionLabel>what comes next</SectionLabel>
      <H2 num="◆">The operations arc</H2>
      <P>
        The series so far has been about BUILDING — APIs (17-19), data systems (20-22). What
        is missing is RUNNING what you built. The next arc tackles operations:
      </P>
      <Code id="next-arc" lang="text">{`ATLAS 23 — OBSERVABILITY            "What is actually happening inside the system?"
   (planned)                          Logs · metrics · traces — the three pillars
                                      Cardinality budgets · structured logging · OpenTelemetry

ATLAS 24 — RELIABILITY              "How reliable IS the system, and how reliable should it be?"
   (planned)                          SLIs · SLOs · SLAs · error budgets · chaos engineering

ATLAS 25 — INCIDENT RESPONSE         "What happens when something breaks?"
   (planned)                          On-call · alerting · postmortems · blameless culture`}</Code>
      <P>
        Each builds on the previous arcs. You cannot debug a distributed system without
        observability. You cannot have a meaningful SLO without instrumentation. You cannot
        write a useful postmortem without understanding what the system was supposed to
        do — and that requires the architectural muscle the previous atlases built.
      </P>
      <P>
        Reference index at <Kbd>atlases.vercel.app</Kbd>. The series continues.
      </P>
      <div className="text-zinc-500 text-center text-[10.5px] tracking-[0.3em] uppercase mt-12 mb-4"
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        ≋ · atlas twenty-two · complete · data-systems arc complete
      </div>
    </>
  );
}
