/* Section 02 — Delivery Semantics.
 *
 * Prose + Delivery Semantics Simulator.
 *
 * The simulator: three failure scenarios × three semantic levels. The
 * student picks one of each and the simulator renders the timeline of
 * events at each actor (producer / broker / consumer), with the final
 * outcome (delivered N times, duplicated, or lost).
 *
 * Pattern carried over from Atlas 20 §03 (Isolation Level Simulator):
 * scenario tabs + level picker → timeline fills in based on combination.
 *
 *   Scenarios:
 *     1. Happy path — no failures
 *     2. Broker ack lost — broker persisted, ack didn't reach producer
 *     3. Consumer crash after processing — processed, never acked
 *
 *   Semantics:
 *     - at-most-once    (no retry; can lose)
 *     - at-least-once   (retry until ack; can duplicate)
 *     - exactly-once-ish (at-least-once + idempotent producer + idempotent consumer)
 *
 * All prose strings use backticks (template literals).
 */

import { useState } from 'react';
import { Sparkles, Send, Server, Cpu, AlertTriangle, CheckCircle2, X } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Delivery Semantics Simulator
// ───────────────────────────────────────────────────────────────────────

const SEMANTICS = [
  { id: 'at-most-once',     label: 'at-most-once'     },
  { id: 'at-least-once',    label: 'at-least-once'    },
  { id: 'exactly-once-ish', label: 'exactly-once-ish' },
];

// Each step in a timeline: actor, action description, tone (neutral/warn/error/ok).
const SCENARIOS = [
  {
    id: 'happy',
    label: 'Happy path',
    description: `Producer sends one message. Broker persists it. Consumer reads, processes, acks. All three semantics give the same result here — the failure cases are where they diverge.`,
    outcomes: {
      'at-most-once': {
        steps: [
          { actor: 'producer', text: `sends MSG-A`,                tone: 'neutral' },
          { actor: 'broker',   text: `receives, persists`,          tone: 'neutral' },
          { actor: 'broker',   text: `delivers MSG-A to consumer`,  tone: 'neutral' },
          { actor: 'consumer', text: `acks (pre-ack model)`,         tone: 'neutral' },
          { actor: 'consumer', text: `processes MSG-A`,              tone: 'ok' },
        ],
        delivered: 1, tone: 'good',
        verdict: `Delivered exactly once. No failures, no retries, no duplicates.`,
      },
      'at-least-once': {
        steps: [
          { actor: 'producer', text: `sends MSG-A`,                tone: 'neutral' },
          { actor: 'broker',   text: `receives, persists, acks to producer`, tone: 'neutral' },
          { actor: 'broker',   text: `delivers MSG-A to consumer`,  tone: 'neutral' },
          { actor: 'consumer', text: `processes MSG-A`,              tone: 'ok' },
          { actor: 'consumer', text: `acks to broker`,                tone: 'neutral' },
        ],
        delivered: 1, tone: 'good',
        verdict: `Delivered exactly once. The ack mechanism worked correctly; no retries were needed.`,
      },
      'exactly-once-ish': {
        steps: [
          { actor: 'producer', text: `sends MSG-A with producer_id + seq=42`, tone: 'neutral' },
          { actor: 'broker',   text: `receives, persists (first time for this seq)`, tone: 'neutral' },
          { actor: 'broker',   text: `delivers MSG-A to consumer`,           tone: 'neutral' },
          { actor: 'consumer', text: `checks dedup table — not seen`,        tone: 'neutral' },
          { actor: 'consumer', text: `process + insert dedup-row + ack in one transaction`, tone: 'ok' },
        ],
        delivered: 1, tone: 'good',
        verdict: `Delivered exactly once. The dedup mechanism added latency but no behavioral change in the happy path.`,
      },
    },
  },
  {
    id: 'ack-lost',
    label: 'Broker ack lost',
    description: `Producer sends MSG-A. Broker receives and persists it. But the ACK back to producer is lost in the network. Producer's timeout fires — what does each semantic do?`,
    outcomes: {
      'at-most-once': {
        steps: [
          { actor: 'producer', text: `sends MSG-A`, tone: 'neutral' },
          { actor: 'broker',   text: `receives, persists`, tone: 'neutral' },
          { actor: 'broker',   text: `sends ACK to producer`, tone: 'neutral' },
          { actor: 'network',  text: `⚠ ACK lost in transit`, tone: 'warn' },
          { actor: 'producer', text: `timeout — but at-most-once does NOT retry`, tone: 'neutral' },
          { actor: 'broker',   text: `delivers MSG-A to consumer (the original made it)`, tone: 'neutral' },
          { actor: 'consumer', text: `processes MSG-A`, tone: 'ok' },
        ],
        delivered: 1, tone: 'good',
        verdict: `Delivered once. The lost-ack didn't cause retry — original message did reach broker and propagated normally. (If the ORIGINAL message had also been lost, at-most-once would have silently lost it.)`,
      },
      'at-least-once': {
        steps: [
          { actor: 'producer', text: `sends MSG-A`, tone: 'neutral' },
          { actor: 'broker',   text: `receives, persists`, tone: 'neutral' },
          { actor: 'broker',   text: `sends ACK to producer`, tone: 'neutral' },
          { actor: 'network',  text: `⚠ ACK lost in transit`, tone: 'warn' },
          { actor: 'producer', text: `timeout — RETRIES, sends MSG-A again`, tone: 'warn' },
          { actor: 'broker',   text: `receives MSG-A AGAIN (no dedup) — now has 2 copies`, tone: 'error' },
          { actor: 'broker',   text: `delivers MSG-A copy 1 to consumer`, tone: 'neutral' },
          { actor: 'consumer', text: `processes — delivery #1`, tone: 'ok' },
          { actor: 'broker',   text: `delivers MSG-A copy 2 to consumer`, tone: 'neutral' },
          { actor: 'consumer', text: `processes — delivery #2 (DUPLICATE!)`, tone: 'error' },
        ],
        delivered: 2, tone: 'bad',
        verdict: `Delivered TWICE. Producer's retry created a duplicate at the broker. The consumer processed both copies. This is the classic at-least-once duplicate scenario — and the reason consumers MUST be idempotent in production.`,
      },
      'exactly-once-ish': {
        steps: [
          { actor: 'producer', text: `sends MSG-A with producer_id=P1, seq=42`, tone: 'neutral' },
          { actor: 'broker',   text: `receives, persists with (P1, 42)`, tone: 'neutral' },
          { actor: 'broker',   text: `sends ACK to producer`, tone: 'neutral' },
          { actor: 'network',  text: `⚠ ACK lost in transit`, tone: 'warn' },
          { actor: 'producer', text: `timeout — retries with (P1, 42)`, tone: 'warn' },
          { actor: 'broker',   text: `sees (P1, 42) already persisted → DROPS retry (idempotent producer)`, tone: 'ok' },
          { actor: 'broker',   text: `delivers MSG-A to consumer (one copy only)`, tone: 'neutral' },
          { actor: 'consumer', text: `processes MSG-A`, tone: 'ok' },
        ],
        delivered: 1, tone: 'good',
        verdict: `Delivered exactly once. The idempotent producer protocol (producer ID + sequence number) lets the broker recognize and drop the retry. This is one half of Kafka's "exactly-once semantics."`,
      },
    },
  },
  {
    id: 'consumer-crash',
    label: 'Consumer crash after processing',
    description: `Consumer reads MSG-A, processes it (sends an email, updates a database, charges a card), then crashes before sending the ack back to the broker. The broker's redelivery timer fires — what does each semantic do?`,
    outcomes: {
      'at-most-once': {
        steps: [
          { actor: 'producer', text: `sends MSG-A`, tone: 'neutral' },
          { actor: 'broker',   text: `delivers MSG-A to consumer`, tone: 'neutral' },
          { actor: 'consumer', text: `acks BEFORE processing (pre-ack)`, tone: 'neutral' },
          { actor: 'broker',   text: `marks MSG-A as acked, will not redeliver`, tone: 'neutral' },
          { actor: 'consumer', text: `processes MSG-A`, tone: 'neutral' },
          { actor: 'consumer', text: `⚠ crashes mid-processing`, tone: 'error' },
        ],
        delivered: 0, tone: 'bad',
        verdict: `LOST. The pre-ack model trades durability for performance — broker thinks the message was handled, but the consumer crashed before completing. No retry. This is at-most-once's failure mode: you can silently lose messages.`,
      },
      'at-least-once': {
        steps: [
          { actor: 'producer', text: `sends MSG-A`, tone: 'neutral' },
          { actor: 'broker',   text: `delivers MSG-A to consumer`, tone: 'neutral' },
          { actor: 'consumer', text: `processes MSG-A (sends email, charges card)`, tone: 'ok' },
          { actor: 'consumer', text: `⚠ crashes BEFORE sending ack`, tone: 'error' },
          { actor: 'broker',   text: `timeout — no ack received, redelivers MSG-A`, tone: 'warn' },
          { actor: 'consumer', text: `(restarted or other instance) processes MSG-A again`, tone: 'error' },
          { actor: 'consumer', text: `acks to broker`, tone: 'neutral' },
        ],
        delivered: 2, tone: 'bad',
        verdict: `Delivered TWICE. The card was charged twice; two emails went out. The user is unhappy. This is why consumers in at-least-once systems MUST be idempotent — either by natural design (UPSERTs, PUT semantics) or via deduplication.`,
      },
      'exactly-once-ish': {
        steps: [
          { actor: 'producer', text: `sends MSG-A with seq=42`, tone: 'neutral' },
          { actor: 'broker',   text: `delivers MSG-A to consumer`, tone: 'neutral' },
          { actor: 'consumer', text: `BEGIN TRANSACTION`, tone: 'neutral' },
          { actor: 'consumer', text: `INSERT INTO dedup_table (msg_id=42)`, tone: 'neutral' },
          { actor: 'consumer', text: `process side effect (update DB)`, tone: 'ok' },
          { actor: 'consumer', text: `⚠ crashes BEFORE COMMIT`, tone: 'error' },
          { actor: 'consumer', text: `transaction rolls back — dedup row + side effect gone`, tone: 'warn' },
          { actor: 'broker',   text: `timeout — redelivers MSG-A`, tone: 'warn' },
          { actor: 'consumer', text: `(restarted) BEGIN, checks dedup_table — not present (rolled back)`, tone: 'neutral' },
          { actor: 'consumer', text: `INSERT dedup-row, process, COMMIT`, tone: 'ok' },
          { actor: 'consumer', text: `acks to broker`, tone: 'neutral' },
        ],
        delivered: 1, tone: 'good',
        verdict: `Delivered exactly once. The atomic transaction (dedup-row + side effect + commit) is the trick: either everything happens or nothing does. The first attempt rolled back; the redelivery succeeded. The user was charged exactly once and the email was sent exactly once — because they were inside the same transaction.`,
      },
    },
  },
];

// ───────────────────────────────────────────────────────────────────────
// UI helpers
// ───────────────────────────────────────────────────────────────────────

const ACTOR_CONFIG = {
  producer: { label: 'PRODUCER', icon: Send,   color: 'text-fuchsia-300' },
  broker:   { label: 'BROKER',   icon: Server, color: 'text-lime-400' },
  consumer: { label: 'CONSUMER', icon: Cpu,    color: 'text-cyan-300' },
  network:  { label: 'NETWORK',  icon: AlertTriangle, color: 'text-amber-400' },
};

const TONE_STYLES = {
  neutral: { text: 'text-zinc-300',    icon: null },
  ok:      { text: 'text-lime-300',    icon: CheckCircle2 },
  warn:    { text: 'text-amber-300',   icon: AlertTriangle },
  error:   { text: 'text-rose-300',    icon: X },
};

function StageHeader() {
  return (
    <div className="grid grid-cols-3 gap-2 mb-3">
      {[ACTOR_CONFIG.producer, ACTOR_CONFIG.broker, ACTOR_CONFIG.consumer].map((a, i) => {
        const Icon = a.icon;
        return (
          <div key={i} className="border border-zinc-800 bg-zinc-900/40 p-2 flex items-center justify-center gap-2">
            <Icon size={13} className={a.color} />
            <span className={`text-[10.5px] tracking-[0.25em] uppercase font-semibold ${a.color}`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {a.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function DeliverySimulator() {
  const [scenarioIdx, setScenarioIdx] = useState(0);
  const [semantic, setSemantic] = useState(null);

  const scenario = SCENARIOS[scenarioIdx];
  const outcome = semantic ? scenario.outcomes[semantic] : null;

  const switchScenario = (i) => {
    setScenarioIdx(i);
    setSemantic(null);
  };

  return (
    <div className="my-6 border border-fuchsia-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-fuchsia-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-fuchsia-300" />
          <span className="text-fuchsia-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · delivery semantics simulator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Scenario tabs */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => switchScenario(i)}
              className={`px-3 py-1.5 border text-[11.5px] transition-colors ${
                i === scenarioIdx
                  ? 'border-fuchsia-300 bg-fuchsia-300/15 text-fuchsia-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-fuchsia-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {i + 1}. {s.label}
            </button>
          ))}
        </div>

        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13px] leading-relaxed italic">
          {scenario.description}
        </div>

        {/* Stage header */}
        <StageHeader />

        {/* Semantic picker */}
        <div className="mb-4">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            pick a delivery semantic
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {SEMANTICS.map(s => (
              <button key={s.id} onClick={() => setSemantic(s.id)}
                className={`px-3 py-2 border text-[11.5px] transition-colors ${
                  semantic === s.id
                    ? 'border-fuchsia-300 bg-fuchsia-300/15 text-fuchsia-200 font-semibold'
                    : 'border-zinc-700 text-zinc-400 hover:border-fuchsia-300/50 hover:text-zinc-200'
                }`}
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Timeline */}
        {outcome ? (
          <>
            <div className="border border-zinc-800 bg-zinc-950/60 overflow-hidden mb-3">
              <div className="bg-zinc-900 px-3 py-1.5 text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                event timeline
              </div>
              <div className="divide-y divide-zinc-800/60">
                {outcome.steps.map((step, i) => {
                  const actor = ACTOR_CONFIG[step.actor];
                  const tone = TONE_STYLES[step.tone];
                  const ToneIcon = tone.icon;
                  return (
                    <div key={i} className="grid grid-cols-[36px_1fr_2.5fr] gap-2 py-1.5 px-2 items-start">
                      <div className="text-zinc-600 text-[10px] text-right pt-0.5"
                        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                        {String(i + 1).padStart(2, '0')}
                      </div>
                      <div className={`text-[10px] tracking-[0.2em] uppercase font-semibold ${actor.color} pt-0.5 flex items-center gap-1`}
                        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                        {actor.label}
                      </div>
                      <div className={`text-[11.5px] leading-snug flex items-start gap-1.5 ${tone.text}`}
                        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                        {ToneIcon && <ToneIcon size={11} className="shrink-0 mt-0.5" />}
                        <span>{step.text}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Outcome */}
            <div className={`border p-4 ${
              outcome.tone === 'good'
                ? 'border-lime-400/60 bg-lime-400/10'
                : 'border-rose-400/60 bg-rose-400/10'
            }`}>
              <div className={`text-[11px] tracking-[0.25em] uppercase font-semibold mb-2 flex items-center gap-2 ${
                outcome.tone === 'good' ? 'text-lime-400' : 'text-rose-400'
              }`} style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {outcome.tone === 'good' ? <CheckCircle2 size={13} /> : <AlertTriangle size={13} />}
                outcome · delivered {outcome.delivered === 0 ? 'ZERO times (LOST)' : `${outcome.delivered} time${outcome.delivered === 1 ? '' : 's'}`}
              </div>
              <div className="text-zinc-200 text-[13px] leading-relaxed">
                {outcome.verdict}
              </div>
            </div>
          </>
        ) : (
          <div className="border border-zinc-800 bg-zinc-900/40 p-4 text-zinc-400 text-[12.5px] italic text-center">
            Pick a delivery semantic above to see how this scenario plays out.
          </div>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section02_Delivery() {
  return (
    <>
      <SectionLabel>section 02</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Delivery semantics — the exactly-once-ish reality
      </h2>
      <P>
        Section 01 set up two patterns: queues for work, streams for events. This section
        answers the question every team eventually asks: "when our system says it delivered a
        message, what does that actually mean?" The honest answer is one of three things, and
        the third one — exactly-once — is harder than it sounds. The fix is not a protocol
        trick; it is a discipline applied at every consumer.
      </P>

      <H2 num="◇ 01">The three semantic levels</H2>
      <Code id="semantics-overview" lang="text">{`AT-MOST-ONCE      The message may be delivered ZERO or ONE times.
                  Never delivered twice. May be LOST.

                  Use case: telemetry, metrics samples — losing one is fine,
                  duplicating one would skew the count.

AT-LEAST-ONCE     The message will be delivered ONE or MORE times.
                  Never lost. May be DUPLICATED.

                  Use case: 90% of production workloads. Combined with
                  idempotent consumers, behaves like exactly-once.

EXACTLY-ONCE      The message is delivered EXACTLY ONE TIME.
                  Never lost. Never duplicated.

                  Use case: financial transactions, anything where a duplicate
                  causes real-world harm. Achievable WITHIN a closed system
                  boundary (Kafka EOS); back to at-least-once the moment you
                  cross to an external system.`}</Code>

      <H2 num="◇ 02">Why exactly-once is theoretically impossible across systems</H2>
      <P>
        Atlas 21 §01 covered the two generals problem: across an unreliable network, no finite
        protocol can guarantee that both sides agree exactly. The same impossibility applies
        here. Producer sends MSG; broker may or may not receive it; broker sends ACK; producer
        may or may not receive it. Both sides must commit AND know the other committed — and
        that knowledge has the same impossibility result.
      </P>
      <P>
        The practical workaround: do not try to make exactly-once impossible-true. Make it
        practically-true by being:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li><strong className="text-fuchsia-300">At-least-once at the protocol level</strong> — retry until acked</li>
        <li><strong className="text-fuchsia-300">Idempotent at the application level</strong> — duplicates have no effect</li>
        <li><strong className="text-fuchsia-300">Net result</strong> — observable behavior is "delivered exactly once"</li>
      </ul>
      <Callout kind="stream" title="THE 'EXACTLY-ONCE-ISH' MENTAL MODEL">
        Almost every "exactly-once" claim in industry is really "at-least-once with idempotent
        consumers." Kafka&apos;s Exactly-Once Semantics achieves this within Kafka&apos;s
        boundary by combining idempotent producers, transactional writes across partitions,
        and atomic offset commits — but the moment a consumer&apos;s side-effect goes to an
        EXTERNAL system (DB, email service, payment processor), Kafka&apos;s guarantee ends
        and idempotency on YOUR side starts.
      </Callout>

      <H2 num="◇ 03">At-most-once — fire and forget</H2>
      <P>
        At-most-once is what you get when nobody retries. Producer sends; if it gets through,
        great; if it does not, the message is lost. Consumers ack BEFORE processing (or never
        ack at all), so even successful delivery may be lost if the consumer crashes mid-work.
      </P>
      <Code id="amo-tradeoff" lang="text">{`USE AT-MOST-ONCE WHEN:
  - You'd rather drop a message than have a duplicate
  - The data has continuous nature — telemetry, metrics, sensor readings
  - "How fast?" matters more than "how complete?"

EXAMPLES:
  - UDP-based metrics (statsd default)
  - Click tracking where 1% loss is acceptable
  - Sensor data streams where the next reading is in 100ms anyway

DO NOT USE FOR:
  - Anything with a financial or legal trail
  - Anything that triggers a user-visible action
  - Anything that updates a database
  - Anything where you'd be debugging a missing event later`}</Code>

      <H2 num="◇ 04">At-least-once — the practical default</H2>
      <P>
        At-least-once is what most queue and stream brokers default to. The protocol:
      </P>
      <Code id="alo-protocol" lang="text">{`PRODUCER          BROKER                            CONSUMER
  │                  │                                  │
  ├── send(MSG) ──►  │                                  │
  │                  ├── persist(MSG)                   │
  ◄── ACK ───────────┤                                  │
  │                  │                                  │
  │                  ├── deliver(MSG) ─────────────────►│
  │                  │                                  ├── process(MSG)
  │                  ◄── ACK ──────────────────────────┤
  │                  ├── mark MSG as acked              │
  │                  │                                  │

If ANY ack is lost or times out, the prior step retries.
Result: messages always reach their destination → AT-LEAST-ONCE.
But each retry creates the potential for a DUPLICATE.

THE TIMELINE OF A TYPICAL DUPLICATE:
  Consumer processes MSG → updates DB → ack queued in TCP buffer
  Consumer process dies before TCP buffer flushes the ack
  Broker times out → redelivers MSG to a different consumer
  Other consumer processes MSG → updates DB AGAIN`}</Code>
      <P>
        At-least-once is fine — as long as your consumer handles duplicates correctly. That is
        the idempotent-consumer pattern.
      </P>

      <H2 num="◇ 05">The idempotent consumer pattern — the practical workhorse</H2>
      <P>
        Atlas 19 §02 covered idempotency keys for HTTP. The pattern at the consumer level is
        the same shape: every message has a unique ID, the consumer tracks which IDs it has
        processed, duplicates are detected and skipped (or processed harmlessly).
      </P>
      <Code id="idempotent-consumer" lang="sql">{`-- Option 1: dedup table (explicit)
CREATE TABLE processed_messages (
  message_id  TEXT PRIMARY KEY,
  processed_at TIMESTAMP DEFAULT now()
);

-- In the consumer, wrap processing in a transaction:
BEGIN;
  INSERT INTO processed_messages (message_id) VALUES ($1);
  -- If we get here, this is the FIRST time we've seen this ID.
  -- If the INSERT failed with unique-violation, it's a duplicate — SKIP.

  -- Do the side effect:
  UPDATE accounts SET balance = balance - 50 WHERE user_id = $2;
COMMIT;
-- Then ack the broker. If we crash before ack, broker redelivers,
-- the INSERT fails next time, the consumer skips processing.

-- Option 2: natural idempotency (better when applicable)
-- Design operations as PUT-style: setting state to X is the same whether
-- you do it once or twice. UPSERTs are naturally idempotent.

INSERT INTO user_profiles (user_id, name) VALUES ($1, $2)
  ON CONFLICT (user_id) DO UPDATE SET name = EXCLUDED.name;
-- Running this twice has the same effect as running it once.`}</Code>
      <Callout kind="tip" title="WHAT MAKES THE TRANSACTION CRUCIAL">
        The atomic transaction is the whole point. Insert the dedup row AND do the side effect
        IN THE SAME TRANSACTION. If the consumer crashes anywhere between them, the
        transaction rolls back — dedup row gone, side effect gone — and the redelivery starts
        clean. If you split them ("first check dedup table; then if not present, do the side
        effect; then insert dedup row"), a crash between steps 2 and 3 causes a duplicate side
        effect on retry. Atomic-or-not is the difference between exactly-once-ish and
        at-least-once with a fancy table.
      </Callout>

      <H2 num="◇ 06">Kafka&apos;s Exactly-Once Semantics — how it actually works</H2>
      <P>
        Kafka&apos;s EOS (introduced in 2017) is the most production-deployed implementation
        of exactly-once-ish. It works by combining three mechanisms:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-fuchsia-300">Idempotent producer.</strong> Each producer is assigned a unique <Kbd>producer_id</Kbd>. Each message gets a monotonic <Kbd>sequence_number</Kbd>. The broker tracks the latest sequence number per producer-id+partition and rejects any retry of an already-stored sequence — effectively dedup at the broker.
        </li>
        <li>
          <strong className="text-fuchsia-300">Transactional writes across partitions.</strong> A producer can begin a transaction, write to multiple partitions, and commit atomically. Either all writes appear or none do. Consumers can be configured (<Kbd>isolation.level=read_committed</Kbd>) to ignore uncommitted writes.
        </li>
        <li>
          <strong className="text-fuchsia-300">Atomic offset commits.</strong> Consumers can commit their offset as part of the same transaction that produces their downstream output. Read-process-write becomes one atomic unit — process MSG, write derived MSG to output topic, commit input offset, all-or-nothing.
        </li>
      </ul>
      <Code id="kafka-eos-pattern" lang="text">{`THE READ-PROCESS-WRITE PATTERN IN KAFKA EOS:

  BEGIN TRANSACTION
    consumer.poll() → MSG-A
    derived = transform(MSG-A)
    producer.send(output-topic, derived)
    producer.sendOffsetsToTransaction(consumer.position())
  COMMIT

If anything fails between BEGIN and COMMIT, the transaction aborts:
  - No derived message appears on output-topic
  - The consumer's offset is NOT advanced
  - On retry, the same MSG-A is processed again

If COMMIT succeeds:
  - Derived appears atomically
  - Offset commits atomically
  - No way to have one without the other

THE LIMIT: Kafka EOS only protects the Kafka boundary. If your transform
makes an HTTP call or DB write, that side effect can run twice if the
transaction is retried — back to at-least-once on the external system.`}</Code>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 07">See same failure, three different outcomes</H2>
      <P>
        Three scenarios, three semantics. Pick a scenario, then pick a semantic — watch the
        timeline of events at each actor (producer, broker, consumer) and the final outcome.
        The happy-path scenario shows all three give the same result. The two failure
        scenarios are where they diverge — and where the lesson lives.
      </P>

      <DeliverySimulator />

      <H2 num="◇ 08">When you fall back to at-least-once</H2>
      <P>
        The moment your consumer&apos;s side effect crosses a boundary that Kafka EOS does not
        cover, you are back at at-least-once for that operation. The common cases:
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-amber-300">Writing to a different database</strong> — Postgres, MySQL, Redis, whatever — Kafka cannot transactionally coordinate with them. Need idempotent SQL or a dedup table.</li>
        <li><strong className="text-amber-300">Calling an HTTP API</strong> — payment processors, email services, SMS providers. Use idempotency keys (Atlas 19 §02).</li>
        <li><strong className="text-amber-300">Writing to S3 / GCS</strong> — object stores. Use deterministic keys so retries overwrite the same object instead of creating duplicates.</li>
        <li><strong className="text-amber-300">Publishing to a non-Kafka queue</strong> — RabbitMQ, SQS. They have their own dedup mechanisms; use them.</li>
        <li><strong className="text-amber-300">Anything that involves human-visible action</strong> — sending an email, charging a card. The user will notice the duplicate. Idempotency is non-optional.</li>
      </ul>
      <P>
        The general rule: <strong className="text-fuchsia-300">Kafka EOS protects within Kafka. Idempotent-consumer-pattern protects across boundaries.</strong> Most production systems need both.
      </P>

      <H2 num="◇ 09">The dual-write problem — preview</H2>
      <P>
        One scenario the idempotent consumer pattern alone does not solve: when you need to
        write to a database AND publish an event AT THE SAME TIME — your service updates the
        orders table and announces "OrderCreated" to the rest of the system. The bug:
      </P>
      <Code id="dual-write-bug" lang="text">{`def handle_order(order):
    db.insert_order(order)           # step 1 — writes to DB
    queue.publish('OrderCreated', order)  # step 2 — publishes event

    # ⚠ Between steps 1 and 2, the process can crash.
    # DB has the order. Queue has nothing. Other services don't know.
    # When the process restarts, it has no way to know step 1 succeeded.

# Or worse, swap the order:
def handle_order(order):
    queue.publish('OrderCreated', order)  # step 1 — publishes
    db.insert_order(order)                # step 2 — writes to DB

    # ⚠ Between steps 1 and 2, the process can crash.
    # Queue has the event. DB has NO order. Downstream services see a ghost.`}</Code>
      <P>
        No retry strategy fixes this. Both steps can succeed; both can fail; one can succeed
        while the other fails — and you cannot tell which from the consumer side. The solution
        is the OUTBOX PATTERN — and it is the topic of section 04.
      </P>

      <H2 num="◇ 10">Hardening checklist for delivery semantics</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Default to at-least-once + idempotent consumers (not at-most-once "for performance")</li>
        <li>✓ Every consumer has an explicit idempotency strategy — dedup table, UPSERT, deterministic ID</li>
        <li>✓ Dedup-table + side-effect wrapped in the SAME database transaction (atomic-or-not)</li>
        <li>✓ At-most-once used ONLY for telemetry and metrics — never for state-changing operations</li>
        <li>✓ Kafka EOS enabled where applicable (<Kbd>enable.idempotence=true</Kbd>, <Kbd>isolation.level=read_committed</Kbd>)</li>
        <li>✓ External-system writes (HTTP, SMTP, S3) use idempotency keys explicitly</li>
        <li>✓ Dead-letter queue configured for messages that fail repeatedly — investigate, don&apos;t silently drop</li>
        <li>✓ Consumer lag monitored — large lag often hides a bug that triggers redeliveries</li>
        <li>✓ Duplicate-handling tested explicitly — chaos test that kills consumers mid-processing</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Section 03 covers what happens when streams grow without bound — the natural fate of
        any append-only log. The answer is log compaction: keep only the latest value per key,
        garbage-collect the rest, and use it as the foundation for event sourcing and CQRS.
      </Callout>
    </>
  );
}
