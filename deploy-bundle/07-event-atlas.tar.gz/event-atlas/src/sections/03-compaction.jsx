/* Section 03 — Log Compaction and Event Sourcing.
 *
 * Prose + Log Compaction Visualizer.
 *
 * The simulator: user adds events with keys (user_42, user_43, ...) and
 * auto-incrementing values. The full log grows append-only. Click
 * "Run compaction" — obsolete events (same key, earlier offset) get
 * struck through; the compacted view appears below showing only the
 * latest value per key. Tombstones (null-value events) cause the key to
 * disappear from the compacted view entirely.
 *
 * The teaching aim: compaction is the trick that lets streams be
 * permanent without growing forever. Latest-per-key is the canonical
 * shape for event-sourced state.
 *
 * All prose strings use backticks (template literals).
 */

import { useState } from 'react';
import { Sparkles, Plus, Trash2, RotateCcw, Layers, Scissors, Skull } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Log Compaction Visualizer
// ───────────────────────────────────────────────────────────────────────

const KEYS = ['user_42', 'user_43', 'user_44', 'user_45'];

function LogCompactionVisualizer() {
  const [log, setLog] = useState([]);          // [{ key, value (null=tombstone), seq }]
  const [counter, setCounter] = useState(100); // auto-increment value
  const [compacted, setCompacted] = useState(null); // [{ key, value, seq }] | null

  const addEvent = (key) => {
    setLog(prev => [...prev, { key, value: counter, seq: prev.length }]);
    setCounter(v => v + 50);
    setCompacted(null);  // any new event invalidates the compaction view
  };

  const addTombstone = (key) => {
    setLog(prev => [...prev, { key, value: null, seq: prev.length }]);
    setCompacted(null);
  };

  const runCompaction = () => {
    // For each key, find the latest event
    const latestByKey = new Map();
    log.forEach(e => latestByKey.set(e.key, e));
    // Drop tombstones (in real Kafka, kept until delete.retention.ms — we simplify)
    const result = Array.from(latestByKey.values()).filter(e => e.value !== null);
    // Preserve insertion order by seq
    result.sort((a, b) => a.seq - b.seq);
    setCompacted(result);
  };

  const reset = () => {
    setLog([]);
    setCompacted(null);
    setCounter(100);
  };

  // For full log: figure out which events are obsolete (have a later same-key)
  const obsoleteSeqs = new Set();
  for (let i = 0; i < log.length; i++) {
    for (let j = i + 1; j < log.length; j++) {
      if (log[i].key === log[j].key) { obsoleteSeqs.add(log[i].seq); break; }
    }
  }

  // Color by key
  const KEY_COLORS = {
    'user_42': { border: 'border-fuchsia-300/70', bg: 'bg-fuchsia-300/15', text: 'text-fuchsia-100' },
    'user_43': { border: 'border-cyan-300/70',     bg: 'bg-cyan-300/15',     text: 'text-cyan-100' },
    'user_44': { border: 'border-lime-300/70',     bg: 'bg-lime-300/15',     text: 'text-lime-100' },
    'user_45': { border: 'border-amber-300/70',    bg: 'bg-amber-300/15',    text: 'text-amber-100' },
  };

  return (
    <div className="my-6 border border-fuchsia-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-fuchsia-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-fuchsia-300" />
          <span className="text-fuchsia-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · log compaction visualizer
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Producer controls */}
        <div className="border border-zinc-800 bg-zinc-900/40 p-3 mb-3">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            produce events
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-2">
            {KEYS.map(k => {
              const c = KEY_COLORS[k];
              return (
                <button key={k} onClick={() => addEvent(k)}
                  className={`px-2 py-1.5 border ${c.border} ${c.bg} ${c.text} hover:opacity-80 transition-opacity text-[10.5px] font-semibold flex items-center justify-center gap-1`}
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  <Plus size={10} /> {k}={counter}
                </button>
              );
            })}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {KEYS.map(k => (
              <button key={k} onClick={() => addTombstone(k)}
                className="px-2 py-1 border border-rose-400/60 text-rose-300 hover:bg-rose-400/10 transition-colors text-[10px] flex items-center justify-center gap-1"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <Skull size={9} /> tombstone {k}
              </button>
            ))}
          </div>
        </div>

        {/* Full log */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-3 mb-3">
          <div className="flex items-center justify-between mb-2">
            <div className="text-zinc-400 text-[10px] tracking-[0.25em] uppercase flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <Layers size={11} /> full log (append-only)
            </div>
            <div className="text-zinc-500 text-[10px]"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {log.length} event{log.length === 1 ? '' : 's'}
            </div>
          </div>
          <div className="min-h-[70px] flex flex-wrap gap-1.5">
            {log.length === 0 ? (
              <span className="text-zinc-600 text-[11px] italic"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                empty — click any "produce" button to start
              </span>
            ) : (
              log.map(e => {
                const c = KEY_COLORS[e.key];
                const obsolete = obsoleteSeqs.has(e.seq);
                const isTombstone = e.value === null;
                return (
                  <div key={e.seq}
                    className={`shrink-0 px-2 py-1 border ${c.border} ${obsolete ? 'opacity-30' : c.bg} ${c.text} ${isTombstone ? 'border-dashed' : ''}`}
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    <div className={`text-[10.5px] font-bold ${obsolete ? 'line-through' : ''}`}>
                      {e.key}={isTombstone ? <span className="italic">null</span> : e.value}
                    </div>
                    <div className="text-[8.5px] opacity-70">off={e.seq}</div>
                  </div>
                );
              })
            )}
          </div>
          {log.length > 0 && (
            <div className="text-zinc-600 text-[10px] mt-2 pt-2 border-t border-zinc-800"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {obsoleteSeqs.size} obsolete · {log.length - obsoleteSeqs.size} would survive compaction
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap gap-2 mb-3">
          <button onClick={runCompaction} disabled={log.length === 0}
            className="px-3 py-1.5 border border-fuchsia-300 bg-fuchsia-300/10 text-fuchsia-200 hover:bg-fuchsia-300/20 disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-[11.5px] font-semibold flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Scissors size={11} /> run compaction
          </button>
          <button onClick={reset}
            className="px-3 py-1.5 border border-zinc-700 text-zinc-400 hover:text-zinc-200 hover:border-zinc-500 transition-colors text-[11px] flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Trash2 size={11} /> reset
          </button>
        </div>

        {/* Compacted view */}
        {compacted && (
          <div className="border border-lime-400/40 bg-lime-400/5 p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="text-lime-400 text-[10px] tracking-[0.25em] uppercase font-semibold flex items-center gap-1.5"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <Scissors size={11} /> compacted view · latest-per-key
              </div>
              <div className="text-lime-300 text-[10px]"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {compacted.length} retained / {log.length} original
              </div>
            </div>
            {compacted.length === 0 ? (
              <div className="text-zinc-500 text-[11px] italic"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                Nothing retained — all events either obsolete or tombstoned away.
              </div>
            ) : (
              <div className="flex flex-wrap gap-1.5 mb-2">
                {compacted.map(e => {
                  const c = KEY_COLORS[e.key];
                  return (
                    <div key={e.seq}
                      className={`shrink-0 px-2 py-1 border ${c.border} ${c.bg} ${c.text}`}
                      style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                      <div className="text-[10.5px] font-bold">{e.key}={e.value}</div>
                      <div className="text-[8.5px] opacity-70">off={e.seq}</div>
                    </div>
                  );
                })}
              </div>
            )}
            <div className="text-zinc-300 text-[11.5px] leading-relaxed mt-1 pt-2 border-t border-lime-400/20">
              Compaction kept the latest value for each surviving key. Tombstoned keys were dropped entirely. Original offsets preserved — consumers reading from offset 0 still see exactly one event per surviving key, in original order.
            </div>
          </div>
        )}

        {/* Helper text */}
        {!compacted && log.length === 0 && (
          <Callout kind="info" title="HOW TO USE">
            Click any "produce" button to add an event with that key and an auto-incrementing
            value. Add multiple events for the same key — older ones become obsolete (struck
            through). Click "tombstone" to mark a key for deletion. Then click "run compaction"
            to see what survives.
          </Callout>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section03_Compaction() {
  return (
    <>
      <SectionLabel>section 03</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Log compaction — keeping streams forever without growing forever
      </h2>
      <P>
        Append-only logs solve the "I need history" problem from section 01 (streams replay,
        queues do not). But "append-only" means "grows forever." For a busy stream — say, a
        million events per day at a few hundred bytes each — that is hundreds of gigabytes a
        year, indefinitely. Two strategies handle this. Time-based retention is the simple
        one. Log compaction is the clever one — and it is the foundation of event sourcing.
      </P>

      <H2 num="◇ 01">Why streams grow forever — and the two strategies</H2>
      <Code id="retention-strategies" lang="text">{`THE PROBLEM:
  Producer pushes 10K events/sec to a stream.
  At 200 bytes/event, that's 2 MB/sec, 170 GB/day, 60 TB/year.
  After two years: 120 TB. Forever after that: bigger.

  Streams are valuable because they are HISTORY. But you cannot keep
  everything forever — disk has limits, scans get slow, storage costs.

TWO STRATEGIES:

  1. TIME-BASED RETENTION
       "Delete events older than N days."
       Simple. Predictable disk use. The default for Kafka, Kinesis, Pulsar.
       Trade: you lose the deep history.

  2. KEY-BASED COMPACTION
       "Keep at most ONE event per key — the latest one."
       Older events for the same key are GARBAGE-COLLECTED.
       Bounded by the number of distinct keys, not by time.
       Trade: you can't see the history of a key — only its current value.

You can use ONE per topic. Time-based is the right default for fact streams
(every event matters individually). Compaction is the right default for
state streams (only the latest matters per key).`}</Code>

      <H2 num="◇ 02">Time-based retention — the simple option</H2>
      <P>
        Kafka&apos;s default. You configure a window — typically 7 days, sometimes 30, rarely
        90 — and the broker periodically deletes segments (files) older than that. Cheap to
        run, predictable disk consumption, but the deep history is gone.
      </P>
      <Code id="time-retention" lang="text">{`# Kafka topic config — keep 7 days, max 100 GB
kafka-configs --alter --topic events \\
  --add-config retention.ms=604800000,retention.bytes=107374182400

# After 7 days, older events are deleted in segment-file chunks.
# Replay-from-zero is impossible for data older than 7 days.

USE TIME-BASED RETENTION FOR:
  Streams where every event has standalone value:
    - Order placed, payment authorized, shipment dispatched
    - User clicks, page views, search queries
    - Metric samples, log entries
  You want them for the retention window, then they're done.`}</Code>

      <H2 num="◇ 03">Log compaction — the clever option</H2>
      <P>
        Compaction works because many event streams encode STATE changes per key. The "latest
        balance for user_42" is more interesting than "every balance user_42 has ever had." If
        you only care about the current value, you only need to keep the latest event for each
        key. Older events for the same key are obsolete — compaction garbage-collects them.
      </P>
      <Code id="compaction-mechanics" lang="text">{`THE LOG BEFORE COMPACTION:

  off  key       value
  ───  ───       ─────
  0    user_42   balance=100
  1    user_43   balance=50
  2    user_42   balance=150   ← supersedes offset 0
  3    user_44   balance=75
  4    user_42   balance=200   ← supersedes offset 0 and 2

THE LOG AFTER COMPACTION:

  off  key       value
  ───  ───       ─────
  1    user_43   balance=50
  3    user_44   balance=75
  4    user_42   balance=200

Offsets are preserved (consumers reading from offset 0 see the surviving
events at their original offsets). Obsolete events are physically deleted.
The log now occupies less disk; new consumers reading from 0 see the
current state of each key — and only that.`}</Code>
      <Callout kind="stream" title="COMPACTION RUNS IN THE BACKGROUND, NOT IN REAL TIME">
        Compaction is a periodic background task — Kafka triggers it when a configurable
        "dirty ratio" of obsolete events exceeds a threshold (default 50%). In the meantime,
        the full log still exists on disk. Consumers reading the tail of the log see every
        event; consumers reading older segments see compacted versions. The trade is between
        write throughput (real-time compaction would be expensive) and storage efficiency
        (the more obsolete data, the more you save).
      </Callout>

      <H2 num="◇ 04">Tombstones — how delete works in a compacted topic</H2>
      <P>
        How do you DELETE a key from a compacted topic? You cannot delete; you can only append.
        The solution: append a TOMBSTONE — a message with the same key but a NULL value. The
        next compaction sees the tombstone and removes the key entirely. The tombstone itself
        stays in the log for a configurable window (<Kbd>delete.retention.ms</Kbd>, default 24
        hours) so downstream consumers have a chance to see it; after that, the tombstone is
        also compacted away.
      </P>
      <Code id="tombstones" lang="python">{`# Producer side — delete user_42 from a compacted topic
producer.send(
    topic="users",
    key="user_42",
    value=None,        # ← the null value IS the tombstone
)

# Consumer side — must handle null-value messages
for record in consumer:
    if record.value is None:
        # tombstone — this key was deleted
        delete_user_from_local_view(record.key)
    else:
        # normal upsert
        upsert_user(record.key, record.value)`}</Code>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 05">Compact a log live</H2>
      <P>
        Add events with four sample keys. Each new event for the same key obsoletes the older
        one — watch them go translucent and struck-through in the full log. Drop a tombstone
        on a key to mark it for deletion. Then click "run compaction" — the compacted view
        appears below, showing only the latest value per key with original offsets preserved.
      </P>

      <LogCompactionVisualizer />

      <H2 num="◇ 06">Event sourcing — storing events, deriving state</H2>
      <P>
        Compaction enables a deeper pattern: event sourcing. Instead of storing the CURRENT
        state of an entity in a database and overwriting it on every change, store the SEQUENCE
        of events that produced it. The current state becomes a derived view that you compute
        by replaying events.
      </P>
      <Code id="event-sourcing" lang="text">{`TRADITIONAL CRUD:                  EVENT-SOURCED:

  accounts table:                    events log (compacted by account_id):
    id    balance                      seq  key       event
    42    250                          0    acc_42    AccountOpened{init=0}
    43    100                          1    acc_42    Deposit{amount=200}
                                       2    acc_43    AccountOpened{init=0}
  UPDATE accounts                      3    acc_42    Withdrawal{amount=50}
  SET balance = balance - 50           4    acc_42    Deposit{amount=100}
  WHERE id = 42                        5    acc_43    Deposit{amount=100}
                                       6    acc_42    Deposit{amount=0}  ← keepalive (compact-friendly)
  (old value lost)                                    
                                       to read balance for acc_42:
                                         replay events for acc_42 → 0+200-50+100 = 250

ADVANTAGES OF EVENT SOURCING:

  ✓ Full history is the natural representation, not an audit-log bolt-on
  ✓ Rebuild any view by replaying — analytics, fraud detection, ML training
  ✓ Time-travel: "what did the state look like on Tuesday at 3pm?"
  ✓ Bugs in business logic can be replayed against the same events

TRADEOFFS:

  ✗ Reading current state requires replay (mitigated by snapshots — below)
  ✗ Schema changes to events are forever (need careful versioning)
  ✗ Eventual consistency is the norm, not the exception
  ✗ Higher initial complexity than CRUD`}</Code>

      <H2 num="◇ 07">Snapshots — when replay gets expensive</H2>
      <P>
        Event sourcing breaks down when "replay from the beginning" gets too slow. If an
        account has 10 million events, computing its current balance by replaying all of them
        takes minutes. The solution is periodic SNAPSHOTS:
      </P>
      <Code id="snapshots" lang="text">{`PERIODIC SNAPSHOT PATTERN:

  events log (compacted):                snapshots table (regular DB):
    seq  key       event                   id    balance   snapshot_seq
    ...                                    42    250       1000000
    1000000  acc_42  ...
    1000001  acc_42  Deposit{50}
    1000002  acc_42  Withdrawal{20}

READING current state of acc_42:
  1. Load snapshot:    balance = 250, snapshot_seq = 1000000
  2. Replay events from seq > 1000000:
       seq 1000001 → +50  → 300
       seq 1000002 → -20  → 280
  3. Return 280

The snapshot reduces replay work from "every event ever" to "events since
the last snapshot." Tune snapshot frequency to balance read latency
(infrequent snapshots → slow reads) against snapshot cost (frequent
snapshots → write overhead).`}</Code>

      <H2 num="◇ 08">CQRS — separating reads from writes</H2>
      <P>
        Command Query Responsibility Segregation builds on event sourcing. The WRITE model
        is the event log — append-only, well-validated, single source of truth. The READ
        models are denormalized views derived FROM the event log — optimized for the queries
        each consumer needs. Different consumers can have completely different views of the
        same events.
      </P>
      <Code id="cqrs" lang="text">{`                       ┌─────────────────┐
   write API ──────►   │   EVENT LOG     │   (write model — append-only)
                       │ (compacted)     │
                       └────────┬────────┘
                                │
                ┌───────────────┼───────────────┬─────────────────┐
                ▼               ▼               ▼                 ▼
        ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
        │ CURRENT      │  │ SEARCH       │  │ ANALYTICS    │  │ ML FEATURE   │
        │ STATE TABLE  │  │ INDEX        │  │ WAREHOUSE    │  │ STORE        │
        │ (Postgres)   │  │ (Elastic)    │  │ (Snowflake)  │  │ (Feast)      │
        └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘
              ▲                  ▲                 ▲                 ▲
              │                  │                 │                 │
         read API           search API        BI dashboards    ML training

EACH READ MODEL is derived independently from the same event log.
Adding a new read model (next quarter's "fraud features" view) is just
adding a new consumer that replays from offset 0 and builds its own
derived state. No coordination with existing consumers. No write-side
changes.`}</Code>

      <H2 num="◇ 09">When compaction is right — and when it is wrong</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-lime-400">RIGHT for state streams.</strong> User profiles, account balances, configuration values, feature flags, anything where the LATEST value per key is what consumers want. Bounded disk usage; new consumers can bootstrap their state from compaction-from-zero.
        </li>
        <li>
          <strong className="text-lime-400">RIGHT for change-data-capture (CDC).</strong> Database tables published as compacted streams (Debezium et al.) — the stream is a "this is the current state of the table" feed where consumers can rebuild a replica of the source by reading from offset 0.
        </li>
        <li>
          <strong className="text-rose-400">WRONG for fact streams.</strong> Orders, page views, clicks, log entries — each event has standalone value; you cannot compact two clicks into one. Use time-based retention.
        </li>
        <li>
          <strong className="text-rose-400">WRONG for high-throughput, low-cardinality streams.</strong> If you have a million events per second across only a few hundred keys, compaction will repeatedly garbage-collect the same data — wasting CPU without saving disk meaningfully (the working set is small).
        </li>
        <li>
          <strong className="text-amber-300">CAREFUL with key skew.</strong> If 90% of your events are for 10 hot keys, compaction&apos;s effectiveness collapses for those keys (the latest is always being replaced). For the cold tail, compaction works great. Monitor the per-key compaction ratio.
        </li>
      </ul>

      <H2 num="◇ 10">Hardening checklist for compaction and event sourcing</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Retention policy per topic chosen deliberately: time-based, key-compacted, or both (Kafka supports <Kbd>cleanup.policy=compact,delete</Kbd>)</li>
        <li>✓ Tombstone retention (<Kbd>delete.retention.ms</Kbd>) longer than your slowest consumer&apos;s lag — otherwise deletes get missed</li>
        <li>✓ Compaction-trigger ratio tuned (<Kbd>min.cleanable.dirty.ratio</Kbd>) — too eager wastes CPU, too lazy wastes disk</li>
        <li>✓ Event-sourced systems use snapshot-and-replay reads, not "replay from zero" for hot keys</li>
        <li>✓ Event schemas versioned and forward-compatible — events from 5 years ago must still parse</li>
        <li>✓ Schema registry (Confluent / Apicurio) in front of producers — no untyped JSON in event streams</li>
        <li>✓ Consumer recovery procedure documented: how to rebuild a read model from offset 0 cleanly</li>
        <li>✓ Tombstone handling explicit in every consumer — null values are NOT "skip this"</li>
        <li>✓ Snapshot cadence monitored — falling behind on snapshots means read latency creeps up silently</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Final section closes the atlas — AND the data-systems trilogy. The outbox pattern
        (the answer to §02&apos;s dual-write cliffhanger), distributed sagas, operational
        realities (backpressure, dead-letter queues, consumer lag monitoring), and the
        arc-closing wrap that frames Atlas 20-21-22 as the full story they tell together.
      </Callout>
    </>
  );
}
