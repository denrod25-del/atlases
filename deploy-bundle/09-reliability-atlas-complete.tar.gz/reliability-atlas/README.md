# Reliability — Atlas #24 (B. Symbolic)

SLIs · SLOs · Error Budgets · Chaos Engineering · The Math of Good Enough

**Continues the operations arc.** Atlas 23 (Observability) built the apparatus
for measuring a system. This atlas turns those measurements into commitments —
and into permission. The discipline of deciding how reliable "reliable enough"
actually is, and what to do when production tells you the answer is "not yet."

## Conventions
- Palette: emerald-300 primary, rose-400 accent
- Glyph: ⊕ (circled plus — equilibrium / target / balance)
- Type: Bricolage Grotesque · JetBrains Mono · Manrope
- New callout kind: `budget` (Gauge icon) for SLO/budget math
- Build script uses `node ./node_modules/vite/bin/vite.js build` (Vercel-fix baked in)
- `.gitignore` baked in from first commit
- Pre-flight secret scan clean

## Run locally
```
npm install
npm run dev          # http://localhost:5173
```

## Section status
- 01 SLIs & SLOs    — COMPLETE (SLO Target Selector)
- 02 Error Budgets  — COMPLETE (Error Budget Burn Simulator)
- 03 Chaos          — COMPLETE (Chaos Experiment Designer)
- 04 Good Enough    — COMPLETE (Reliability Cost Curve + atlas-closing wrap)

## Series
- Atlas 17-19 — API series
- Atlas 20-22 — Data-systems arc (complete)
- Atlas 23 — Observability (operations arc opened)
- **Atlas 24 — Reliability (this one) — continues operations arc**
- Atlas 25 — Incident Response (planned)
