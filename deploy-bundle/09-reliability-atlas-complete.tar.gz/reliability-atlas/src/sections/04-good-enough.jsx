/* Section 04 — The Math of Good Enough.
 *
 * Prose + Reliability Cost Curve interactive.
 *
 * The interactive: a four-tier nines selector (99% → 99.9% → 99.99% →
 * 99.999%). Each tier shows the downtime allowance per year / month /
 * week, the approximate cost multiplier relative to two nines, what the
 * tier demands in engineering terms, and who genuinely needs it. An SVG
 * cost curve plots all four tiers with the selected one highlighted, so
 * the exponential shape of the curve is visible at a glance.
 *
 * The teaching aim: reliability is an economic decision, not a virtue
 * contest. Each additional nine costs roughly 10× more and delivers
 * downtime savings most users can never perceive. "Good enough" is a
 * number you choose deliberately — then defend with the budget math
 * from Section 02.
 *
 * Closes the atlas: wrap of §01-04 plus the bridge to Atlas 25
 * (Incident Response).
 *
 * All prose strings use backticks (template literals).
 */

import { useState } from 'react';
import { TrendingUp, CheckCircle2 } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Reliability Cost Curve
// ───────────────────────────────────────────────────────────────────────

const MINUTES_PER_YEAR = 365.25 * 24 * 60;

/* Format a downtime allowance (given in minutes) into the most readable
 * human unit. Bounded: allowances here range from seconds to days.
 */
function formatDowntime(minutes) {
  if (minutes >= 60 * 24) return `${(minutes / (60 * 24)).toFixed(1)} days`;
  if (minutes >= 90) return `${(minutes / 60).toFixed(1)} hours`;
  if (minutes >= 1) return `${minutes.toFixed(1)} minutes`;
  return `${(minutes * 60).toFixed(0)} seconds`;
}

/* Downtime allowance in minutes for an availability target over a period. */
function allowance(target, periodMinutes) {
  return (1 - target) * periodMinutes;
}

const TIERS = [
  {
    id: 'two',
    nines: '99%',
    label: `two nines`,
    target: 0.99,
    costX: 1,
    tone: `baseline`,
    summary: `A single well-kept server or small VPS deployment. Downtime is measured in days per year — noticeable, but survivable for internal tools, side projects, and anything whose users can shrug and retry tomorrow.`,
    demands: [
      `One production environment, restored from backup when it breaks`,
      `Monitoring that tells a human something is down`,
      `A documented restart / restore procedure`,
      `Maintenance windows are acceptable — planned downtime is fine`,
    ],
    fitsWho: `Internal dashboards, side projects, batch jobs, anything with a "try again later" tolerance.`,
  },
  {
    id: 'three',
    nines: '99.9%',
    label: `three nines`,
    target: 0.999,
    costX: 10,
    tone: `the workhorse`,
    summary: `The default SLO for serious SaaS. Under nine hours of downtime a year — users notice incidents, but a well-run on-call rotation resolves them before trust erodes. Most successful products live here far longer than their engineers like to admit.`,
    demands: [
      `Redundant instances behind a load balancer — no single machine matters`,
      `Automated health checks and restarts; deploys without downtime`,
      `An on-call rotation with alerting tuned to symptoms (Section 01)`,
      `An error budget policy the team actually follows (Section 02)`,
    ],
    fitsWho: `Customer-facing SaaS, e-commerce, most APIs — the broad middle of the industry.`,
  },
  {
    id: 'four',
    nines: '99.99%',
    label: `four nines`,
    target: 0.9999,
    costX: 100,
    tone: `serious money`,
    summary: `Under an hour of downtime a year — less than five minutes a month. Humans cannot respond that fast, so recovery must be automatic. Every layer needs redundancy, including the infrastructure that provides the redundancy.`,
    demands: [
      `Multi-zone (often multi-region) deployment with automatic failover`,
      `Recovery is automated — a human paged at minute 3 has already blown the month`,
      `Canary or progressive deploys; instant automated rollback`,
      `Chaos engineering to prove the failover actually works (Section 03)`,
    ],
    fitsWho: `Payment processing, auth providers, infrastructure other companies build on.`,
  },
  {
    id: 'five',
    nines: '99.999%',
    label: `five nines`,
    target: 0.99999,
    costX: 1000,
    tone: `telecom territory`,
    summary: `Five minutes of downtime a year — twenty-six seconds a month. This is carrier-grade engineering: no maintenance windows, no cold starts, no "we'll fix it in the morning." Every component, process, and person is organized around never being the reason.`,
    demands: [
      `Active-active multi-region serving with zero-downtime everything`,
      `Formal change management; every deploy is a gradual, reversible rollout`,
      `Dedicated reliability engineering staff — this is their whole job`,
      `Dependencies must ALSO be five nines, or be survivable when they are not`,
    ],
    fitsWho: `Telephone networks, emergency services, core banking rails. Almost nobody else.`,
  },
];

/* SVG curve geometry — cost (y, exponential) against nines (x, linear).
 * Fixed viewBox; points computed from tier index so the curve stays
 * honest to the 1× → 10× → 100× → 1000× shape on a log-ish visual scale.
 */
const CURVE = { w: 560, h: 200, padX: 48, padY: 24 };

function curvePoint(index) {
  const usableW = CURVE.w - CURVE.padX * 2;
  const usableH = CURVE.h - CURVE.padY * 2;
  const x = CURVE.padX + (index / (TIERS.length - 1)) * usableW;
  // log10 of costX: 0, 1, 2, 3 → normalized 0..1, inverted for SVG y
  const yNorm = Math.log10(TIERS[index].costX) / 3;
  const y = CURVE.h - CURVE.padY - yNorm * usableH;
  return { x, y };
}

function CostCurveSvg({ activeIndex }) {
  const points = TIERS.map((_, i) => curvePoint(i));
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  return (
    <svg viewBox={`0 0 ${CURVE.w} ${CURVE.h}`} className="w-full h-auto" role="img"
      aria-label={`Cost curve: each additional nine of availability costs roughly ten times more`}>
      <line x1={CURVE.padX} y1={CURVE.h - CURVE.padY} x2={CURVE.w - CURVE.padX}
        y2={CURVE.h - CURVE.padY} stroke="#3f3f46" strokeWidth="1" />
      <path d={path} fill="none" stroke="#6ee7b7" strokeWidth="2" strokeLinejoin="round" />
      {TIERS.map((tier, i) => {
        const p = points[i];
        const isActive = i === activeIndex;
        return (
          <g key={tier.id}>
            <circle cx={p.x} cy={p.y} r={isActive ? 7 : 4}
              fill={isActive ? '#6ee7b7' : '#18181b'}
              stroke={isActive ? '#6ee7b7' : '#52525b'} strokeWidth="2" />
            <text x={p.x} y={CURVE.h - CURVE.padY + 16} textAnchor="middle"
              fill={isActive ? '#6ee7b7' : '#71717a'} fontSize="11"
              fontFamily="JetBrains Mono, monospace">
              {tier.nines}
            </text>
            <text x={p.x} y={p.y - 12} textAnchor="middle"
              fill={isActive ? '#fda4af' : '#52525b'} fontSize="11"
              fontFamily="JetBrains Mono, monospace">
              {tier.costX}×
            </text>
          </g>
        );
      })}
    </svg>
  );
}

function DowntimeStat({ label, value }) {
  return (
    <div className="border border-zinc-800 bg-zinc-950/60 p-3">
      <div className="text-zinc-500 text-[10px] tracking-[0.25em] uppercase mb-1"
        style={{ fontFamily: 'JetBrains Mono, monospace' }}>
        {label}
      </div>
      <div className="text-zinc-100 text-[17px]"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        {value}
      </div>
    </div>
  );
}

function ReliabilityCostCurve() {
  const [activeIndex, setActiveIndex] = useState(1);
  const tier = TIERS[activeIndex];
  const perYear = allowance(tier.target, MINUTES_PER_YEAR);
  const perMonth = allowance(tier.target, MINUTES_PER_YEAR / 12);
  const perWeek = allowance(tier.target, MINUTES_PER_YEAR / 52.18);

  return (
    <div className="my-6 border border-zinc-800 bg-zinc-950/60">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-zinc-800">
        <div className="flex items-center gap-2 text-emerald-300 text-[11px] tracking-[0.2em] uppercase"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          <TrendingUp size={13} strokeWidth={2.5} />
          <span>reliability cost curve</span>
        </div>
        <div className="text-zinc-600 text-[10px] tracking-[0.2em] uppercase hidden sm:block"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          pick a target
        </div>
      </div>

      <div className="flex gap-1.5 px-4 pt-4 overflow-x-auto">
        {TIERS.map((t, i) => {
          const isActive = i === activeIndex;
          return (
            <button key={t.id} onClick={() => setActiveIndex(i)}
              className={`px-3 py-1.5 border text-[12px] whitespace-nowrap transition-colors shrink-0 ${
                isActive
                  ? 'border-emerald-300 bg-emerald-300/15 text-emerald-200'
                  : 'border-zinc-700/80 text-zinc-400 hover:border-emerald-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {t.nines}
            </button>
          );
        })}
      </div>

      <div className="px-4 pt-4">
        <CostCurveSvg activeIndex={activeIndex} />
      </div>

      <div className="px-4 pb-4">
        <div className="flex items-baseline gap-3 mt-2 mb-2 flex-wrap">
          <div className="text-zinc-50 text-[20px]"
            style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
            {tier.nines} — {tier.label}
          </div>
          <div className="text-rose-400 text-[12px] tracking-[0.15em] uppercase"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            ~{tier.costX}× cost · {tier.tone}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-3">
          <DowntimeStat label="allowed / year" value={formatDowntime(perYear)} />
          <DowntimeStat label="allowed / month" value={formatDowntime(perMonth)} />
          <DowntimeStat label="allowed / week" value={formatDowntime(perWeek)} />
        </div>

        <p className="text-zinc-300 text-[14px] leading-relaxed mb-3"
          style={{ fontFamily: 'Manrope, sans-serif' }}>
          {tier.summary}
        </p>

        <div className="text-zinc-500 text-[10px] tracking-[0.25em] uppercase mb-2"
          style={{ fontFamily: 'JetBrains Mono, monospace' }}>
          what this tier demands
        </div>
        <ul className="space-y-1.5 mb-3">
          {tier.demands.map((d) => (
            <li key={d} className="flex items-start gap-2 text-zinc-300 text-[13.5px] leading-relaxed"
              style={{ fontFamily: 'Manrope, sans-serif' }}>
              <CheckCircle2 size={14} strokeWidth={2.5} className="text-emerald-300 mt-1 shrink-0" />
              <span>{d}</span>
            </li>
          ))}
        </ul>

        <div className="border border-zinc-800 bg-zinc-900/40 p-3 text-zinc-400 text-[13px] leading-relaxed"
          style={{ fontFamily: 'Manrope, sans-serif' }}>
          <span className="text-emerald-300 text-[10px] tracking-[0.25em] uppercase mr-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            who needs it
          </span>
          {tier.fitsWho}
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section
// ───────────────────────────────────────────────────────────────────────

export default function Section04_GoodEnough() {
  return (
    <>
      <SectionLabel>section 04</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        The math of good enough — what each nine costs
      </h2>
      <P>
        Everything in this atlas so far has been about measuring reliability and defending it.
        This closing section asks the question that should have come first and deliberately
        comes last: how reliable should you even be? The honest answer is a number, not a
        feeling — and the number comes from a cost curve that punishes ambition exponentially
        while rewarding it invisibly.
      </P>

      <H2 num="◇ 01">Each nine costs roughly ten times more</H2>
      <P>
        Moving from 99% to 99.9% means surviving every failure a single machine can produce.
        Moving from 99.9% to 99.99% means surviving every failure a single <em>zone</em> can
        produce, faster than a human can be paged. Moving to 99.999% means surviving every
        failure a single <em>region</em> can produce, with no one noticing. Each step does not
        add effort — it multiplies it, because each step removes an entire category of
        recovery strategy. At two nines you can restore from backup. At three you can wake
        someone up. At four the machines must save themselves. At five, even the machines
        saving themselves must have a backup plan.
      </P>
      <P>
        Explore the four tiers. Watch two things as you climb: how fast the downtime allowance
        shrinks, and how the engineering demands stop being features and start being
        organizational commitments.
      </P>

      <ReliabilityCostCurve />

      <Callout kind="budget" title="THE 10× RULE OF THUMB">
        Industry folklore, but well-earned: each additional nine of availability costs roughly
        an order of magnitude more — in infrastructure, in engineering time, and in
        operational discipline. The exact multiplier varies by system; the exponential shape
        does not. If someone proposes raising the SLO by a nine, the first question is not
        {' '}<Kbd>how</Kbd> — it is <Kbd>who pays, and what do they give up</Kbd>.
      </Callout>

      <H2 num="◇ 02">The nines your users cannot feel</H2>
      <P>
        The other half of the math: the benefit curve flattens as viciously as the cost curve
        steepens. A user on a phone reaches your service through a mobile network that is
        itself roughly 99.5% reliable, a home ISP at maybe 99.9%, a laptop that sleeps, a
        browser that gets closed. Once your availability comfortably exceeds the noise floor
        of everything between you and the user, additional nines are indistinguishable from
        luck. The user who hits your one bad minute per month at four nines almost certainly
        blames their WiFi.
      </P>
      <P>
        There is also a ceiling you do not control: your reliability is capped by the hard
        dependencies in your critical path. If your service cannot answer without a payment
        API that runs at 99.9%, then your effective availability is your reliability
        <em> multiplied by</em> theirs — 99.99% × 99.9% is 99.89%. You bought four nines and
        shipped three. The escape routes are the ones this atlas keeps returning to: cache,
        degrade gracefully, queue and retry — or accept the ceiling and stop paying for nines
        above it.
      </P>

      <Code lang="text" id="effective-availability">{`Your SLO:                         99.99%   (52.6 min/year allowed)
Hard dependency (payments API):   99.9%    (8.77 h/year down)

Effective availability = 0.9999 × 0.999 = 0.9989  →  99.89%

You are paying 100× for four nines.
Your users are receiving three.
Either the dependency gets an escape route (cache / degrade / queue),
or the honest SLO is 99.9% — at a tenth of the cost.`}</Code>

      <H2 num="◇ 03">Choosing your number</H2>
      <P>
        A defensible reliability target comes from four questions, answered in order. What do
        users actually need — measured tolerance, not imagined perfectionism? What do your
        dependencies permit — the multiplication above? What does the next nine cost — the
        curve? And what would that money buy elsewhere — the feature, the second product, the
        third engineer? Good enough is where those four answers intersect, written down as
        an SLO from Section 01, defended by the budget from Section 02, and proven by the
        experiments from Section 03.
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-emerald-300">Start lower than your pride wants.</strong> A 99.9% SLO you consistently meet builds more trust than a 99.99% SLO you miss twice a year. You can always raise a target you are beating; lowering one you are missing is a public retreat.</li>
        <li><strong className="text-emerald-300">Different SLOs for different journeys.</strong> Checkout deserves more nines than the recommendation carousel. One blanket number overpays for the trivial and underprotects the critical.</li>
        <li><strong className="text-emerald-300">Let the error budget arbitrate.</strong> Budget consistently unspent? The target may be too loose — or you are over-engineered and could ship faster. Budget consistently exhausted? The target is too ambitious for the current architecture, and either the target or the architecture must move.</li>
        <li><strong className="text-rose-400">Never promise externally what you have not proven internally.</strong> A contractual SLA should sit a comfortable margin below the SLO you reliably hit. The SLA is where missed nines stop costing engineering time and start costing money.</li>
      </ul>

      <Callout kind="dont" title="THE PERFECTIONIST TRAP">
        More reliable is not better engineering — past the point users can perceive, it is
        worse engineering: capital burned on nines nobody feels, velocity sacrificed to a
        number chosen by ego. The five-nines systems that deserve five nines — emergency
        services, core banking, the phone network — earned that target from consequences,
        not from ambition.
      </Callout>

      <SectionLabel>closing the atlas</SectionLabel>
      <H2 num="◇ 04">What you built here</H2>
      <P>
        This atlas gave you the full reliability loop. Section 01: SLIs measure what users
        actually experience, and SLOs turn those measurements into commitments. Section 02:
        error budgets convert the commitment into arithmetic — permission to ship fast when
        healthy, a mandate to slow down when burning. Section 03: chaos engineering stops the
        whole structure from being theater, by proving your failure claims against real
        failure. And this section: the discipline of choosing targets whose cost you can
        justify, because reliability is an economic decision wearing an engineering costume.
      </P>
      <P>
        The loop closes on itself. The cost curve tells you which nines to buy. The SLO writes
        the choice down. The budget enforces it month by month. Chaos verifies it holds. And
        when the verdict comes back not-yet — when the budget is gone and the graphs are
        red — the discipline is to stop, fix, and re-earn the target before chasing a bigger
        one.
      </P>

      <Callout kind="info" title="WHAT'S NEXT — ATLAS 25">
        Everything in this atlas assumed failures get handled. Atlas 25 — Incident Response —
        is about the handling: what disciplined teams do in the minutes after the page fires.
        On-call that does not burn people out, incident command that scales past two
        responders, communication while everything is on fire, and postmortems that actually
        prevent the sequel. This atlas decided how much failure you can afford; the next one
        is about spending those failures well.
      </Callout>
    </>
  );
}
