/* Section 01 — SLIs, SLOs, and SLAs.
 *
 * Prose + SLO Target Selector.
 *
 * The interactive: a column of common SLO targets (90% / 95% / 99% /
 * 99.5% / 99.9% / 99.95% / 99.99% / 99.999%). For each, render the
 * derived math (downtime per year / month / week / day; errors per
 * million requests) and a "reality check" panel — what kind of org
 * actually operates at this level, what it costs, who is famous for it.
 *
 * The teaching aim: nines are exponentially expensive. The right SLO is
 * the one users actually need — usually NOT five nines.
 *
 * All prose strings use backticks (template literals).
 */

import { useState } from 'react';
import { Sparkles, Target, TrendingUp, Building2, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// SLO Target Selector
// ───────────────────────────────────────────────────────────────────────

const SLO_OPTIONS = [
  {
    pct: 90,
    name: 'one nine',
    minPerMonth: 4320,
    minPerYear:  52560,
    errPerMillion: 100_000,
    cost: 1,
    tone: 'easy',
    example: 'A side project. Internal tool used by one team. Throwaway prototype. Almost no operational investment needed.',
  },
  {
    pct: 95,
    name: 'one and a half nines',
    minPerMonth: 2160,
    minPerYear:  26280,
    errPerMillion: 50_000,
    cost: 1,
    tone: 'easy',
    example: 'Early-stage MVP. Users tolerate occasional outages. The cost of higher reliability would exceed the value.',
  },
  {
    pct: 99,
    name: 'two nines',
    minPerMonth: 432,
    minPerYear: 5256,
    errPerMillion: 10_000,
    cost: 2,
    tone: 'easy',
    example: 'Most startups. Most internal SaaS. Most B2B tools serving moderate-sized teams. Roughly 7 hours of downtime per month is acceptable — barely.',
  },
  {
    pct: 99.5,
    name: 'two and a half nines',
    minPerMonth: 216,
    minPerYear: 2628,
    errPerMillion: 5_000,
    cost: 2,
    tone: 'moderate',
    example: 'Growing SaaS. Tools customers pay for but tolerate maintenance windows. About 3.5 hours of downtime per month — a few short incidents.',
  },
  {
    pct: 99.9,
    name: 'three nines',
    minPerMonth: 43.2,
    minPerYear: 525.6,
    errPerMillion: 1_000,
    cost: 3,
    tone: 'moderate',
    example: 'Mature SaaS. Most consumer apps. The unofficial industry baseline for "we take reliability seriously." About 43 minutes/month — one bad incident eats a quarter of it.',
  },
  {
    pct: 99.95,
    name: 'three and a half nines',
    minPerMonth: 21.6,
    minPerYear: 262.8,
    errPerMillion: 500,
    cost: 4,
    tone: 'hard',
    example: 'Premium SaaS. Customer-facing financial tools. Healthcare-adjacent products. About 22 minutes/month — single-incident budgets shrink to "minor blip only."',
  },
  {
    pct: 99.99,
    name: 'four nines',
    minPerMonth: 4.32,
    minPerYear: 52.56,
    errPerMillion: 100,
    cost: 5,
    tone: 'hard',
    example: 'Hyperscaler services (AWS S3, Google Cloud Storage). Major payment networks. ~4 minutes/month — no manual intervention is fast enough; automation must do the heavy lifting.',
  },
  {
    pct: 99.999,
    name: 'five nines',
    minPerMonth: 0.432,
    minPerYear: 5.256,
    errPerMillion: 10,
    cost: 6,
    tone: 'extreme',
    example: 'Telecom switches. DNS root servers. Tier-1 financial-clearing networks. 26 SECONDS per month. Achievable only with multi-region active-active, sub-second failover, and the engineering org of a hyperscaler.',
  },
];

function formatDuration(minutes) {
  if (minutes < 1) {
    const secs = minutes * 60;
    return `${secs.toFixed(secs < 10 ? 1 : 0)} sec`;
  }
  if (minutes < 60) {
    return `${minutes.toFixed(minutes < 10 ? 1 : 0)} min`;
  }
  const hours = minutes / 60;
  if (hours < 24) {
    return `${hours.toFixed(hours < 10 ? 1 : 0)} hr`;
  }
  const days = hours / 24;
  return `${days.toFixed(1)} days`;
}

function SLOTargetSelector() {
  const [idx, setIdx] = useState(4);  // start on 99.9% — the industry baseline
  const slo = SLO_OPTIONS[idx];

  const toneStyles = {
    easy:     { border: 'border-lime-400/60',    bg: 'bg-lime-400/10',    text: 'text-lime-400'  },
    moderate: { border: 'border-emerald-300/60', bg: 'bg-emerald-300/10', text: 'text-emerald-300' },
    hard:     { border: 'border-amber-400/60',   bg: 'bg-amber-400/10',   text: 'text-amber-400'  },
    extreme:  { border: 'border-rose-400/60',    bg: 'bg-rose-400/10',    text: 'text-rose-400'   },
  };
  const tone = toneStyles[slo.tone];

  // Cost bar — 6 cells with the cost level filled
  const costCells = Array.from({ length: 6 }, (_, i) => i < slo.cost);

  return (
    <div className="my-6 border border-emerald-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-emerald-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-emerald-300" />
          <span className="text-emerald-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · slo target selector
          </span>
        </div>
      </div>

      <div className="p-4">
        <div className="mb-4 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13px] leading-relaxed italic">
          Each row is an SLO target with the exact math it commits you to. Pick the level
          your users actually need — not the level that sounds impressive. Notice how the cost
          (engineering investment, infrastructure spend) climbs exponentially while user-felt
          difference between adjacent levels shrinks toward invisible.
        </div>

        {/* SLO target list */}
        <div className="space-y-1.5 mb-4">
          {SLO_OPTIONS.map((s, i) => {
            const isActive = i === idx;
            const t = toneStyles[s.tone];
            return (
              <button key={s.pct} onClick={() => setIdx(i)}
                className={`w-full grid grid-cols-[80px_1fr_70px] sm:grid-cols-[90px_1fr_88px] gap-3 items-center text-left p-2 border transition-colors ${
                  isActive
                    ? `${t.border} ${t.bg}`
                    : 'border-zinc-800 hover:border-zinc-600 bg-zinc-900/30'
                }`}>
                <div className={`text-[14px] font-bold ${isActive ? t.text : 'text-zinc-300'}`}
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {s.pct}%
                </div>
                <div>
                  <div className={`text-[10.5px] tracking-[0.2em] uppercase ${isActive ? t.text : 'text-zinc-500'}`}
                    style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    {s.name}
                  </div>
                  <div className="text-zinc-400 text-[11px]">
                    {formatDuration(s.minPerMonth)} downtime/month allowed · {s.errPerMillion.toLocaleString()} errors per million reqs
                  </div>
                </div>
                <div className={`text-[10px] tracking-[0.15em] uppercase font-semibold text-right ${isActive ? t.text : 'text-zinc-500'}`}
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {s.tone}
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected SLO breakdown */}
        <div className={`border ${tone.border} ${tone.bg} p-4`}>
          <div className="flex items-center justify-between mb-3">
            <div className={`text-[10.5px] tracking-[0.25em] uppercase font-semibold flex items-center gap-2 ${tone.text}`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <Target size={12} />
              breakdown · {slo.pct}% SLO
            </div>
            <div className="flex items-center gap-2">
              <span className="text-zinc-500 text-[9.5px] tracking-[0.2em] uppercase"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>cost</span>
              <div className="flex gap-0.5">
                {costCells.map((filled, i) => (
                  <div key={i} className={`w-3 h-3 ${filled ? tone.bg + ' ' + tone.border + ' border' : 'border border-zinc-700'}`} />
                ))}
              </div>
            </div>
          </div>

          {/* Downtime grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
            <div className="border border-zinc-700 bg-zinc-950/60 p-2">
              <div className="text-zinc-500 text-[9px] tracking-[0.25em] uppercase"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>per year</div>
              <div className="text-zinc-100 text-[14px] font-bold leading-none mt-1"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {formatDuration(slo.minPerYear)}
              </div>
            </div>
            <div className="border border-zinc-700 bg-zinc-950/60 p-2">
              <div className="text-zinc-500 text-[9px] tracking-[0.25em] uppercase"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>per month</div>
              <div className="text-zinc-100 text-[14px] font-bold leading-none mt-1"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {formatDuration(slo.minPerMonth)}
              </div>
            </div>
            <div className="border border-zinc-700 bg-zinc-950/60 p-2">
              <div className="text-zinc-500 text-[9px] tracking-[0.25em] uppercase"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>per week</div>
              <div className="text-zinc-100 text-[14px] font-bold leading-none mt-1"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {formatDuration(slo.minPerMonth / 4.345)}
              </div>
            </div>
            <div className="border border-zinc-700 bg-zinc-950/60 p-2">
              <div className="text-zinc-500 text-[9px] tracking-[0.25em] uppercase"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>per day</div>
              <div className="text-zinc-100 text-[14px] font-bold leading-none mt-1"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                {formatDuration(slo.minPerMonth / 30)}
              </div>
            </div>
          </div>

          {/* Reality check */}
          <div className="text-zinc-200 text-[13px] leading-relaxed border-t border-zinc-700/40 pt-3 flex items-start gap-2">
            <Building2 size={14} className={`shrink-0 mt-0.5 ${tone.text}`} />
            <div>{slo.example}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section01_SLOs() {
  return (
    <>
      <SectionLabel>section 01</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        SLIs, SLOs, and SLAs — making "reliable" mean something
      </h2>
      <P>
        Atlas 23 built the apparatus for measuring a system. This atlas turns those measurements
        into commitments — and into permission. "We try to be reliable" is hope, not a plan. A
        Service Level Objective is a number with consequences attached: you write it down, you
        measure against it, and when you miss it you change how you operate. The discipline is
        not just measuring reliability. It is deciding how reliable you actually need to be —
        which is almost always lower than your instincts say.
      </P>

      <H2 num="◇ 01">The three letters — SLI, SLO, SLA</H2>
      <Code id="slo-vocabulary" lang="text">{`SLI    SERVICE LEVEL INDICATOR
       A METRIC — the actual thing you're measuring.
       Examples:
         "fraction of requests with HTTP status 2xx-4xx (not 5xx)"
         "fraction of requests served in under 200ms"
         "fraction of jobs completed within their freshness window"

       The SLI is a NUMBER, computed from your metrics, on a defined window.

SLO    SERVICE LEVEL OBJECTIVE
       A TARGET — the value the SLI should hit.
       Examples:
         "99.9% of requests over a rolling 30 days will have status 2xx-4xx"
         "99.5% of requests over a rolling 7 days will complete in under 200ms"
         "99.99% of pipelines over the quarter will finish within 15 minutes of schedule"

       The SLO is an INTERNAL COMMITMENT — you write it down, you measure
       against it, missing it triggers organizational consequences (the
       famous "freeze feature work until the budget recovers").

SLA    SERVICE LEVEL AGREEMENT
       A CONTRACT — what you promise to CUSTOMERS, with penalties.
       Examples:
         "99% uptime monthly; if missed, customers receive 10% credit"
         "p99 latency under 500ms; if missed for two consecutive months,
          customer may exit contract penalty-free"

       The SLA is almost always WEAKER than the SLO — you commit to less
       externally than you target internally, because hitting the SLA needs
       to be near-certain.

THE HIERARCHY (most teams):     SLA  <  SLO  <  achieved SLI
                                ↑       ↑          ↑
                                what     what       what you
                                you      you        actually
                                promise  target     deliver`}</Code>

      <H2 num="◇ 02">What makes a good SLI</H2>
      <P>
        Not every metric is an SLI. A good SLI measures what users actually experience — not
        what is convenient to graph. CPU utilization is a metric, but no user opens your app
        and feels "CPU is at 87%." They feel "this took 4 seconds" or "the page errored out."
        SLIs are user-facing.
      </P>
      <Code id="sli-examples" lang="text">{`THE CANONICAL SLI TYPES (Google SRE book):

  AVAILABILITY    "Did the request succeed?"
                  good_events / valid_events
                  
                  Where good = HTTP 2xx, 3xx, 4xx (4xx is client's fault, not yours)
                  Where valid = total non-cancelled requests
                  
                  Example: "99.9% of requests are not 5xx errors over rolling 30 days"

  LATENCY         "Was the request fast enough?"
                  events_within_threshold / valid_events
                  
                  Note: it's a fraction, not "average latency." This counts how MANY
                  requests met a threshold, not how slow the slow ones were.
                  
                  Example: "99% of requests complete in under 200ms over rolling 7 days"

  FRESHNESS       "Is the data current enough?"
                  records_younger_than_threshold / total_records
                  
                  For batch jobs, data pipelines, derived datasets.
                  Example: "99% of dashboards refreshed within the last 5 minutes"

  CORRECTNESS     "Are the computed results right?"
                  good_outputs / total_outputs
                  
                  Often measured by sampling and cross-validating.
                  Example: "99.99% of order totals computed correctly per audit sample"

  DURABILITY      "Did stored data survive?"
                  bytes_retrievable / bytes_stored
                  
                  Mostly for storage systems. Example: "99.999999999% (eleven nines)
                  durability for S3" — the famously high number for object stores.

WHAT NOT TO USE AS SLIs:
  ✗ CPU, memory, disk, network — these are RESOURCE metrics (USE method, Atlas 23 §03)
    They tell you about HEALTH, not USER EXPERIENCE
  ✗ Queue depth — internal symptom, not user experience
  ✗ Garbage collector pause time — same; internal
  ✗ Anything users cannot feel, even indirectly`}</Code>
      <Callout kind="budget" title="THE SLI IS A FRACTION, NOT AN AVERAGE">
        Notice every SLI definition above is structured as <strong className="text-emerald-200">good_events / valid_events</strong> — a count, not a magnitude. "99% of requests under
        200ms" is an SLI; "average latency 95ms" is not. The fraction-based form lets you
        compose SLIs directly with an error budget (1 - SLO = budget for bad events) and
        gives you a uniform target language across availability, latency, freshness, and any
        other dimension.
      </Callout>

      <H2 num="◇ 03">Choosing an SLO — the most consequential reliability decision</H2>
      <P>
        Once you have an SLI, the SLO is just the number you commit to. But the choice of
        number is the most consequential reliability decision your team will make. Pick too
        low and customers leave. Pick too high and you burn engineering for a difference
        users cannot perceive. The right number lives at the intersection of "what users
        actually need" and "what we can sustainably deliver."
      </P>
      <Code id="slo-selection" lang="text">{`HOW MANY NINES DO YOU NEED?

   1. What does the USER experience at each level?
        99%      User notices outages occasionally; tolerates if rare
        99.9%    User notices once a quarter at most; expects pages working
        99.99%   User notices only during major incidents; expects "always there"
        99.999%  User notices ONLY when something catastrophic happens

   2. What CAN you deliver sustainably?
        Each additional 9 costs roughly 10× the engineering effort of the
        previous. The infrastructure cost climbs similarly:
          1 region                 → 99.5% achievable
          Multi-AZ                  → 99.9% achievable
          Multi-region active-passive → 99.95% achievable
          Multi-region active-active → 99.99% achievable
          Many regions, sub-second failover → 99.999% achievable

   3. The DEPENDENCY MATH constrains you.
        If you call a service with a 99.5% SLO, your own SLO cannot
        meaningfully exceed 99.5% — their outages become your outages.
        Plan: count dependencies, set realistic ceiling.

   4. The COST of missing the SLO must be commensurate.
        99.9%: missing burns engineering credibility; freeze features for a sprint
        99.99%: missing might cost a CSAT spike, refunds, contract questions
        99.999%: missing might cost millions of dollars, regulatory attention

THE RULE: pick the LOWEST SLO your users would actually be happy with.
Most consumer SaaS lives at 99.9%. Most B2B internal tools live at 99% or
99.5%. Five nines is for teams whose users would notice the difference —
which is far rarer than vendor marketing implies.`}</Code>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 04">Pick your nines</H2>
      <P>
        Eight SLO target levels with the math derived for each — downtime allowed per year,
        per month, per week, per day, plus the cost level and a reality check naming what kind
        of organization actually operates at this level. Notice that going from 99% to 99.9%
        cuts allowed downtime by 10×; going from 99.9% to 99.99% cuts it another 10×; going
        from 99.99% to 99.999% cuts it yet another 10×. The user-perceived difference between
        adjacent levels shrinks as the cost explodes. Find the level your users would actually
        notice the difference at — not the one that sounds impressive in a marketing deck.
      </P>

      <SLOTargetSelector />

      <H2 num="◇ 05">SLAs — the contract version</H2>
      <P>
        SLAs are the externally-facing commitment with consequences (credits, refunds, exit
        rights). The rules are different from SLOs in two important ways: SLAs are weaker
        than SLOs, and SLA misses cost money in ways SLO misses do not.
      </P>
      <Code id="slas-vs-slos" lang="text">{`WHY SLAs ARE WEAKER THAN SLOs:

   If your INTERNAL SLO is 99.9% (43 min/month allowed) and your EXTERNAL SLA
   is also 99.9%, every internal miss is a contract violation. That puts you
   in negotiation with every customer every month.

   Buffer rule of thumb: SLA is 1 nine LOOSER than the SLO. If internal SLO
   is 99.95%, SLA to customers is 99.9%. If internal SLO is 99.9%, SLA is 99%.

   This gives you ROOM TO MISS the internal target occasionally without
   triggering external consequences. The SLA is the cliff; the SLO is the
   guardrail you build in front of it.

WHAT A REAL SLA INCLUDES:

   - The SLI (what's measured)
   - The SLO (target value)
   - The measurement window (monthly, quarterly, annually)
   - What counts as downtime (response code thresholds, latency limits)
   - What does NOT count (scheduled maintenance, force majeure,
     customer's own infrastructure failures, third-party providers)
   - The remedy (service credits — usually 10-25% of monthly fee)
   - The exit rights (if missed N times in M months, customer can leave)

CUSTOMER-FACING NUANCES:

   - "Per-customer SLA" vs "global SLA" — global is harder; per-customer
     means a single customer's bad month doesn't trigger refunds for everyone
   - Credits are usually a percentage of subscription value, NOT actual damages
   - "Available for issuing credit upon request" is common — customers must
     proactively claim, most don't, so the actual financial exposure is lower
     than the on-paper exposure
   - Enterprise customers will negotiate stronger SLAs than your default`}</Code>

      <H2 num="◇ 06">The dependency-chain math</H2>
      <P>
        If your service depends on others, your achievable SLO is bounded by theirs. The math
        is multiplicative and bites quickly.
      </P>
      <Code id="dependency-math" lang="text">{`THE BASIC MULTIPLICATION:

   Service A depends on services B, C, D. If each is 99.9% (independent failures):
      Theoretical max SLO of A = 0.999 × 0.999 × 0.999 = 0.997 → 99.7%
      
   With 10 such dependencies:
      0.999^10 = 0.990 → 99.0%

   The more services you depend on, the lower your achievable SLO ceiling.
   Microservice architectures pay this tax constantly.

WHEN DEPENDENCIES OVERLAP (BAD):
   If services B and C both depend on the same database, their failures are
   CORRELATED — a DB outage breaks both at the same time. The multiplication
   approach overestimates your reliability. Investigate the real dependency
   topology.

WHEN DEPENDENCIES HAVE FALLBACKS (GOOD):
   If B has a cached value you can use when B is down, B's contribution
   to your SLO is much higher than its raw SLO. Design the fallbacks
   explicitly; document them; test them in chaos experiments (§03).

THE ESCAPE HATCH — DEGRADATION:
   You don't have to fail when a dependency fails. Most products can run
   with reduced functionality. Examples:
     - Recommendation engine down → show popular items instead
     - User-preferences service slow → use defaults
     - Search index out of date → return less-relevant results, not nothing
   
   Designed degradation gives your SLO room to breathe. Plan it explicitly.`}</Code>

      <H2 num="◇ 07">Hardening checklist for SLOs</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Every customer-facing service has at least one SLO (availability + latency, usually)</li>
        <li>✓ SLIs are user-facing measurements — counts of good events / valid events</li>
        <li>✓ SLOs documented in version-controlled YAML or similar — not in someone&apos;s head</li>
        <li>✓ SLO chosen at the LOWEST level that meets actual user needs, not the highest that sounds impressive</li>
        <li>✓ SLA (if external) is at least 1 nine looser than internal SLO</li>
        <li>✓ Dependency math validated — your SLO ceiling cannot exceed your dependencies&apos; SLOs (multiplicatively)</li>
        <li>✓ Degraded-functionality modes designed for major dependencies — never an all-or-nothing failure</li>
        <li>✓ SLO dashboards exist; rolling-window status visible to engineers AND product/leadership</li>
        <li>✓ SLO review cadence (monthly, quarterly) — adjust as user expectations and architecture evolve</li>
        <li>✓ Missing the SLO has documented organizational consequences (feature freeze, etc.) — not vibes</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Section 02 turns SLOs into the most powerful operational tool the SRE discipline has
        produced — error budgets. The math of "what we&apos;re allowed to fail at," burn-rate
        alerts that page you when you&apos;re consuming the budget too fast, and the
        feature-velocity tradeoff that turns reliability from a cost center into the lever
        product teams use to decide what to ship.
      </Callout>
    </>
  );
}
