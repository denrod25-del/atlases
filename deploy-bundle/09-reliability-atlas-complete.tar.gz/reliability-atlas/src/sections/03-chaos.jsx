/* Section 03 — Chaos Engineering.
 *
 * Prose + Chaos Experiment Designer.
 *
 * The simulator: four pre-built chaos experiments. Each has a hypothesis,
 * injection details, monitored metrics, an outcome (success / partial /
 * failure), and lessons learned. The student picks an experiment from
 * the card grid, reads the design, predicts the outcome, then sees what
 * actually happened — which is often "partially what we expected, with
 * one important surprise."
 *
 * The teaching aim: chaos engineering's value is not "things break."
 * It's "things break in ways you didn't predict, which means your mental
 * model is wrong, and you only find out by trying."
 *
 * All prose strings use backticks (template literals).
 */

import { useState } from 'react';
import { Sparkles, Beaker, Activity, CheckCircle2, AlertTriangle, XCircle, FlaskConical, Target } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Chaos Experiment Designer
// ───────────────────────────────────────────────────────────────────────

const EXPERIMENTS = [
  {
    id: 'instance-kill',
    label: 'Kill 10% of instances',
    icon: '⚰',
    setup: {
      target: 'payment-service (k8s deployment, 30 pods)',
      injection: 'Terminate 3 random pods (10%)',
      duration: '5 minutes (during business hours, 20% peak traffic)',
      blastRadius: 'Production · small · controlled',
    },
    hypothesis: `When 10% of payment-service instances are killed, the load balancer detects the failures within the health-check window (~10s) and reroutes traffic to remaining instances. Kubernetes schedules replacements within ~30s. Total user-visible impact: <30 seconds of elevated latency (p99 might bump from 60ms to 200ms briefly), zero errors.`,
    observations: [
      { metric: 'error rate',           expected: 'stays < 0.1%',                     actual: 'briefly 0.4% for 8 seconds',     tone: 'caution' },
      { metric: 'p99 latency',           expected: 'briefly up to ~200ms',             actual: 'briefly 280ms for 25 seconds',   tone: 'ok'      },
      { metric: 'request rate',          expected: 'unchanged',                        actual: 'unchanged',                       tone: 'ok'      },
      { metric: 'pod replacement time',  expected: '~30s',                             actual: '32s · within target',             tone: 'ok'      },
    ],
    outcome: {
      tone: 'success',
      title: 'SUCCESS — system recovered as predicted',
      text: `The load balancer's health checks did their job. Three pods died, three new ones came up, traffic rerouted smoothly. The 0.4% error spike during the 8-second health-check window was minor and within normal noise — but worth investigating: could we tune the health-check interval down from 10s to 5s for faster detection? Action item filed.`,
      icon: CheckCircle2,
    },
    lesson: `The simplest chaos experiment — kill some pods, watch the system recover. Every production system should pass this. If your system FAILS this test, you have bigger problems than chaos engineering.`,
  },
  {
    id: 'latency-injection',
    label: 'Inject 1500ms latency on tax-service',
    icon: '⌛',
    setup: {
      target: 'tax-service (called by checkout flow, ~80 reqs/sec)',
      injection: 'Add 1500ms delay to all tax-service responses (via service mesh sidecar)',
      duration: '15 minutes (off-peak, monitored carefully)',
      blastRadius: 'Production · medium · timeouts expected to engage',
    },
    hypothesis: `Checkout's tax-service client has a 2-second timeout. When tax-service responds in 1500ms, the timeout does NOT engage; checkout simply takes ~1500ms longer than usual. But — when occasionally taking >2000ms — the timeout fires and the cached-tax-rate fallback activates. Net effect: most checkouts slower by 1.5s, ~5-10% fallback to cached rates with slightly stale tax computation.`,
    observations: [
      { metric: 'checkout p50 latency',  expected: '1500ms slower',                     actual: '1500ms slower (~1850ms total)',   tone: 'ok'      },
      { metric: 'tax-service timeout rate', expected: '5-10%',                          actual: '8% timeout rate',                  tone: 'ok'      },
      { metric: 'cached-tax fallback',    expected: 'activates on timeout',             actual: 'activates BUT cache hit only 60%', tone: 'caution' },
      { metric: 'checkout error rate',    expected: '< 0.5%',                           actual: '3.2% errors during 15-min window',  tone: 'bad'     },
    ],
    outcome: {
      tone: 'partial',
      title: 'PARTIAL — fallback worked, but cache thin',
      text: `The timeout fired correctly. The fallback to cached tax rates activated. But the cached-rates cache only had a 60% hit rate — for the other 40% (timed out + cache miss), the checkout failed entirely. Net result: 3.2% checkout error rate, well above the SLO. This experiment revealed that the FALLBACK ITSELF has a reliability problem — the cache was assumed to be exhaustive and is not. Action items: warm the cache proactively, add a SECOND fallback (last-known-good rate from session), monitor cache hit rate as an SLI of its own.`,
      icon: AlertTriangle,
    },
    lesson: `This is the classic "we have a fallback" trap. The fallback works — but the fallback has its own reliability story. Chaos experiments are how you discover that you have a TWO-DEEP reliability problem rather than the ONE-DEEP one you thought you had.`,
  },
  {
    id: 'network-partition',
    label: 'Partition us-east from us-west',
    icon: '⛓',
    setup: {
      target: 'cross-region traffic between us-east-1 and us-west-2',
      injection: 'Block 100% of network traffic between regions for 10 minutes (via security group rules)',
      duration: '10 minutes (planned game day with on-call team standing by)',
      blastRadius: 'Production · high · both regions should operate independently',
    },
    hypothesis: `The architecture is "active-active multi-region." Each region serves its own users independently. Cross-region traffic is only for replication (eventually consistent) and admin operations. When the regions are partitioned: each region continues serving local users normally; cross-region replication queues up; when partition heals, the queue drains in a few minutes. Net user impact: none.`,
    observations: [
      { metric: 'us-east user-facing error rate',  expected: '< 0.1%',                  actual: '< 0.1% · normal',                  tone: 'ok'      },
      { metric: 'us-west user-facing error rate',  expected: '< 0.1%',                  actual: '< 0.1% · normal',                  tone: 'ok'      },
      { metric: 'replication queue depth',          expected: 'grows during partition',  actual: 'grew to 2.4M messages',            tone: 'caution' },
      { metric: 'replication queue drain time',     expected: '~5 minutes post-heal',    actual: '90 minutes post-heal · CRITICAL',  tone: 'bad'     },
      { metric: 'admin operations cross-region',    expected: 'fail with retry',         actual: 'failed; some hung indefinitely',   tone: 'bad'     },
    ],
    outcome: {
      tone: 'failure',
      title: 'FAILURE — partition survived, recovery did not',
      text: `The user-facing claim held: both regions kept serving traffic. But the recovery was a disaster. Replication queue grew 10× faster than expected (because of a recent feature that increased cross-region writes). Drain took 18× longer than predicted. During the 90-minute drain, the system was operationally degraded — admin tooling didn't work properly, dashboards were stale. Action items: load-test the replication queue at higher rates, add backpressure when queue exceeds a threshold, add a timeout to all admin cross-region operations so they fail fast instead of hanging.`,
      icon: XCircle,
    },
    lesson: `The hypothesis covered the SURVIVING-THE-FAILURE part. It missed the RECOVERING-FROM-THE-FAILURE part. Most chaos engineers will tell you: surviving the chaos is the easy part. Recovery is where most reliability claims die. Always design experiments that include the recovery period — not just the failure window.`,
  },
  {
    id: 'pool-exhaustion',
    label: 'Exhaust DB connection pool',
    icon: '⛔',
    setup: {
      target: 'orders-service primary database connection pool (size 50)',
      injection: 'Open and hold 50 idle connections from a separate test client',
      duration: '10 minutes (off-peak, careful monitoring)',
      blastRadius: 'Production · high · expected to trigger backpressure',
    },
    hypothesis: `When the pool exhausts, orders-service requests will wait briefly for a connection (up to 500ms timeout configured). Past that, they will return HTTP 503 with a Retry-After header. Clients (web app + mobile) will retry with exponential backoff. Background job worker will pause its database-heavy operations and resume when capacity recovers. Net user impact: brief elevated latency, no errors past the 500ms threshold.`,
    observations: [
      { metric: 'orders-api error rate',            expected: '503s within 500ms',       actual: '503s within 500ms · clean',         tone: 'ok'      },
      { metric: 'orders-api latency p99',           expected: 'briefly up to 500ms',     actual: 'p99 600ms during window',           tone: 'ok'      },
      { metric: 'client retry rate',                expected: 'elevated, success after backoff', actual: 'elevated, success after backoff', tone: 'ok' },
      { metric: 'background job worker',            expected: 'pauses gracefully',       actual: 'CRASHED · no backpressure path',    tone: 'bad'     },
      { metric: 'orphaned job queue',                expected: 'empty',                   actual: '12,000 jobs stuck after worker died', tone: 'bad'   },
    ],
    outcome: {
      tone: 'partial',
      title: 'PARTIAL — API survived, worker did not',
      text: `The synchronous API path handled the exhaustion correctly — backpressure was clean, clients retried, no data lost. But the background worker had no backpressure path; it crashed when its pool connection attempts kept timing out. 12,000 jobs got stuck in the queue, and the worker's crash-loop took 20 minutes to recover. Action items: add the same backpressure pattern to the worker as the API; add a "pool wait" metric for the worker; document the failure mode in the runbook so on-call doesn't kill the worker pods (which makes it worse).`,
      icon: AlertTriangle,
    },
    lesson: `Backpressure is a SYSTEM-WIDE discipline, not a per-service one. The API got the discipline; the worker didn't. Chaos experiments reveal these asymmetries quickly. Every service in your fleet should be evaluated for backpressure independently — "we have backpressure" is too coarse a claim.`,
  },
];

const OUTCOME_TONE = {
  success: { border: 'border-emerald-300/60', bg: 'bg-emerald-300/10', text: 'text-emerald-300' },
  partial: { border: 'border-amber-400/60',   bg: 'bg-amber-400/10',   text: 'text-amber-400'   },
  failure: { border: 'border-rose-400/60',    bg: 'bg-rose-400/10',    text: 'text-rose-400'    },
};

const OBSERVATION_TONE = {
  ok:      'text-emerald-300',
  caution: 'text-amber-300',
  bad:     'text-rose-300',
};

function ChaosExperimentDesigner() {
  const [idx, setIdx] = useState(2);  // start on the partition — most instructive
  const exp = EXPERIMENTS[idx];
  const tone = OUTCOME_TONE[exp.outcome.tone];
  const OIcon = exp.outcome.icon;

  return (
    <div className="my-6 border border-emerald-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-emerald-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-emerald-300" />
          <span className="text-emerald-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · chaos experiment designer
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Experiment picker */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
          {EXPERIMENTS.map((e, i) => {
            const isActive = i === idx;
            const t = OUTCOME_TONE[e.outcome.tone];
            return (
              <button key={e.id} onClick={() => setIdx(i)}
                className={`px-2 py-2 border text-left transition-colors ${
                  isActive
                    ? `${t.border} ${t.bg}`
                    : 'border-zinc-700 hover:border-zinc-500 bg-zinc-900/30'
                }`}>
                <div className={`text-[18px] mb-1 ${isActive ? t.text : 'text-zinc-500'}`}>{e.icon}</div>
                <div className={`text-[10.5px] leading-tight font-semibold ${isActive ? t.text : 'text-zinc-300'}`}
                  style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                  {e.label}
                </div>
              </button>
            );
          })}
        </div>

        {/* Setup */}
        <div className="border border-zinc-800 bg-zinc-900/40 p-3 mb-3">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2 flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Beaker size={11} /> experiment setup
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-3 gap-y-1.5 text-[11.5px]"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <div className="flex flex-col">
              <span className="text-zinc-500 text-[9px] tracking-[0.2em] uppercase">target</span>
              <span className="text-zinc-200">{exp.setup.target}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-zinc-500 text-[9px] tracking-[0.2em] uppercase">injection</span>
              <span className="text-zinc-200">{exp.setup.injection}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-zinc-500 text-[9px] tracking-[0.2em] uppercase">duration</span>
              <span className="text-zinc-200">{exp.setup.duration}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-zinc-500 text-[9px] tracking-[0.2em] uppercase">blast radius</span>
              <span className="text-zinc-200">{exp.setup.blastRadius}</span>
            </div>
          </div>
        </div>

        {/* Hypothesis */}
        <div className="border border-emerald-300/40 bg-emerald-300/5 p-3 mb-3">
          <div className="text-emerald-300 text-[10px] tracking-[0.25em] uppercase font-semibold mb-1.5 flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Target size={11} /> steady-state hypothesis
          </div>
          <div className="text-zinc-200 text-[12.5px] leading-relaxed">
            {exp.hypothesis}
          </div>
        </div>

        {/* Observations */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-3 mb-3">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2 flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <Activity size={11} /> observations during experiment
          </div>
          <div className="grid grid-cols-[1fr_1fr_1.4fr] gap-1.5 text-[10.5px] mb-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <div className="text-zinc-500 tracking-[0.15em] uppercase text-[9px]">metric</div>
            <div className="text-zinc-500 tracking-[0.15em] uppercase text-[9px]">expected</div>
            <div className="text-zinc-500 tracking-[0.15em] uppercase text-[9px]">actual</div>
          </div>
          <div className="space-y-1">
            {exp.observations.map((o, i) => (
              <div key={i} className="grid grid-cols-[1fr_1fr_1.4fr] gap-1.5 items-start py-1 border-t border-zinc-800/60 text-[10.5px]"
                style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                <div className="text-zinc-300">{o.metric}</div>
                <div className="text-zinc-500">{o.expected}</div>
                <div className={`${OBSERVATION_TONE[o.tone]} font-semibold`}>{o.actual}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Outcome */}
        <div className={`border ${tone.border} ${tone.bg} p-3 mb-3`}>
          <div className={`text-[10.5px] tracking-[0.25em] uppercase font-semibold mb-1.5 flex items-center gap-2 ${tone.text}`}
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <OIcon size={12} />
            {exp.outcome.title}
          </div>
          <div className="text-zinc-200 text-[12.5px] leading-relaxed">
            {exp.outcome.text}
          </div>
        </div>

        {/* Lesson */}
        <div className="border border-sky-300/40 bg-sky-300/5 p-3">
          <div className="text-sky-300 text-[10px] tracking-[0.25em] uppercase font-semibold mb-1.5 flex items-center gap-1.5"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <FlaskConical size={11} /> what we learned
          </div>
          <div className="text-zinc-200 text-[12.5px] leading-relaxed italic">
            {exp.lesson}
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section03_Chaos() {
  return (
    <>
      <SectionLabel>section 03</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Chaos engineering — proving reliability instead of hoping
      </h2>
      <P>
        Sections 01 and 02 made reliability into math. This section makes it into evidence.
        SLOs commit you to a target. Error budgets give you permission to risk it. Chaos
        engineering tells you whether your system can actually meet the target when stressed —
        because the only true reliability claim is the one you have tested. Code that has
        never run with the database unreachable has not been tested with the database
        unreachable. Everything else is hope.
      </P>

      <H2 num="◇ 01">Why chaos — the "tested" vs "designed" reliability gap</H2>
      <Code id="chaos-rationale" lang="text">{`THE PROBLEM:

   Your architecture diagram says the system handles a DB primary failure
   gracefully. The runbook describes the failover. The replica is configured.
   The team confirmed it works "in theory."

   But:
     - Has anyone actually tested this in production?
     - When the replica took over, did the connection pool reconnect?
     - When the application reconnected, did the cached queries work?
     - When the failover happened, did the queue consumers handle the gap?
     - When the load returned to the new primary, did pgbouncer behave?

   Nobody knows. The architecture diagram is a HYPOTHESIS. Until you test
   it under realistic failure, you have a design — not a tested system.

THE CORE INSIGHT:

   YOUR ACTUAL RELIABILITY = WHAT YOU HAVE TESTED.

   Anything you have not tested could fail in any number of unexpected ways.
   The only path to confidence is to test it — under realistic conditions,
   in production, repeatedly, with consequences if it fails.

   Chaos engineering is the discipline of running these tests deliberately.`}</Code>

      <H2 num="◇ 02">The Netflix origin — Chaos Monkey and the Simian Army</H2>
      <P>
        Chaos engineering as a named discipline started at Netflix in 2010 during their
        migration from a single data center to AWS. The reliability requirements crossed a
        threshold where traditional testing was insufficient. The response was an automated
        system that randomly killed production instances during business hours — Chaos Monkey.
      </P>
      <Code id="simian-army" lang="text">{`THE NETFLIX SIMIAN ARMY (circa 2011-2014):

   CHAOS MONKEY    Randomly terminates production instances during work hours.
                   "If we are going to lose instances anyway, let's lose them
                    when engineers are awake."

   CHAOS GORILLA   Simulates an entire AWS Availability Zone outage.

   CHAOS KONG      Simulates an entire AWS Region outage.

   LATENCY MONKEY  Injects artificial delays into service calls.

   CONFORMITY MONKEY Finds instances that don't match best practices and shuts them down.

   DOCTOR MONKEY   Performs health checks and removes unhealthy instances.

   JANITOR MONKEY  Searches for and removes unused resources.

   10-18 MONKEY    Detects internationalization (i18n) and localization (l10n) issues.

THE INSIGHT THAT NETFLIX SHIPPED INTO THE INDUSTRY:

   You don't get reliability by AVOIDING failure. You get reliability by
   designing your system to ABSORB failure, then constantly verifying that
   the design works by INJECTING failure on purpose.

   The willingness to deliberately break production is the price of admission
   for serious reliability. Everything else is theater.`}</Code>

      <H2 num="◇ 03">The four principles of chaos engineering</H2>
      <P>
        Codified at principlesofchaos.org, mostly by ex-Netflix engineers. Four steps that
        define what makes a chaos experiment LEGITIMATE — versus just randomly breaking things.
      </P>
      <Code id="four-principles" lang="text">{`1. BUILD A HYPOTHESIS AROUND STEADY-STATE BEHAVIOR

   Before injecting failure, write down what you EXPECT the system to do.
   Specifically:
     - What metric will be unchanged? (e.g., request rate, business KPIs)
     - What metric will be DIFFERENT? (e.g., one service's latency briefly)
     - For how long?

   A chaos experiment without a hypothesis is just breakage. The hypothesis
   turns breakage into a TEST.

2. VARY REAL-WORLD EVENTS

   The failures you inject should be REPRESENTATIVE of what could actually
   happen in production. Common ones:
     - Hardware failure: kill an instance
     - Network failure: drop packets, add latency, partition
     - Resource exhaustion: fill memory, fill disk, exhaust pool
     - Dependency failure: block calls to an external service
     - Region/AZ failure: take down a whole availability zone
     - Time skew: distort clocks (for consensus-sensitive systems)
     - Software failure: deploy a broken version (for canary system tests)

   Do NOT inject failures that cannot happen in reality (e.g., "all servers
   simultaneously experience cosmic-ray bit-flips at exactly 14:32"). Those
   experiments teach nothing about real risks.

3. RUN EXPERIMENTS IN PRODUCTION

   The most controversial principle. Staging environments do not have:
     - Real traffic patterns
     - Real data shape
     - Real third-party dependencies
     - Real load
     - Real users

   The reliability claim is about PRODUCTION. Verifying it requires testing
   in production — carefully, with limited blast radius, with rollback ready.

4. AUTOMATE EXPERIMENTS TO RUN CONTINUOUSLY

   A one-time chaos exercise is theater. The system evolves; what was safe
   yesterday may be broken today by a recent change. Continuous chaos —
   running on a schedule, automatically — keeps the claim fresh.`}</Code>
      <Callout kind="budget" title="THE PRINCIPLE THAT BREAKS MOST TEAMS">
        Principle 3 — "Run experiments in production" — is where most teams stop. It feels
        irresponsible to break production deliberately. The argument FOR doing it: production
        WILL break unexpectedly; you can either find out under your own controlled conditions
        with rollback ready, or find out at 3 AM during a real outage. Most teams that adopt
        chaos engineering eventually run in production; the ones that don't never reach the
        reliability claims they aspire to.
      </Callout>

      <H2 num="◇ 04">Blast radius — never test what you cannot recover from</H2>
      <P>
        The single most important operational discipline in chaos engineering is BLAST RADIUS
        MANAGEMENT — limiting the scope of an experiment so that if the hypothesis is wrong,
        the damage is contained. Every experiment escalates through stages.
      </P>
      <Code id="blast-radius" lang="text">{`THE BLAST RADIUS ESCALATION LADDER:

   1. DEV / LOCAL          One developer's laptop. Zero customer impact.
                            Verify the injection mechanism itself works.

   2. STAGING                A non-production environment. Verify the experiment
                            framework, the metrics, the rollback procedure.

   3. PRODUCTION CANARY     A small percentage of production traffic (e.g., 1%
                            of requests, or one out of 30 pods). Limited
                            customer impact if hypothesis is wrong.

   4. PRODUCTION PARTIAL    Larger percentage (10-25%). Material impact if
                            hypothesis is wrong, but still bounded.

   5. PRODUCTION FULL       100% of one service / region / AZ. Significant
                            impact possible. Only run after smaller scales
                            confirm the hypothesis.

NEVER ESCALATE WITHOUT PROOF:
   Each stage must succeed before moving to the next. If stage 3 reveals an
   unexpected failure, STOP. Fix the issue. Re-run stage 3. Only then proceed.

ABORT CRITERIA — DEFINE BEFORE STARTING:
   - Error rate exceeds X%
   - User-facing latency exceeds Y ms
   - Business KPI drops below threshold (orders/min, signups/min, etc.)
   - Any alert pages

   If abort criteria trigger, the experiment ROLLS BACK IMMEDIATELY — the
   injection stops, the system returns to normal. Then analyze.`}</Code>

      <H2 num="◇ 05">Game days — chaos as team training</H2>
      <P>
        A game day is a scheduled chaos exercise where the on-call team responds as if it
        were a real incident. The injection is announced ahead of time (so leadership knows),
        but the responding engineers act as if surprised — they follow the runbook, escalate
        through the chain, communicate publicly, run the incident as live. The training
        value rivals the testing value.
      </P>
      <Code id="game-days" lang="text">{`A GAME DAY HAS THE FOLLOWING ROLES:

   THE INJECTOR     An engineer (often the team lead or chaos engineer) who
                    triggers the failure at the agreed time. Knows the
                    full picture. Holds the "abort" button.

   THE RESPONDERS   The on-call team. They do NOT know the exact failure
                    that's coming (or sometimes know it but practice the
                    response anyway). They run the incident as if real.

   THE OBSERVERS    Senior engineers, leadership, occasionally other teams.
                    Watch how the response unfolds. Take notes. Provide
                    feedback after.

WHAT GAME DAYS REVEAL:
   - Runbooks that don't actually work
   - Alerts that fire too late, too early, or to the wrong people
   - Escalation paths that break (e.g., the listed person is on vacation)
   - Dashboards that lack the necessary view during this kind of incident
   - Communication channels that get jammed
   - Team members who do not know how to use the tooling under pressure
   - Whether the team makes the SAME decisions under simulated stress

CADENCE: most teams do a major game day quarterly. Smaller, single-system
chaos experiments run weekly or continuously.`}</Code>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 06">Read four real-shaped chaos experiments</H2>
      <P>
        Four production-realistic experiments — instance kill, latency injection, network
        partition, pool exhaustion. Each has its setup, steady-state hypothesis, observed
        metrics (expected vs actual), outcome, and the lesson learned. Notice how the failure
        modes are rarely "the system broke totally" — they are almost always "the system
        mostly worked, but one specific assumption was wrong." That is what chaos engineering
        reveals: not whether your system survives, but WHICH HIDDEN ASSUMPTIONS are wrong.
      </P>

      <ChaosExperimentDesigner />

      <H2 num="◇ 07">The tooling landscape</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-emerald-300">Gremlin.</strong> Managed SaaS. The "Netflix engineering as a product" company. Polished UI, broad failure-injection catalog, runs on Kubernetes / bare metal / EC2. The default for teams that want fast adoption without building infrastructure.
        </li>
        <li>
          <strong className="text-emerald-300">Chaos Mesh.</strong> CNCF, open source, Kubernetes-native. Declarative experiment YAML; Kubernetes operator runs the injections. The default if you are k8s-heavy and want self-hosted.
        </li>
        <li>
          <strong className="text-emerald-300">Litmus.</strong> CNCF, open source, broader scope than Chaos Mesh — supports k8s plus VMs. Workflow-based experiment composition. Strong community.
        </li>
        <li>
          <strong className="text-emerald-300">AWS Fault Injection Simulator (FIS).</strong> Managed by AWS. Direct integration with AWS services (EC2, RDS, ECS, EKS, etc.). The default if your stack is heavily AWS-native.
        </li>
        <li>
          <strong className="text-emerald-300">Steadybit.</strong> Managed, similar to Gremlin. Strong on game-day workflows and reliability tests as code.
        </li>
        <li>
          <strong className="text-emerald-300">Toxiproxy.</strong> Open source from Shopify. A proxy that lets you inject network failures (latency, packet loss, slow connections) at a single point. Light, focused, often used as a building block.
        </li>
        <li>
          <strong className="text-emerald-300">"Just kill -9 stuff" / scripts.</strong> Many small teams start here. Works fine until you need scheduling, blast radius limits, automated abort, and integration with metrics. Tools are an upgrade, not a starting requirement.
        </li>
      </ul>

      <H2 num="◇ 08">Common anti-patterns</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-rose-400">No hypothesis.</strong> Running a chaos experiment without writing down what you expect to happen. You learn nothing because you cannot tell whether the result is normal or surprising.</li>
        <li><strong className="text-rose-400">Starting in production at full blast.</strong> Skipping dev / staging / canary stages. The first prod experiment is the one you cannot recover from.</li>
        <li><strong className="text-rose-400">No abort criteria.</strong> "We'll see how it goes" with no pre-defined trigger to roll back. The experiment runs longer than it should because everyone is hoping it will recover.</li>
        <li><strong className="text-rose-400">Running once and declaring victory.</strong> The system that survived last quarter's instance-kill experiment has been changed 200 times since. The chaos claim is stale. Continuous chaos beats one-time chaos.</li>
        <li><strong className="text-rose-400">Hiding chaos from product / leadership.</strong> Running experiments without telling the org. The first incident response after a chaos-caused issue surfaces the program in the worst possible way. Build the chaos program with open stakeholders.</li>
        <li><strong className="text-rose-400">Testing only the failure, not the recovery.</strong> The hypothesis covers what happens DURING the chaos. It often misses what happens AFTER. Most real-world recovery problems live in the "everything went back to normal, but..." period.</li>
      </ul>

      <H2 num="◇ 09">Hardening checklist for chaos engineering</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Chaos experiments documented BEFORE running (hypothesis, blast radius, abort criteria, rollback plan)</li>
        <li>✓ Experiments escalate through dev → staging → canary → partial → full; no skipping stages</li>
        <li>✓ Abort criteria defined as concrete metrics with thresholds, not "we&apos;ll see"</li>
        <li>✓ Automatic abort tooling exists and is tested — operators can pull the rip-cord in seconds</li>
        <li>✓ All major systems exercised quarterly via game days; smaller chaos continuously</li>
        <li>✓ Game days have explicit injector / responder / observer roles</li>
        <li>✓ Findings from each experiment generate action items, tracked to completion</li>
        <li>✓ Recovery (not just failure tolerance) is part of every experiment&apos;s hypothesis</li>
        <li>✓ Chaos program visible to product / leadership; not a hidden engineering ritual</li>
        <li>✓ Postmortems run for unexpected chaos outcomes; treated as legitimate incidents that produced learning instead of cost</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Section 04 closes the atlas with the math of "good enough" — the cost curve of nines,
        the relationship between SLOs and shipping speed, and the connective tissue to Atlas
        25 (Incident Response) which picks up where this atlas ends: when reliability claims
        meet the real world and break, what disciplined teams do next.
      </Callout>
    </>
  );
}
