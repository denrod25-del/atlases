/* Section 02 — Error Budgets.
 *
 * Prose + Error Budget Burn Simulator.
 *
 * The simulator: four pre-built 30-day burn scenarios. Each shows the
 * daily downtime in minutes, the cumulative budget consumed as a curve,
 * the threshold line at 100% (exhaustion), and markers where multi-burn-
 * rate alerts would have fired. The student switches between scenarios
 * to see how different failure patterns consume budget at different
 * speeds — and which patterns trigger which alerts.
 *
 * The teaching aim: error budget is the math that converts "reliability"
 * from a feeling into a permission system. When the budget is healthy,
 * ship fast. When it's burning, slow down. When it's exhausted, freeze
 * features until the rolling window recovers.
 *
 * All prose strings use backticks (template literals).
 */

import { useState, useMemo } from 'react';
import { Sparkles, Gauge, AlertTriangle, CheckCircle2, Flame, ShieldCheck } from 'lucide-react';
import { Code, Callout, H2, P, Kbd, SectionLabel } from '../components/primitives.jsx';

// ───────────────────────────────────────────────────────────────────────
// Error Budget Burn Simulator
// ───────────────────────────────────────────────────────────────────────

// Budget for 99.9% SLO over 30 days: (1 - 0.999) × 30 × 24 × 60 = 43.2 minutes
const TOTAL_BUDGET_MIN = 43.2;
const DAYS = 30;

/* Each scenario provides 30 daily burns (in minutes of downtime that day).
 * The simulator computes cumulative consumption and the budget remaining.
 */
const SCENARIOS = [
  {
    id: 'steady',
    label: 'Steady state',
    description: `A healthy service running normally. Tiny background error rate of about 0.5 minutes of effective downtime per day, mostly due to occasional brief blips. Burns about 35% of the month's budget across 30 days — well within the SLO.`,
    daily: Array.from({ length: DAYS }, () => 0.3 + Math.random() * 0.4),
    alerts: [],
    verdict: {
      tone: 'safe',
      icon: ShieldCheck,
      title: 'SAFE — budget healthy',
      text: `Operating well inside the budget. Burn rate is sustainable — at this pace the month ends with significant budget remaining. Engineering can focus on feature work, take some calculated risks, and run chaos experiments to test reliability claims. This is what a healthy service looks like.`,
    },
  },
  {
    id: 'slow-leak',
    label: 'Slow leak',
    description: `A subtle regression introduced on day 5 — perhaps a slightly slower DB query path that takes a few percent of requests just over the latency threshold. No single day looks bad in isolation; the budget bleeds steadily until the alerts fire on cumulative consumption.`,
    daily: Array.from({ length: DAYS }, (_, i) => {
      if (i < 5) return 0.3 + Math.random() * 0.2;
      // bleeding from day 5 onward
      return 1.8 + Math.random() * 0.6;
    }),
    alerts: [
      { day: 14, type: '6h burn', text: `6h burn-rate alert at day 14 — burning ~13% of budget per day; would exhaust the month's budget by day 22` },
      { day: 22, type: '24h burn', text: `Slow-burn alert at day 22 — over 80% of budget consumed; near exhaustion` },
    ],
    verdict: {
      tone: 'elevated',
      icon: AlertTriangle,
      title: 'ELEVATED — slow burn detected',
      text: `Two slow-burn alerts fired during the month. The bleeding pattern suggests a regression (the slow query path introduced on day 5). The alerts gave engineering 8 days of warning before exhaustion — long enough to find and fix the root cause without freezing features. This is what multi-window burn-rate alerts are designed to catch.`,
    },
  },
  {
    id: 'sudden',
    label: 'Sudden incident',
    description: `Normal operation for most of the month, then a major incident on day 18 — perhaps a regional outage that affected requests for 4 hours. One incident burns 35% of the month's budget in a single day. Fast-burn alerts fired within an hour of the incident starting.`,
    daily: Array.from({ length: DAYS }, (_, i) => {
      if (i === 17) return 15;  // the bad day: ~15 min of downtime
      return 0.3 + Math.random() * 0.4;
    }),
    alerts: [
      { day: 18, type: '1h burn', text: `Fast-burn alert at day 18, 14:32 — burning ~2% of monthly budget per hour; would exhaust in ~50 hours at this rate` },
      { day: 18, type: '6h burn', text: `6h burn alert at day 18, 18:45 — accumulated impact crossing threshold` },
    ],
    verdict: {
      tone: 'elevated',
      icon: Flame,
      title: 'ELEVATED — major incident, contained',
      text: `Big incident, fast alert, contained quickly. Most of the month's budget was eaten in 4 hours. The remaining budget is tight; for the rest of the rolling window the team should slow feature work and prioritize stability. The fast-burn alert triggered within an hour — fast enough that human responders could engage before the incident grew worse.`,
    },
  },
  {
    id: 'exhausted',
    label: 'Budget exhausted',
    description: `A bad month. Several smaller incidents combined with a couple of larger ones. By day 24 the cumulative consumption crosses 100% — the SLO has been MISSED. The on-paper consequence: feature freeze, reliability work prioritized over everything else.`,
    daily: [
      0.4, 0.3, 0.5, 0.4, 0.6,     // 1-5: normal
      6.0, 0.4, 0.5,                // 6-8: small incident day 6
      0.4, 0.5, 8.5, 0.6, 0.4,     // 9-13: medium incident day 11
      0.5, 0.3, 0.4, 0.5,           // 14-17: normal
      12.0, 1.2, 0.5, 0.6,         // 18-21: big incident day 18
      0.4, 0.5, 15.0,              // 22-24: another big incident day 24
      0.4, 0.5, 0.4, 0.5, 0.3, 0.4 // 25-30: normal (but too late)
    ],
    alerts: [
      { day: 6, type: '1h burn', text: `Fast-burn alert at day 6 — first incident` },
      { day: 11, type: '1h burn', text: `Fast-burn alert at day 11 — second incident` },
      { day: 18, type: '1h burn', text: `Fast-burn alert at day 18 — third incident` },
      { day: 24, type: 'EXHAUSTION', text: `BUDGET EXHAUSTED at day 24 — SLO will be missed for the rolling window` },
    ],
    verdict: {
      tone: 'exhausted',
      icon: AlertTriangle,
      title: 'EXHAUSTED — SLO MISSED, feature freeze',
      text: `Four incidents combined to exhaust the month's budget by day 24. Per the team's documented error budget policy: feature work freezes; reliability backlog moves to top priority; postmortems for the four incidents drive the next month's reliability investments. This is the entire reason the budget exists — not as punishment, but as the math-driven moment when the team agrees "we are not reliable enough; stop adding features and fix things."`,
    },
  },
];

const TONE_STYLES = {
  safe:      { border: 'border-emerald-300/60', bg: 'bg-emerald-300/10', text: 'text-emerald-300' },
  elevated:  { border: 'border-amber-400/60',   bg: 'bg-amber-400/10',   text: 'text-amber-400'   },
  exhausted: { border: 'border-rose-400/60',    bg: 'bg-rose-400/10',    text: 'text-rose-400'    },
};

function ErrorBudgetBurnSimulator() {
  const [idx, setIdx] = useState(2);  // start on sudden — most instructive
  const scenario = SCENARIOS[idx];

  // Compute cumulative consumption per day
  const cumulative = useMemo(() => {
    const out = [];
    let total = 0;
    for (const d of scenario.daily) {
      total += d;
      out.push(total);
    }
    return out;
  }, [scenario]);

  const totalBurned = cumulative[cumulative.length - 1];
  const pctBurned = Math.min((totalBurned / TOTAL_BUDGET_MIN) * 100, 100);
  const remaining = Math.max(TOTAL_BUDGET_MIN - totalBurned, 0);

  const tone = TONE_STYLES[scenario.verdict.tone];
  const VIcon = scenario.verdict.icon;

  // SVG dimensions
  const svgW = 800;
  const svgH = 180;
  const dayW = svgW / DAYS;
  const maxBurnDay = Math.max(...scenario.daily, 8);  // floor to keep small bars visible
  const exhaustY = (1 - 1) * svgH;  // unused — kept for clarity

  // Y for cumulative curve: 0 at top of usable area, 100% (exhaustion) at half-height
  const yForCumulative = (val) => {
    const pct = Math.min(val / (TOTAL_BUDGET_MIN * 1.5), 1);  // cap visually
    return svgH - (pct * svgH);
  };

  return (
    <div className="my-6 border border-emerald-300/30 bg-zinc-900/40">
      <div className="flex items-center justify-between bg-zinc-950 px-4 py-2.5 border-b border-emerald-300/30">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-emerald-300" />
          <span className="text-emerald-300 text-[11px] tracking-[0.25em] uppercase font-semibold"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            interactive · error budget burn simulator
          </span>
        </div>
      </div>

      <div className="p-4">
        {/* Setup info */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          <div className="border border-zinc-800 bg-zinc-950/60 p-2">
            <div className="text-zinc-500 text-[9px] tracking-[0.25em] uppercase"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>slo target</div>
            <div className="text-zinc-100 text-[13px] font-bold"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>99.9%</div>
          </div>
          <div className="border border-zinc-800 bg-zinc-950/60 p-2">
            <div className="text-zinc-500 text-[9px] tracking-[0.25em] uppercase"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>budget · 30d</div>
            <div className="text-zinc-100 text-[13px] font-bold"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>43.2 min</div>
          </div>
          <div className="border border-zinc-800 bg-zinc-950/60 p-2">
            <div className="text-zinc-500 text-[9px] tracking-[0.25em] uppercase"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>window</div>
            <div className="text-zinc-100 text-[13px] font-bold"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>rolling 30d</div>
          </div>
        </div>

        {/* Scenario tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 mb-3">
          {SCENARIOS.map((s, i) => (
            <button key={s.id} onClick={() => setIdx(i)}
              className={`px-2 py-1.5 border text-[11px] transition-colors text-left ${
                i === idx
                  ? 'border-emerald-300 bg-emerald-300/15 text-emerald-200'
                  : 'border-zinc-700 text-zinc-400 hover:border-emerald-300/50 hover:text-zinc-200'
              }`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <div className="font-semibold">{s.label}</div>
            </button>
          ))}
        </div>

        {/* Description */}
        <div className="mb-3 p-3 border border-zinc-800 bg-zinc-900/40 text-zinc-300 text-[13px] leading-relaxed italic">
          {scenario.description}
        </div>

        {/* Budget tank */}
        <div className="border border-zinc-800 bg-zinc-950/60 p-3 mb-3">
          <div className="flex items-center justify-between mb-2">
            <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <Gauge size={11} /> budget tank
            </div>
            <div className={`text-[11px] font-bold ${tone.text}`}
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {Math.max(0, 100 - pctBurned).toFixed(1)}% remaining · {remaining.toFixed(1)} min left
            </div>
          </div>
          <div className="h-6 w-full bg-zinc-900 border border-zinc-800 relative overflow-hidden">
            <div className={`h-full ${
              pctBurned < 50  ? 'bg-emerald-400/70'  :
              pctBurned < 80  ? 'bg-amber-400/70'    :
                                'bg-rose-400/70'
            }`} style={{ width: `${Math.min(pctBurned, 100)}%` }} />
            <div className="absolute inset-0 flex items-center justify-center text-[11px] font-bold text-zinc-50"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {pctBurned.toFixed(1)}% burned
            </div>
          </div>
        </div>

        {/* Burn timeline SVG */}
        <div className="border border-zinc-800 bg-zinc-950/80 p-3 mb-3">
          <div className="text-zinc-500 text-[9.5px] tracking-[0.25em] uppercase mb-2"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            30-day burn timeline (daily downtime + cumulative consumption)
          </div>
          <svg viewBox={`0 0 ${svgW} ${svgH + 30}`} className="w-full" preserveAspectRatio="none">
            {/* Exhaustion threshold line (100% budget) */}
            <line
              x1={0}
              y1={yForCumulative(TOTAL_BUDGET_MIN)}
              x2={svgW}
              y2={yForCumulative(TOTAL_BUDGET_MIN)}
              stroke="#f87171"
              strokeWidth={1}
              strokeDasharray="4 3" />
            <text x={5} y={yForCumulative(TOTAL_BUDGET_MIN) - 4}
              fill="#f87171"
              fontSize="9"
              fontFamily="JetBrains Mono, monospace">
              100% budget — exhaustion line
            </text>

            {/* Daily burn bars (lower half) */}
            {scenario.daily.map((d, i) => {
              const barH = (d / maxBurnDay) * (svgH * 0.4);
              const isHigh = d > 5;
              return (
                <rect key={i}
                  x={i * dayW + 1}
                  y={svgH - barH}
                  width={dayW - 2}
                  height={barH}
                  className={isHigh ? 'fill-rose-400/70' : 'fill-emerald-300/40'}
                />
              );
            })}

            {/* Cumulative consumption line */}
            <polyline
              points={cumulative.map((v, i) => `${i * dayW + dayW/2},${yForCumulative(v)}`).join(' ')}
              fill="none"
              stroke="#fb7185"
              strokeWidth={1.8}
            />
            {cumulative.map((v, i) => (
              <circle key={i}
                cx={i * dayW + dayW/2}
                cy={yForCumulative(v)}
                r={1.5}
                fill="#fb7185"
              />
            ))}

            {/* Alert markers */}
            {scenario.alerts.map((a, i) => {
              const x = (a.day - 0.5) * dayW;
              const isExhaust = a.type === 'EXHAUSTION';
              return (
                <g key={i}>
                  <line x1={x} y1={0} x2={x} y2={svgH}
                    stroke={isExhaust ? '#f87171' : '#fbbf24'}
                    strokeWidth={isExhaust ? 2 : 1}
                    strokeDasharray="2 2" />
                  <text x={x + 4} y={12}
                    fill={isExhaust ? '#f87171' : '#fbbf24'}
                    fontSize="9"
                    fontWeight="700"
                    fontFamily="JetBrains Mono, monospace">
                    {a.type}
                  </text>
                </g>
              );
            })}

            {/* Baseline */}
            <line x1={0} y1={svgH} x2={svgW} y2={svgH} stroke="#3f3f46" strokeWidth={1} />

            {/* X-axis day labels */}
            {[1, 5, 10, 15, 20, 25, 30].map(d => (
              <text key={d}
                x={(d - 0.5) * dayW}
                y={svgH + 20}
                fill="#52525b"
                fontSize="9"
                fontFamily="JetBrains Mono, monospace"
                textAnchor="middle">
                d{d}
              </text>
            ))}
          </svg>

          {/* Legend */}
          <div className="mt-2 pt-2 border-t border-zinc-800 flex flex-wrap gap-3 text-[9.5px] text-zinc-500"
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-2 bg-emerald-300/40"></span> daily burn (low)
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-2 bg-rose-400/70"></span> daily burn (high)
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-0.5 bg-rose-400"></span> cumulative consumption
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-0.5 bg-amber-400 border-dashed"></span> burn-rate alerts
            </span>
          </div>
        </div>

        {/* Alerts list */}
        {scenario.alerts.length > 0 && (
          <div className="border border-amber-400/40 bg-amber-400/5 p-3 mb-3">
            <div className="text-amber-400 text-[10px] tracking-[0.25em] uppercase font-semibold mb-2 flex items-center gap-1.5"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              <AlertTriangle size={11} /> alerts during this month
            </div>
            <ul className="space-y-1 text-[11.5px] text-zinc-200"
              style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {scenario.alerts.map((a, i) => (
                <li key={i} className="flex gap-2">
                  <span className={`shrink-0 ${a.type === 'EXHAUSTION' ? 'text-rose-400' : 'text-amber-400'}`}>
                    {a.type === 'EXHAUSTION' ? '⊗' : '▲'}
                  </span>
                  <span>{a.text}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Verdict */}
        <div className={`border ${tone.border} ${tone.bg} p-3`}>
          <div className={`text-[10.5px] tracking-[0.25em] uppercase font-semibold mb-1.5 flex items-center gap-2 ${tone.text}`}
            style={{ fontFamily: 'JetBrains Mono, monospace' }}>
            <VIcon size={12} />
            {scenario.verdict.title}
          </div>
          <div className="text-zinc-200 text-[12.5px] leading-relaxed">
            {scenario.verdict.text}
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Section content
// ───────────────────────────────────────────────────────────────────────

export default function Section02_ErrorBudgets() {
  return (
    <>
      <SectionLabel>section 02</SectionLabel>
      <h2 className="text-zinc-50 text-[28px] leading-tight mb-3"
        style={{ fontFamily: 'Bricolage Grotesque, sans-serif', fontWeight: 600 }}>
        Error budgets — turning reliability into permission
      </h2>
      <P>
        An SLO without an error budget is a wish. The error budget is the SLO turned into
        math: the explicit allowance for unreliability per unit of time. When the budget is
        healthy, you have permission to take risks. When it is burning, you slow down. When it
        is exhausted, you stop adding new code and fix what is broken. The error budget makes
        reliability a number that decisions follow from — not a value that gets argued over
        in meetings.
      </P>

      <H2 num="◇ 01">The formula</H2>
      <Code id="budget-formula" lang="text">{`ERROR BUDGET = 1 - SLO

For an SLO of 99.9% over a 30-day rolling window:
   Budget = 1 - 0.999 = 0.001 = 0.1% of requests OR 0.1% of time

   As REQUESTS: at 1M req/day → 30M/month × 0.001 = 30,000 failed requests allowed
   As DOWNTIME: 30 days × 24h × 60min × 0.001 = 43.2 minutes of downtime allowed

THE TWO COMMON FORMS:

   REQUEST-BASED BUDGET:
     budget = (1 - SLO) × total_requests_in_window
     "How many bad requests can we have this month?"
     Better for high-traffic services where downtime is fuzzy
     (partial outages affecting some users)

   TIME-BASED BUDGET:
     budget = (1 - SLO) × window_duration
     "How many minutes can we be down this month?"
     Easier to communicate to non-engineers
     Better for low-traffic services where requests are sparse
     and even minutes matter

PICK ONE. Don't define both for the same SLO — they will diverge and your
team will argue about which is "really" exhausted.`}</Code>

      <H2 num="◇ 02">Burn rate — how fast the budget is being consumed</H2>
      <P>
        At any moment, the burn rate tells you how quickly the current behavior is consuming
        the budget — and therefore how long the budget will last if the pattern continues.
      </P>
      <Code id="burn-rate" lang="text">{`BURN RATE = (current_error_rate) / (1 - SLO)

For a 99.9% SLO (budget allows 0.1% errors):
   If current error rate is 0.1%:  burn_rate = 1.0  (at-budget; exhausts in exactly 30 days)
   If current error rate is 0.5%:  burn_rate = 5.0  (5× budget; exhausts in 6 days)
   If current error rate is 1.0%:  burn_rate = 10.0 (10× budget; exhausts in 3 days)
   If current error rate is 5.0%:  burn_rate = 50.0 (50× budget; exhausts in 14 hours)

THE INTUITION:

   Burn rate = 1.0  → "On track to exactly consume the budget by month end."
   Burn rate < 1.0  → "On track to come in under budget — good."
   Burn rate > 1.0  → "On track to MISS the SLO — investigate."
   Burn rate > 10.0 → "Will exhaust the budget within DAYS — page someone."

   At burn rate X, the time-to-exhaustion is: window_remaining / X.`}</Code>

      <H2 num="◇ 03">Multi-window multi-burn-rate alerts</H2>
      <P>
        The naive approach to error-budget alerting is to alert when the burn rate exceeds
        some threshold (say, "alert when burn rate > 2"). The problem: a brief spike sets
        the alert off even though the impact is minimal, AND a slow, persistent leak that
        burns the entire month silently is missed by short-window evaluation. The canonical
        Google SRE pattern fixes this with multiple simultaneous windows.
      </P>
      <Code id="multi-burn-alerts" lang="text">{`THE GOOGLE SRE RECIPE (four-burn-rate alerts):

   FAST PAGE   1h window + 5m window, burn rate > 14.4
                 → consumes 2% of monthly budget in 1 hour
                 → would exhaust the month in ~50 hours at this rate
                 → page immediately; this is a real incident

   SLOW PAGE   6h window + 30m window, burn rate > 6
                 → consumes 5% of budget in 6 hours
                 → would exhaust the month in ~5 days at this rate
                 → page; growing but not catastrophic

   FAST TICKET 24h window + 2h window, burn rate > 3
                 → consumes 10% of budget in 24 hours
                 → would exhaust the month in ~10 days
                 → file ticket; investigate during business hours

   SLOW TICKET 72h window + 6h window, burn rate > 1
                 → consumes 10% of budget over 72 hours
                 → on track to miss the SLO if pattern continues
                 → file ticket; this is the "slow leak" alarm

WHY TWO WINDOWS PER ALERT:
   Short window confirms the issue is HAPPENING NOW (avoids alerting on
   already-resolved past incidents). Long window confirms it's NOT a 
   one-off blip (avoids alerting on a 30-second spike).

   The alert fires only if BOTH windows show the same burn rate — past
   and present must both be bad.`}</Code>
      <Callout kind="budget" title="THE TWO ALERT CLASSES, IN ONE LINE">
        Page alerts (fast and slow page) interrupt sleep — the burn rate would exhaust the
        month within days. Ticket alerts (fast and slow ticket) catch slow degradations — the
        burn rate would only miss the SLO with enough time to investigate during business
        hours. Both classes matter; both classes are derived from the same budget math; both
        classes go through the same SLO doc that defines the underlying budget.
      </Callout>

      <SectionLabel>practice</SectionLabel>
      <H2 num="◇ 04">Watch four months burn</H2>
      <P>
        Four common burn patterns, each 30 days long, against a 99.9% SLO (43.2 minutes of
        budget). The timeline shows daily downtime as bars and cumulative consumption as a
        line. The dashed red horizontal line is the 100% threshold — crossing it means the
        SLO has been missed. Vertical markers show where multi-burn-rate alerts would have
        fired in real time. Notice how different failure patterns trigger different alert
        classes — and how the same total budget can be exhausted by one bad day or by
        a hundred slightly bad days.
      </P>

      <ErrorBudgetBurnSimulator />

      <H2 num="◇ 05">Error budget as permission — the velocity tradeoff</H2>
      <P>
        The most consequential use of error budgets is not alerting — it is permission.
        Reliability competes with feature velocity. Without a framework, this trade is
        argued constantly. With error budgets, it becomes math: when the budget is healthy,
        ship; when the budget is burning, slow down; when the budget is exhausted, freeze
        feature work.
      </P>
      <Code id="velocity-tradeoff" lang="text">{`THE ERROR BUDGET POLICY (every team needs one written down):

   BUDGET HEALTHY (> 50% remaining):
     - Feature velocity: full speed
     - Risk: acceptable to take calculated risks
     - Chaos experiments: run them now while budget allows
     - Deploy frequency: per the team's normal cadence
     - Reliability work: continues as background priority

   BUDGET BURNING (< 50% remaining):
     - Feature velocity: still moving but reviews tighter
     - Risk: avoid major changes; small, safe deploys only
     - Chaos experiments: defer
     - Deploy frequency: more conservative
     - Reliability work: elevated priority

   BUDGET LOW (< 20% remaining):
     - Feature velocity: only critical features or fixes
     - Risk: no risky changes; require additional approvals
     - Reliability work: top priority for most engineers
     - Deploy frequency: only safety fixes and reliability work

   BUDGET EXHAUSTED (0% remaining; SLO will be missed):
     - Feature velocity: FREEZE — no new feature deploys
     - The team focuses entirely on:
        1. Resolving outstanding incidents
        2. Postmortems for incidents that caused the burn
        3. Reliability work derived from postmortem action items
     - Freeze lasts until the rolling window reflects budget recovery

   THE FREEZE IS NOT PUNISHMENT.
   It is the mechanism by which the team's stated SLO commitment is honored.
   Without it, the SLO is decorative.`}</Code>

      <H2 num="◇ 06">What to do when the budget is exhausted</H2>
      <P>
        Most teams have never actually exhausted a budget — they have only DISCUSSED what
        they would do. The first time a budget really exhausts is the test of whether the
        team has internalized the policy or just published a doc no one reads.
      </P>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li><strong className="text-rose-400">Stop feature deploys.</strong> Production stops moving forward except for safety fixes. This usually surfaces immediate organizational resistance — "but we promised marketing this would ship Monday." Hold the line; this is exactly when the policy proves its value.</li>
        <li><strong className="text-emerald-300">Run postmortems on the incidents that caused the burn.</strong> Each major budget-consuming incident gets a blameless postmortem (Atlas 25). The output: prioritized action items addressing root causes.</li>
        <li><strong className="text-emerald-300">Prioritize reliability work above everything.</strong> The action items from postmortems jump to the top of the backlog. Engineering capacity that was going to features goes to reliability.</li>
        <li><strong className="text-emerald-300">Communicate to stakeholders.</strong> Product, sales, customer success need to know: the team is in a feature freeze for reliability reasons. With the SLO and budget framework, this is a data-driven conversation, not vibes.</li>
        <li><strong className="text-amber-300">Resist the urge to renegotiate the SLO downward.</strong> A common (wrong) response: "let's lower the SLO to 99.5%; then we are not exhausted." This undermines the entire system. Stay disciplined.</li>
      </ul>

      <H2 num="◇ 07">Common anti-patterns</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-2 max-w-prose">
        <li>
          <strong className="text-rose-400">"Stretch SLO" — picking a target you cannot meet.</strong> Some teams set aggressive SLOs they routinely miss, treating them as aspirational. The budget perpetually exhausts; the freeze policy gets ignored; the SLO loses its meaning. Set realistic SLOs and meet them, then tighten gradually.
        </li>
        <li>
          <strong className="text-rose-400">"Budget is full, let&apos;s party."</strong> Some teams interpret a healthy budget as license to take on more risk than needed. Burn the budget DELIBERATELY by running chaos experiments and shipping aggressive features — but do not deliberately push to the budget&apos;s limit just because there&apos;s headroom. Wasting budget you might need later is a real failure mode.
        </li>
        <li>
          <strong className="text-rose-400">"We can&apos;t freeze features."</strong> The organizational refusal to honor the freeze defeats the entire system. If the freeze is not enforceable, the SLO is decorative. Get leadership sign-off on the policy BEFORE the first exhaustion; that&apos;s the only time it&apos;s easy.
        </li>
        <li>
          <strong className="text-rose-400">Renegotiating mid-month.</strong> "We&apos;re going to exhaust; let&apos;s lower the SLO temporarily." This is the worst response. Either the SLO was wrong from the start (negotiate it for NEXT month) or the team is failing the current month (accept the freeze).
        </li>
        <li>
          <strong className="text-rose-400">No SLI for what users actually feel.</strong> Some teams set SLOs on internal metrics (CPU, queue depth) and pass the SLO while users suffer. The SLI must measure user experience. If your SLI is comfortable but your support queue is burning, your SLI is wrong.
        </li>
      </ul>

      <H2 num="◇ 08">Hardening checklist for error budgets</H2>
      <ul className="text-zinc-300 text-[15px] leading-relaxed my-3 list-disc pl-6 space-y-1.5 max-w-prose">
        <li>✓ Error budget calculated and published for every SLO — both as fraction and as concrete units (minutes or requests)</li>
        <li>✓ Multi-window multi-burn-rate alerts configured per SLO (fast page, slow page, fast ticket, slow ticket)</li>
        <li>✓ Burn rate visible on a dashboard with the rolling SLO window clearly labeled</li>
        <li>✓ Error budget policy DOCUMENT exists, signed off by engineering AND product leadership</li>
        <li>✓ Policy specifies exact actions at each budget threshold (healthy / burning / low / exhausted)</li>
        <li>✓ Policy specifies the feature-freeze trigger and recovery condition</li>
        <li>✓ Team has actually rehearsed (or genuinely experienced) the freeze at least once — the policy is real, not decorative</li>
        <li>✓ Burn-rate alerts route to humans who can actually act — not into a Slack channel nobody reads</li>
        <li>✓ Quarterly review: are SLOs the right targets? Are budgets exhausting too often (too aggressive) or never (too loose)?</li>
        <li>✓ No "stretch SLOs" — if budgets perpetually exhaust, the SLO is wrong</li>
      </ul>
      <Callout kind="info" title="WHAT'S NEXT">
        Section 03 turns to chaos engineering — the discipline of PROVING your reliability
        claims rather than hoping for them. Why injecting failures on purpose is the only
        way to know your system survives them. The principles of well-designed chaos
        experiments, game days, and the tooling that makes "break production deliberately"
        survivable.
      </Callout>
    </>
  );
}
